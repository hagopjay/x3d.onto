-- Rising English-Wikipedia articles: views on 2026-10-16 against the 2026-10-13..15 daily average (desktop site, namespace 0 only).
-- surge = today / (baseline + 2000), the +2000 keeps tiny baselines from dominating. Public table, partitioned by day, clustered by (wiki, title).
WITH today AS (
  SELECT title, SUM(views) AS v_today
  FROM `bigquery-public-data.wikipedia.pageviews_2026`
  WHERE datehour >= TIMESTAMP('2026-10-16') AND datehour < TIMESTAMP('2026-10-17')
    AND wiki = 'en' AND title NOT LIKE '%:%' AND title NOT IN ('Main_Page', '-')
  GROUP BY title
  HAVING v_today >= 5000
), base AS (
  SELECT title, SUM(views) / 3 AS v_base
  FROM `bigquery-public-data.wikipedia.pageviews_2026`
  WHERE datehour >= TIMESTAMP('2026-10-13') AND datehour < TIMESTAMP('2026-10-16')
    AND wiki = 'en' AND title NOT LIKE '%:%' AND title NOT IN ('Main_Page', '-')
  GROUP BY title
)
SELECT t.title, t.v_today, IFNULL(b.v_base, 0) AS v_base, SAFE_DIVIDE(t.v_today, IFNULL(b.v_base, 0) + 2000) AS surge
FROM today t LEFT JOIN base b USING (title)
ORDER BY surge DESC
LIMIT 40
