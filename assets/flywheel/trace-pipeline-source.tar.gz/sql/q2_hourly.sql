-- Hourly views for the 12 top-rising (non-sensitive) titles from q1, 2026-10-13 .. 2026-10-16 (96 hours), English Wikipedia desktop.
SELECT title, datehour, SUM(views) AS views
FROM `bigquery-public-data.wikipedia.pageviews_2026`
WHERE datehour >= TIMESTAMP('2026-10-13') AND datehour < TIMESTAMP('2026-10-17')
  AND wiki = 'en' AND title IN UNNEST(['Action_Park', 'Tesla_Roadster_(second_generation)', 'Hello_Kitty_Island_Adventure', 'The_Hunger_(collection)', 'Tesla_Roadster_(first_generation)', 'Bend,_Oregon', 'Hyron_Andrews', 'Jadwiga_of_Poland', 'October_16', 'Steven_Soderbergh', 'Alexander_McQueen', 'Mount_Sneffels'])
GROUP BY title, datehour
ORDER BY title, datehour