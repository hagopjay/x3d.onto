# x3d-trace/1: the shared contract for "data system run -> 3D scene"

Every stage of the pipeline reads or writes this. One JSON file per run: `trace.json`.
Root dir: ~/Projects/x3d/work/trace-pipeline/   (traces/ , scenes/ , out/ , scripts/<stage>/ , ledger/)

```
{
  "schema": "x3d-trace/1",
  "source": {
    "kind": "kafka-sim | bigquery | spark",
    "synthetic": true|false,                 # REQUIRED and must be honest: the Kafka run is synthetic, the BigQuery run is real
    "title": "...", "run_id": "...", "created_utc": "...",
    "engine": {"name": "...", "version": "..."},
    "data": {"description": "...", "origin": "dataset/table or generator", "rows_or_bytes_read": ..., "license_note": "..."},
    "provenance": {"query_sql_sha256": "...", "job_ids": [...], "bytes_processed": ..., "bytes_billed": ..., "seed": ..., "files": {"name": "sha256"}}
  },
  "time": {"unit": "s", "duration": 30.0},                # simulated or wall-clock seconds covered by the series/flows
  "stages": [                                             # nodes of the machine: scan, shuffle, join, sort, sink / producer, partition, consumer ...
    {"id": "S0", "name": "...", "kind": "scan|aggregate|join|sort|output|shuffle|producer|broker|partition|consumer",
     "layer": 0,                                          # left-to-right position (0 = first); same layer = stacked/parallel
     "start_s": 0.0, "end_s": 1.2,
     "parallelism": 40,                                   # tasks / slots / partitions behind this node
     "metrics": {"records_in": ..., "records_out": ..., "bytes_out": ..., "slot_ms": ..., "skew_ratio": 1.0, ...}}   # whatever the engine reports; numbers only
  ],
  "flows": [                                              # edges: data moving between stages
    {"from": "S0", "to": "S2", "records": ..., "bytes": ..., "start_s": 0.0, "end_s": 1.0}
  ],
  "series": {                                             # time series shared by all channels
    "t": [0.0, 0.25, ...],
    "channels": {"active_slots": [...], "stage:S2:rate": [...], "lag:C0": [...]}
  },
  "entities": [                                           # the "hot things": keys, articles, partitions; each may carry its own series
    {"id": "e1", "label": "...", "value": 123456, "rank": 1, "stage": "S3",
     "series": {"t": [...], "v": [...]}}                   # optional
  ],
  "metrics": {"headline_name": number, ...},              # numbers to print on the scene / page (all must be traceable to the engine or the sim)
  "notes": ["honest caveats shown to the viewer"]
}
```

## Rules for all stages
- `source.synthetic` is never omitted and never "false" for generated data. Any scene or page built from a synthetic trace must say SYNTHETIC visibly.
- Numbers in the 3D scene and on the page come from the trace; nothing is invented at render time. Derived values (ratios, normalisations) are computed in the stage that shows them and documented.
- Real-data runs: public datasets only; no personal data. Titles/labels come from the data as is.
- Keep each exported X3D scene under ~1 MB (the x3d.poc site caps assets) unless the stage says otherwise.

## BigQuery mapping (stage "bq-adapter" writes this)
Job statistics (`bq show -j <id>` JSON): `statistics.query.queryPlan[]` -> `stages[]` (id from `id`, name from `name`, `start_s`/`end_s` from startMs/endMs relative to job start,
parallelism from `parallelInputs`, metrics from recordsRead, recordsWritten, shuffleOutputBytes, shuffleOutputBytesSpilled, slotMs, waitRatioAvg/Max, readRatioAvg/Max,
computeRatioAvg/Max, writeRatioAvg/Max; `skew_ratio` = computeRatioMax / computeRatioAvg), `flows[]` from `inputStages`, `series` from `statistics.query.timeline[]`
(elapsedMs, activeUnits, pendingUnits, completedUnits, totalSlotMs). Provenance: job ids, totalBytesProcessed/Billed, cacheHit, query sha256, dataset + table + partition range.

## Kafka mapping (the synthetic fixture)
producers/partitions/consumers are stages (kinds producer/partition/consumer; layers 0/1/2); flows = producer->partition and partition->consumer message counts; series channels =
per-partition msgs/s and per-consumer lag; entities = hot keys with message counts. See ~/Projects/x3d/work/kafka-gossip/ (kafka_sim.py, events.json, metrics.json).

## Budget rules for BigQuery (user-approved 18 Oct 2026)
Wikipedia pageviews on BigQuery, public datasets only, project <PROJECT> via the signed-in gcloud account: dry-run first, `--maximum_bytes_billed` 10 GB per query,
50 GB total. Every query is appended to ledger/bq-ledger.jsonl BEFORE it runs (sql sha256, dry-run bytes, cap) and updated after (job id, bytes billed). Only the parent runs BigQuery.

## Addendum: `mlops-gnn` (graph neural network inside an MLOps pipeline) and the optional `gnn` extension block
Added by the `gnn_to_trace.py` adapter (real data, real training: `source.synthetic = false`). Nothing above changes meaning; consumers that do not know the extension
ignore it (the generic builder `trace_to_scene.py` still builds a valid scene from this trace: pipeline machine + entity pillars).

- `source.kind = "mlops-gnn"`. `stages` = the MLOps stages, layers 0..7 left to right (ingest, validate, split, train, evaluate, register, serve, monitor), `start_s/end_s` = measured
  wall-clock (`time.perf_counter`) relative to the pipeline start, `metrics.wall_ms` = measured milliseconds, other metrics numbers only. Hashes (strings) live in `source.provenance`
  (`stage_hashes`, `files`, `dataset_sha256`, `weights_sha256`, `code_sha256`), never in `metrics`. `stages[].stage_key` is the machine-readable stage name.
- `flows` = hand-over between consecutive stages (`records` = items handed over, `bytes` = the sender's artifact bytes).
- `series.t` = measured end time (run clock, seconds) of every training epoch (epoch 0 = untrained model), `series.epoch` = epoch numbers (extra key), `series.channels` =
  `loss_train`, `loss_all34`, `accuracy_all34`, `accuracy_unlabelled32` (one value per epoch).
- `entities` = one per graph node. `series` carries `{t, x, y, p_officer}` instead of `{t, v}`: embedding position (x, y) = the hidden layer after each epoch and the model's P(class 1).
  `value` = degree, `faction` = the true class name. (Extra series keys: consumers that only read `series.v` skip these entities.)
- `gnn` (extension, all derived values are labelled where they are shown):
  - `dataset`, `model` (layers, hidden size, n_params, optimiser, lr, weight decay, epochs, seed), `nodes[]` (id, label, true faction, labelled flag, degree, hops_to_leader, final_pred,
    `layout` = display-only 2-D layout in [-1,1], NOT a model output), `layout` (how it was made), `edges[]` = `[member_a, member_b, a_hat_weight]` (A-hat entry, symmetric) and `self_weights[]`
    (A-hat diagonal): the per-layer message weights; they are constant during training, so they are stored once.
  - `epochs` = global per-epoch arrays (`index`, `t_s`, `loss_train`, `loss_all34`, `accuracy_all34`, `accuracy_unlabelled32`, `grad_norm`); `thresholds.undecided_margin` = display rule
    (|P - 0.5| below it is drawn neutral); `emb_axis_max`; `final` (accuracy, confusion, wrong members with their friend split, accuracy by hops to a leader).
  - `monitor` (edge-removal probe + draws), `seed_sweep` (+ `seed_rows`), `repeat` (same-seed retrain: identical hash, warm time), `beats` (derived epochs), `insights[]`:
    `{id, title, text, numbers, at}`; `text` is filled from the run, every number in it is repeated in `numbers`, `at` = where it plays (`stage_from/stage_to`, optional `epoch_from/epoch_to`
    inside the train stage, optional `part` = fractions of the stage window).
- Playback of this kind of trace is STRETCHED by the scene (each stage a fixed slot, epochs evenly spaced inside the train slot); the real times stay in the trace and are printed on the scene.
- Tooling note: `scripts/scene/audit_numbers.py` assumes every entity series has `v` (KeyError otherwise); for this kind of trace use `scripts/gnn/audit_numbers_gnn.py`, which reads any numeric series key.
