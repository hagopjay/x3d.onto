# trace-pipeline: data-system runs as animated X3D scenes

A shared JSON contract (`TRACE_SCHEMA.md`, x3d-trace/1) turns the run of a data system into an animated 3D scene (Blender + the x3d_blender_io fork, validated with x3d_mcp, checked in X_ITE). Honesty rules: `source.synthetic` is never omitted, every number on a scene comes from the trace, nothing is invented at render time, every scene carries a REAL DATA or SYNTHETIC plate.

| Area | Where | One command |
|---|---|---|
| Generic trace -> scene builder, Kafka (synthetic) and BigQuery (real) | `scripts/scene/`, `scripts/adapters/` | `scripts/scene/run_all.sh` |
| Stage 1: karate-club GNN inside a real MLOps pipeline | `scripts/gnn/` | `scripts/gnn/run_all.sh` |
| Stage 2 (thin, static): Kubernetes blueprint analysis (SYNTHETIC) | `scripts/infra/`, `blueprints/` | `scripts/infra/run_all.sh` |
| The X3D flywheel showcase (real toolchain loop, tether, evidence) | `scripts/flywheel/` | `scripts/flywheel/iterate.sh quick` (about 30 s) or `full`; `scripts/flywheel/run_all.sh` (everything) |

Flywheel iteration: every real loop run is saved in `out/flywheel/runs/`, summarised in `out/flywheel/history.json` with the git commit it ran on, and `scripts/flywheel/history.py` prints the delta against the previous run. `scripts/flywheel/make_gif.py` records the scene as a GIF.

Conventions: commits are small and described; regenerable output lives in `out/` (ignored, except the `*.md` notes); raw BigQuery job files and the ledger are not tracked (they contain an account email and project id); some folders in the working tree belong to other sessions (`scripts/anatomy`, `out/anatomy`, `out/x3dom-fun`, `out/scene`) and are intentionally left untracked here. Nothing is pushed anywhere by these scripts.
