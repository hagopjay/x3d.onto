# X3D-TRACE-SCENE-PROFILE 0.1 (draft)
A profile for turning an `x3d-trace/1` run (TRACE_SCHEMA.md) into an X3D 4.0 scene. MUST / SHOULD as in RFC 2119. Node and field facts below are x3d_mcp's own `describe_node` / `list_profiles` output (out/anatomy/spec-facts.json); every rule says how it is checked.

## 1 Profile and components (R01, R04, R05)
A conforming scene MUST declare `<X3D version="4.0" profile="Immersive">` and `<component name="Shape" level="2"/>` (PhysicalMaterial is Shape level 2 and is in no profile but Full). The declaration MUST cover the nodes used, as inferred with `describe_node` + `list_profiles` and confirmed by the server's `validate_semantic` (profile-component). Every parent/containerField/child MUST be licensed by `node_parents`.

| node | component | level | in Immersive | first fields (type, access) |
|---|---|---|---|---|
| Transform | Grouping | 1 | yes | translation SFVec3f inputOutput, rotation SFRotation inputOutput, scale SFVec3f inputOutput |
| Shape | Shape | 1 | yes | appearance SFNode inputOutput, geometry SFNode inputOutput |
| Appearance | Shape | 1 | yes | material SFNode inputOutput |
| UnlitMaterial | Shape | 1 | NO (needs a component statement) | emissiveColor SFColor inputOutput, transparency SFFloat inputOutput |
| PhysicalMaterial | Shape | 2 | NO (needs a component statement) | baseColor SFColor inputOutput, emissiveColor SFColor inputOutput, roughness SFFloat inputOutput |
| IndexedFaceSet | Geometry3D | 2 | yes | coordIndex MFInt32 initializeOnly, solid SFBool initializeOnly, coord SFNode inputOutput |
| Coordinate | Rendering | 1 | yes | point MFVec3f inputOutput |
| Text | Text | 1 | yes | string MFString inputOutput, fontStyle SFNode inputOutput |
| FontStyle | Text | 1 | yes | size SFFloat inputOutput, justify MFString inputOutput, family MFString inputOutput |
| Billboard | Navigation | 2 | yes | axisOfRotation SFVec3f inputOutput, children MFNode inputOutput |
| TimeSensor | Time | 1 | yes | cycleInterval SFTime inputOutput, loop SFBool inputOutput, enabled SFBool inputOutput |
| PositionInterpolator | Interpolation | 1 | yes | key MFFloat inputOutput, keyValue MFVec3f inputOutput, set_fraction SFFloat inputOnly |
| Viewpoint | Navigation | 1 | yes | position SFVec3f inputOutput, orientation SFRotation inputOutput, description SFString inputOutput |
| NavigationInfo | Navigation | 1 | yes | type MFString inputOutput, headlight SFBool inputOutput |
| Background | EnvironmentalEffects | 1 | yes | skyColor MFColor inputOutput |
| DirectionalLight | Lighting | 1 | yes | direction SFVec3f inputOutput, intensity SFFloat inputOutput, global SFBool inputOutput |

Inference result (infer_profile.py): the three exporter scenes declare exactly the least-privilege answer (Immersive + Shape:2); the x3d_mcp-authored companion declares Interchange + Shape:2 + Text:1 where Immersive + Shape:2 would need one statement fewer; all ontology containments licensed.

## 2 Naming (R06, R07)
DEF names MUST be unique and use the exporter scheme `OB_` object (Transform), `ME_` mesh, `MA_` material, `APP_` appearance, `CA_` camera (Viewpoint, `CA_VP<n>_<name>`), `LA_` light, `PI_`/`SI_` position/scale interpolator of `OB_<n>`, the single clock `SceneTimer`; content authored with x3d_mcp and merged in MUST use `XM_`.

## 3 Animation (R08-R10, R21)
Exactly one `TimeSensor` DEF `SceneTimer` (loop true, cycleInterval = (frames-1)/fps). Motion MUST be PositionInterpolators (translation and scale) fed by `SceneTimer.fraction_changed` into `set_fraction` and routed to the Transform; no Script, Proto or Inline. Keys non-decreasing in [0,1]; keyValue length = 3 x keys. The exported motion MUST equal the trace-driven tracks at every frame within 1e-3.

## 4 Honesty labels (R11-R16)
`source.synthetic` is mandatory. The wall banner and a floor banner MUST read `SYNTHETIC` or `REAL DATA` exactly as the trace says; a CAVEATS block MUST carry every trace note; a MAPPING block MUST say what each size, colour and height means; a non-second time unit MUST be stated; every number on the scene MUST be in the trace, a documented mapping constant, a date/provenance string, or quoted from the trace; head meta MUST name the run.

## 5 Budget and robustness (R17-R20, R22)
File <= 900 KB; self-contained (no url, Inline, texture); >= 3 named viewpoints, first the overview; renders in X_ITE 16.4.3 without console errors, >= 3 non-blank screenshots differing pairwise; the trace satisfies the x3d-trace/1 contract.

## 6 Checklist and conformance (scenes/*.x3d)
| rule | checked by | kafka-gossip | bq-wikipedia | x3d-mcp-anatomy | x3d-mcp-anatomy-overlay |
|---|---|---|---|---|---|
| R01 Header: X3D 4.0 (or 4.1 for an x3d_mcp companion), a profile, and component statements so that no node lies outside profile+components | x3d_mcp validate_semantic (profile-component) | PASS | PASS | PASS | PASS |
| R02 XML Schema valid | x3d_mcp validate_x3d | PASS | PASS | PASS | PASS |
| R03 Semantic check: 0 errors and 0 warnings (info allowed) | x3d_mcp validate_semantic | PASS | PASS | PASS | PASS |
| R04 Declared profile + components cover what the content needs (inferred from the nodes via describe_node / list_profiles; the server's own check agrees on every probe) | x3d_mcp describe_node + list_profiles + validate_semantic (infer_profile.py) | PASS | PASS | PASS | PASS |
| R05 Every parent / containerField / child triple is licensed by the ontology | x3d_mcp node_parents (infer_profile.py) | PASS | PASS | PASS | PASS |
| R06 DEF names: unique, and OB_ ME_ MA_ APP_ CA_ LA_ PI_ SI_ (exporter), XM_ (x3d_mcp-authored overlay) or SceneTimer | script (check_profile.py) | PASS | PASS | PASS | PASS |
| R07 Every PI_<n> / SI_<n> interpolator has its OB_<n> transform | script (check_profile.py) | PASS | PASS | PASS | PASS |
| R08 Exactly one TimeSensor, DEF SceneTimer, loop=true, cycleInterval = playback seconds of the build | script (check_profile.py) | PASS | PASS | PASS | n/a |
| R09 No Script / Inline / Proto; every ROUTE end exists; each interpolator is fed by SceneTimer.fraction_changed once and drives a field | script (check_profile.py) | PASS | PASS | PASS | PASS |
| R10 Interpolator keys non-decreasing in [0,1] and keyValue length matches key count | x3d_mcp validate_semantic (interpolator-key-length) + script | PASS | PASS | PASS | PASS |
| R11 Source plate: wall banner and floor banner say REAL DATA or SYNTHETIC exactly as trace.source.synthetic | script (check_profile.py) | PASS | PASS | PASS | n/a |
| R12 Caveat legend present and carries every trace note | script (check_profile.py) | PASS | PASS | PASS | n/a |
| R13 Mapping legend present (what each size / colour / height means) | script (check_profile.py) | PASS | PASS | PASS | n/a |
| R14 A trace time unit other than seconds is stated in the scene | script (check_profile.py) | n/a | n/a | PASS | n/a |
| R15 Every number on the scene is in the trace, a mapping constant of the legend, a date / provenance string, or quoted from the trace | script (audit logic of scripts/scene/audit_numbers.py + classes) | PASS | PASS | PASS | n/a |
| R16 Head meta: title and description naming the trace run | script (check_profile.py) | PASS | PASS | PASS | n/a |
| R17 File size <= 900 KB | script (check_profile.py) | PASS | PASS | PASS | PASS |
| R18 Self-contained: no url= / Inline / texture or media references | script (check_profile.py) | PASS | PASS | PASS | PASS |
| R19 At least three named viewpoints CA_VP<n>_<name>, each with a description; the first is the overview | script (check_profile.py) | PASS | PASS | PASS | n/a |
| R20 X_ITE 16.4.3 renders it with no console errors; >= 3 non-blank screenshots differing pairwise | script (render_check.js / render_views.js + image_stats.py, stored results) | PASS | PASS | PASS | n/a |
| R21 Exported motion equals the trace-driven tracks at every frame (tolerance 1e-3) | script (verify_x3d_motion.py / verify_anatomy_motion.py) | PASS | PASS | PASS | n/a |
| R22 The trace file satisfies the x3d-trace/1 contract | script (check_profile.py: check_trace) | PASS | PASS | PASS | n/a |

Negative controls (a mutated copy of the anatomy scene must fail exactly the named rule):

| rule | mutation | result |
|---|---|---|
| R11 | wall/floor banners relabelled SYNTHETIC on a REAL trace | caught (FAIL) |
| R09 | a Script node inserted | caught (FAIL) |
| R06 | a DEF outside the naming scheme | caught (FAIL) |
| R08 | cycleInterval changed | caught (FAIL) |
| R10 | interpolator keys out of order | caught (FAIL) |
| R15 | an invented number on a label | caught (FAIL) |
| R17 | padded beyond 900 KB | caught (FAIL) |
| R18 | an external texture reference | caught (FAIL) |
| R19 | viewpoint without description | caught (FAIL) |

Notes: R15 classes unmatched numbers (legend constants, dates, quoted labels); R20 for the anatomy scene uses the growth close-up series (the overview series changes only 0.2-0.5 % of pixels, below the stock 0.2 % pairwise threshold for one pair); R21 tolerance is 1e-3 (the anatomy gauges reach 5.9e-4, above the stock verifier's 5e-4).

## 7 Findings about x3d_mcp itself
Live A/B of upstream/main (ff0c0c94) against the fork (fa0b3899), same virtualenv, same calls (10 fork fixes, 6 same, 0 regressions):

| test | upstream/main | fork | verdict |
|---|---|---|---|
| X-05 get_scene writes DEF before USE (RigidBodyCollection built in granular mode) | DEF at 544, first USE at 404 -> USE BEFORE DEF | DEF at 373, first USE at 466 -> DEF first | fork fixes/adds |
| X-05 validate_semantic names USE-before-DEF | shape-no-appearance,shape-no-geometry,use-before-def | use-before-def | same |
| X-05 repair_x3d puts DEF before USE: siblings in different containerFields (RigidBodyCollection joints before bodies) | Unknown tool: repair_x3d | DEF now first; changes=3 | fork fixes/adds |
| X-05 repair_x3d puts DEF before USE: DEF and USE under different parents | Unknown tool: repair_x3d | unchanged (changes=0, unfixable=1) | same |
| X-06 convert_x3d keeps PhysicalMaterial.baseTexture (xml->vrml) | texture not under baseTexture: #VRML V4.0 utf8 | 'baseTexture ImageTexture' in output | fork fixes/adds |
| X-06 convert_x3d keeps MatrixTransform.matrix (xml->xml) | node silently DROPPED (Scene has no MatrixTransform) | node silently DROPPED (Scene has no MatrixTransform) | same |
| X-07 convert_x3d to json returns parseable JSON | json.loads FAILS (e.g. '"X3D":,' ) | json.loads FAILS (e.g. '"X3D":,' ) | same |
| X-08 set_field('on','false') reaches the XML | attribute missing from XML (silently dropped) | on=false in XML | fork fixes/adds |
| X-13 set_field refuses an outputOnly field | Set isActive on 8366edb7-8264-4e55-a896-321b8a860492 | Error executing tool set_field: TimeSensor.isActive is outputOnly and cannot be  | fork fixes/adds |
| X-09/X-10 validate_semantic flags physics defects (mass<=0, zero axis, zero orientation) | containerfield-type-mismatch,shape-no-appearance,unused-def | containerfield-type-mismatch,physics-mass,physics-zero-axis,shape-no-appearance, | fork fixes/adds |
| profile-component check (Text under Interchange) | clean | profile-component,profile-component-fix | fork fixes/adds |
| tuple-count check (Coordinate.point not a multiple of 3) | clean | tuple-count | fork fixes/adds |
| dead-boolean-route check | unused-def | route-never-fires | fork fixes/adds |
| create_scene returns an XSD-valid document | INVALID: Line 3: Element 'X3D': Missing child element(s). Expected is ( Scene ). | INVALID: Line 3: Element 'X3D': Missing child element(s). Expected is ( Scene ). | same |
| negative Box size is rejected by some level (L1-L4) | accepted by all of L1-L4 (create_geometry, validate_x3d, validate_semantic) | accepted by all of L1-L4 (create_geometry, validate_x3d, validate_semantic) | same |
| tool surface: repair_x3d is listed | 34 tools; repair_x3d absent | 35 tools; repair_x3d listed | fork fixes/adds |

Still open in the fork (evidence in out/anatomy/validation/*.json, ab-fork-fixes.json, tool-classification.json):
1. `convert_x3d` crashes on every exporter scene (`DirectionalLight.__init__() got an unexpected keyword argument 'global'`); after stripping `global`, XML->XML keeps all nodes, DEF, USE, ROUTE; only defaults are omitted.
2. `convert_x3d` silently drops `MatrixTransform` subtrees (upstream and fork); its JSON output is not parseable JSON (`"X3D":,`, deferred X-07); reading ClassicVRML or JSON back is not supported, unlike the paper's "XML <-> ClassicVRML <-> JSON".
3. `create_scene` returns a document that fails the XSD (no `<Scene>`); a Box with negative size passes all four levels: validation is not on the return path of the creation tools, unlike the paper's claim.
4. Failures are reported in-band (plain text or `{"error":...}`) without the MCP `isError` flag: 18 of 76 tape failures.
5. `repair_x3d` reorders sibling DEF/USE only; a USE before its DEF under another parent is reported unfixable.
6. `list_nodes` knows 267 nodes, the ontology graph 260: EnvironmentLight, FontLibrary, GaussianSplats, HAnimPose, InlineGeometry, RenderedTexture, Tangent are missing from `node_parents` / `describe_ontology_term`.
7. `render_image` / `render_current_scene` need Playwright (not in the venv); granular MF fields need nested lists, XML strings are rejected.
8. Paper vs code: 28 tools = upstream main line 2026-05-04..2026-08-04; upstream main has 34, the fork 35 (only `repair_x3d` is fork-added); 10 modules vs 9; 19 -> 36 semantic rule ids vs "six classes".
Tape: 1314 calls, 35 of 35 tools used before the coverage sweep completes, 76 not ok (49 unexpected, causes in out/anatomy/tape-stats.json).
