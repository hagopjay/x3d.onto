"""Zachary's karate club: the dataset, embedded as literals (no download).

Citation: W. W. Zachary, "An information flow model for conflict and fission in small groups",
Journal of Anthropological Research 33(4), 452-473 (1977). 34 members of a university karate club, 78 friendships
(unweighted version, as distributed by Newman's karate.gml and networkx.karate_club_graph), and the two factions the club
really split into after a dispute between the instructor ("Mr. Hi", member 1) and the club president ("the Officer", member 34).

Provenance of THIS copy: typed in from the standard published edge list (no network access is used or needed).
It is cross-checked by validate_dataset() in pipeline.py: 34 nodes, 78 edges, symmetric, no self-loops, connected,
17 + 17 faction split, and the published degree sequence (PUBLISHED_DEGREES below, sum 156 = 2 x 78).
Members are numbered 1..34 as in the paper; arrays are 0-indexed (member k is row k-1).
"""
import hashlib
import json

N = 34
# member -> its friends with a HIGHER number (each friendship appears exactly once)
FORWARD = {
    1: [2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 18, 20, 22, 32],
    2: [3, 4, 8, 14, 18, 20, 22, 31],
    3: [4, 8, 9, 10, 14, 28, 29, 33],
    4: [8, 13, 14],
    5: [7, 11],
    6: [7, 11, 17],
    7: [17],
    9: [31, 33, 34],
    10: [34],
    14: [34],
    15: [33, 34],
    16: [33, 34],
    19: [33, 34],
    20: [34],
    21: [33, 34],
    23: [33, 34],
    24: [26, 28, 30, 33, 34],
    25: [26, 28, 32],
    26: [32],
    27: [30, 34],
    28: [34],
    29: [32, 34],
    30: [33, 34],
    31: [33, 34],
    32: [33, 34],
    33: [34],
}
EDGES = [(a, b) for a in sorted(FORWARD) for b in FORWARD[a]]          # 1-indexed pairs, a < b

# published degree of member 1..34 (used only as a cross-check of the typed-in edge list)
PUBLISHED_DEGREES = [16, 9, 10, 6, 3, 4, 4, 4, 5, 2, 3, 1, 2, 5, 2, 2, 2, 2, 2, 3, 2, 2, 2, 5, 3, 3, 2, 4, 3, 4, 4, 6, 12, 17]

# the real split: faction 0 = Mr. Hi's club, faction 1 = the Officer's club
MR_HI = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 17, 18, 20, 22]
FACTION_NAMES = ["Mr. Hi", "Officer"]
LEADERS = {1: 0, 34: 1}                 # member -> faction: the only two labels the model is allowed to see


def factions():
    """Faction (0 = Mr. Hi, 1 = Officer) of members 1..34 as a list indexed by member-1."""
    return [0 if m in set(MR_HI) else 1 for m in range(1, N + 1)]


def edge_list_0idx():
    return [(a - 1, b - 1) for a, b in EDGES]


def canonical_bytes():
    """The dataset as canonical UTF-8 JSON (sorted keys, no spaces): what the ingest stage hashes and writes."""
    doc = {"name": "zachary-karate-club-1977", "n_members": N, "edges_1idx": [list(e) for e in EDGES],
           "faction_of_member_1idx": factions(), "faction_names": FACTION_NAMES,
           "citation": "W. W. Zachary, J. Anthropological Research 33(4):452-473 (1977)"}
    return json.dumps(doc, sort_keys=True, separators=(",", ":")).encode("utf-8")


def dataset_sha256():
    return hashlib.sha256(canonical_bytes()).hexdigest()
