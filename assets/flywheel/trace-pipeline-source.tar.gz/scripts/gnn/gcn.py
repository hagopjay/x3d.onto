"""A 2-layer graph convolutional network (Kipf & Welling, ICLR 2017) in plain numpy, with hand-derived gradients.

    A_hat  = D^-1/2 (A + I) D^-1/2                       (each member averages itself and its friends; weights are fixed)
    Z1     = A_hat X W0        H1 = ReLU(Z1)             (layer 1: gather friends' feature rows, transform, ReLU)
    Z2     = A_hat H1 W1       P  = softmax(Z2)          (layer 2: gather friends' hidden vectors, transform, vote)
    loss   = mean cross-entropy over the LABELLED members  +  wd/2 * ||W0||^2        (semi-supervised: only labelled rows count)

Backward pass (A_hat is symmetric):
    dZ2 = (P - Y) / n_labelled on labelled rows, 0 elsewhere     dW1 = (A_hat H1)^T dZ2
    dH1 = A_hat dZ2 W1^T                                         dZ1 = dH1 * [Z1 > 0]        dW0 = (A_hat X)^T dZ1 + wd W0
The finite-difference check of exactly these formulas lives in test_gnn.py.

Training is plain full-batch gradient descent. Everything is float64 and seeded, so the same seed gives the same weights.
"""
import time

import numpy as np


def normalized_adjacency(A):
    """A_hat = D^-1/2 (A + I) D^-1/2 for a symmetric 0/1 adjacency matrix A."""
    At = A + np.eye(A.shape[0])
    d = At.sum(axis=1)
    dm = 1.0 / np.sqrt(d)
    return dm[:, None] * At * dm[None, :]


def init_params(n_feat, hidden, n_classes, seed):
    """Glorot-uniform weights from a seeded generator."""
    rng = np.random.default_rng(seed)
    g = lambda i, o: rng.uniform(-1.0, 1.0, size=(i, o)) * np.sqrt(6.0 / (i + o))
    return {"W0": g(n_feat, hidden), "W1": g(hidden, n_classes)}


def softmax(Z):
    E = np.exp(Z - Z.max(axis=1, keepdims=True))
    return E / E.sum(axis=1, keepdims=True)


def forward(params, Ahat, X):
    AX = Ahat @ X
    Z1 = AX @ params["W0"]
    H1 = np.maximum(Z1, 0.0)
    AH1 = Ahat @ H1
    Z2 = AH1 @ params["W1"]
    return {"AX": AX, "Z1": Z1, "H1": H1, "AH1": AH1, "Z2": Z2, "P": softmax(Z2)}


def cross_entropy(P, y, rows):
    return float(-np.mean(np.log(P[rows, y[rows]] + 1e-300)))


def loss_and_grads(params, Ahat, X, y, train_rows, wd=0.0, cache=None):
    """Objective (cross-entropy on the labelled rows + L2 on W0) and its analytic gradients."""
    c = cache if cache is not None else forward(params, Ahat, X)
    n_cls = c["P"].shape[1]
    Y = np.zeros_like(c["P"])
    Y[train_rows, y[train_rows]] = 1.0
    nl = float(len(train_rows))
    dZ2 = np.zeros_like(c["P"])
    dZ2[train_rows] = (c["P"][train_rows] - Y[train_rows]) / nl
    dW1 = c["AH1"].T @ dZ2
    dH1 = Ahat @ dZ2 @ params["W1"].T
    dZ1 = dH1 * (c["Z1"] > 0.0)
    dW0 = c["AX"].T @ dZ1 + wd * params["W0"]
    loss = cross_entropy(c["P"], y, train_rows) + 0.5 * wd * float(np.sum(params["W0"] ** 2))
    return loss, {"W0": dW0, "W1": dW1}, c


def predict(params, Ahat, X):
    c = forward(params, Ahat, X)
    return c["P"].argmax(axis=1), c["P"], c


def accuracy(pred, y, rows=None):
    rows = np.arange(len(y)) if rows is None else rows
    return float(np.mean(pred[rows] == y[rows]))


def snapshot(params, Ahat, X, y, train_rows, unl, wd, cache, t_wall):
    """Everything logged for one epoch (the state of the model BEFORE the next gradient step)."""
    P, n = cache["P"], len(y)
    pred = P.argmax(axis=1)
    msg2 = cache["H1"] @ params["W1"]                               # what each member SENDS in layer 2 (before the A_hat weights)
    loss = cross_entropy(P, y, train_rows) + 0.5 * wd * float(np.sum(params["W0"] ** 2))
    return {
        "loss_train": loss,                                          # the objective that is minimised (labelled rows + L2)
        "loss_all": cross_entropy(P, y, np.arange(n)),               # cross-entropy over all 34 (never used for training)
        "acc_all": accuracy(pred, y),
        "acc_unlabelled": accuracy(pred, y, unl),
        "emb": cache["H1"].copy(),                                   # (34, hidden): the hidden layer, post-ReLU = the embedding
        "p_officer": P[:, 1].copy(),
        "vote": (msg2[:, 1] - msg2[:, 0]).copy(),                    # layer-2 message of each member: Officer-minus-Mr.Hi logit contribution
        "pred": pred.copy(),
        "t_wall_s": t_wall,
    }


def train(Ahat, X, y, train_rows, *, hidden=2, seed=0, lr=0.5, epochs=200, wd=5e-4, log=True, clock=time.perf_counter):
    """Full-batch gradient descent. Returns (params, history). history[e] is the state after e updates (e = 0 is the untrained model)."""
    params = init_params(X.shape[1], hidden, int(y.max()) + 1, seed)
    init = {k: v.copy() for k, v in params.items()}
    unl = np.setdiff1d(np.arange(len(y)), train_rows)
    hist, t0 = [], clock()
    for e in range(epochs + 1):
        loss, grads, cache = loss_and_grads(params, Ahat, X, y, train_rows, wd)
        if log:
            now = clock()
            rec = snapshot(params, Ahat, X, y, train_rows, unl, wd, cache, now - t0)
            rec["epoch"], rec["t_abs"] = e, now
            rec["grad_norm"] = float(np.sqrt(sum(float(np.sum(g * g)) for g in grads.values())))
            hist.append(rec)
        if e < epochs:
            for k in params:
                params[k] = params[k] - lr * grads[k]
    return params, init, hist
