#!/usr/bin/env python3
"""Audit: every number that appears in a Text node of the GNN scene must be (a) a value found in the trace, or (b) one of a few DERIVED kinds that
are computed from the trace by the scene and listed here: axis tick labels / epoch ticks (scale marks), playback seconds and the stretch factor
(display time), hash prefixes (strings, digits only), card counters. Anything else is reported as UNEXPLAINED.
usage: python3 scripts/gnn/audit_numbers_gnn.py TRACE.json SCENE.x3d     (exit 1 if anything is unexplained)"""
import json, math, re, sys


def leaves(o, out):
    if isinstance(o, bool) or o is None:
        return
    if isinstance(o, (int, float)):
        out.append(float(o))
    elif isinstance(o, dict):
        for v in o.values():
            leaves(v, out)
    elif isinstance(o, list):
        out.append(float(len(o)))
        for v in o:
            leaves(v, out)


def main(trace_path, x3d_path):
    tr = json.load(open(trace_path))
    vals = []
    leaves(tr, vals)
    for e in tr.get("entities", []):                       # maxima of per-entity series are not leaves of their own
        for lst in (e.get("series") or {}).values():
            if isinstance(lst, list) and lst and isinstance(lst[0], (int, float)):
                vals.append(float(max(lst)))
    strnums = []
    def strs(o):
        if isinstance(o, str):
            strnums.extend(float(x) for x in re.findall(r"(?<![\w.])\d+(?:\.\d+)?(?![\w])", o))
        elif isinstance(o, dict):
            [strs(v) for v in o.values()]
        elif isinstance(o, list):
            [strs(v) for v in o]
    strs(tr)                                                  # digits that live inside trace strings (years, versions, page numbers, notes)
    vals = sorted(set(vals) | set(strnums))
    hashes = set()
    def walk(o):
        if isinstance(o, str) and re.fullmatch(r"[0-9a-f]{16,}", o):
            hashes.add(o[:8])
        elif isinstance(o, dict):
            [walk(v) for v in o.values()]
        elif isinstance(o, list):
            [walk(v) for v in o]
    walk(tr)
    dur, pb = tr["time"]["duration"], None
    s = open(x3d_path, encoding="utf-8").read()
    texts = re.findall(r"<Text string='([^']*)'", s)
    derived = {"ticks": {0, 0.2, 0.4, 0.5, 0.6, 1, 100, 200}, "playback": None}
    m = re.search(r"playback (\d+) s = ([\d.]+) ms .*?\((\d+)x slower\)", " ".join(texts))
    n_match = n_derived = 0
    unexplained, kinds = [], {}
    for t in texts:
        for line in re.findall(r'"([^"]*)"', t):
            for mo in re.finditer(r"(?<![\w.])(-?\d{1,3}(?:,\d{3})+(?:\.\d+)?|-?\d+(?:\.\d+)?(?:e[+-]?\d+)?)(?![\w])", line):
                raw = mo.group(1).replace(",", "")
                v = float(raw)
                dec = len(raw.split(".")[1]) if "." in raw else 0
                tol = max(1e-9, 0.006 * abs(v), 0.5 * 10 ** -dec)
                if any(abs(x - v) <= tol for x in vals):
                    n_match += 1
                    continue
                why = None
                if v in derived["ticks"]:
                    why = "axis tick / scale mark"
                elif m and raw in m.groups():
                    why = "playback seconds, real ms and stretch factor (display time, from the trace duration)"
                elif any(h.startswith(raw) or raw in h for h in hashes) or re.search(r"sha [0-9a-f]*" + re.escape(raw), line):
                    why = "digits of a sha256 prefix (string)"
                elif re.search(r"%d/34|\d+/\d+ checks", line):
                    why = "count shown as n/34"
                elif re.search(r"(tube radius|block height|block depth) = ", line):
                    why = "scale range constant of the generic mapping legend (display)"
                elif "of playback" in line and raw == str(int(v)):
                    why = "playback seconds of the loop (display time)"
                elif v == 6.4 and "slow loops" in line:
                    why = "message-loop period of the animation (display constant)"
                if why:
                    n_derived += 1
                    kinds[why] = kinds.get(why, 0) + 1
                else:
                    unexplained.append((raw, line[:90]))
    print(json.dumps(dict(text_nodes=len(texts), matched_in_trace=n_match, derived_explained=n_derived, derived_kinds=kinds, unexplained=len(unexplained))))
    for raw, line in sorted(set(unexplained)):
        print("  UNEXPLAINED:", raw, "|", line)
    return 1 if unexplained else 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:3]))
