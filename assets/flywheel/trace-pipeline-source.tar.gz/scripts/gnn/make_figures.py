#!/usr/bin/env python3
"""Demo visuals that need no 3D viewer, drawn with PIL straight from traces/gnn-karate.trace.json (same rules as the X3D scene):
  out/gnn/embedding-migration.gif  animated: friendship network + embedding space + loss/accuracy curves, epoch by epoch (real per-epoch log)
  out/gnn/demo-sheet.png           small multiples of the embedding at six epochs + the training curves
colour = the model's guess (blue Mr. Hi, orange Officer, grey = undecided |P-0.5| < undecided margin), radius grows with confidence, ring = the TRUE faction.
usage: python3 scripts/gnn/make_figures.py [--trace T] [--out-dir D]"""
import argparse
import json
import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
BG, PANEL, GRID, TXT, DIM = (8, 10, 16), (16, 21, 32), (50, 62, 86), (232, 238, 246), (150, 165, 188)
HI, OFF, NEU = (46, 140, 255), (255, 133, 20), (150, 160, 178)


def font(size):
    for f in ("/System/Library/Fonts/Helvetica.ttc", "/System/Library/Fonts/Supplemental/Arial.ttf", "/Library/Fonts/Arial.ttf"):
        if os.path.exists(f):
            return ImageFont.truetype(f, size)
    return ImageFont.load_default()


class Data:
    def __init__(self, path):
        t = json.load(open(path))
        g = t["gnn"]
        self.t, self.g = t, g
        self.nodes, self.tau = g["nodes"], g["thresholds"]["undecided_margin"]
        ents = {e["id"]: e for e in t["entities"]}
        self.ex = np.array([ents["m%d" % n["id"]]["series"]["x"] for n in self.nodes])
        self.ey = np.array([ents["m%d" % n["id"]]["series"]["y"] for n in self.nodes])
        self.p = np.array([ents["m%d" % n["id"]]["series"]["p_officer"] for n in self.nodes])
        self.AM = math.ceil(g["emb_axis_max"] * 10) / 10
        ep = g["epochs"]
        self.loss, self.loss_all, self.acc = ep["loss_train"], ep["loss_all34"], ep["accuracy_all34"]
        self.E = ep["index"][-1]
        self.layout = np.array([n["layout"] for n in self.nodes])
        self.faction = [n["faction"] for n in self.nodes]
        self.edges = g["edges"]

    def belief(self, i, e):
        p = self.p[i, e]
        m = abs(p - 0.5)
        if m < self.tau:
            return NEU, 0.0
        return (OFF if p > 0.5 else HI), min(1.0, (m - self.tau) / (0.5 - self.tau))


def circle(d, c, r, fill=None, outline=None, width=1):
    d.ellipse([c[0] - r, c[1] - r, c[0] + r, c[1] + r], fill=fill, outline=outline, width=width)


def draw_nodes(layer, pts, D, e, r0, r1, ring):
    d = ImageDraw.Draw(layer, "RGBA")
    for i, c in enumerate(pts):
        col, conf = D.belief(i, e)
        circle(d, c, ring, outline=(OFF if D.faction[i] else HI) + (255,), width=2)
        circle(d, c, r0 + (r1 - r0) * conf, fill=col + (215,))


def panel(img, box, title, fn, f_small, f_title):
    d = ImageDraw.Draw(img, "RGBA")
    d.rectangle(box, fill=PANEL, outline=GRID)
    d.text((box[0] + 10, box[1] + 6), title, fill=TXT, font=f_title)
    fn(box)


def network(img, D, e, box, scale=1.0):
    x0, y0, x1, y1 = box
    cx, cy, hw, hh = (x0 + x1) / 2, (y0 + y1) / 2 + 8, (x1 - x0) / 2 - 24, (y1 - y0) / 2 - 30
    pts = [(cx + hw * l[0], cy + hh * l[1]) for l in D.layout]
    d = ImageDraw.Draw(img, "RGBA")
    for a, b, w in D.edges:
        d.line([pts[a - 1], pts[b - 1]], fill=(120, 140, 175, 140), width=max(1, int(round(1 + 12 * w * scale))))
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw_nodes(layer, pts, D, e, 5 * scale, 11 * scale, 13 * scale)
    img.alpha_composite(layer)


def embedding(img, D, e, box, scale=1.0):
    x0, y0, x1, y1 = box
    ox, oy, W, H = x0 + 34, y1 - 30, (x1 - x0) - 54, (y1 - y0) - 56
    d = ImageDraw.Draw(img, "RGBA")
    d.line([(ox, oy), (ox + W, oy)], fill=HI + (255,), width=3)
    d.line([(ox, oy), (ox, oy - H)], fill=OFF + (255,), width=3)
    f = font(int(11 * scale + 3))
    for v in (0.5, 1.0):
        if v <= D.AM:
            d.text((ox + v / D.AM * W - 8, oy + 5), "%g" % v, fill=DIM, font=f)
            d.text((ox - 28, oy - v / D.AM * H - 7), "%g" % v, fill=DIM, font=f)
    d.text((ox + W - 95 * scale, oy - 22 * scale), "hidden unit 1", fill=HI, font=f)
    d.text((ox + 8, oy - H + 2), "hidden unit 2", fill=OFF, font=f)
    pts = [(ox + D.ex[i, e] / D.AM * W, oy - D.ey[i, e] / D.AM * H) for i in range(len(D.nodes))]
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw_nodes(layer, pts, D, e, 4 * scale, 9 * scale, 11 * scale)
    img.alpha_composite(layer)


def curves(img, D, e, box):
    x0, y0, x1, y1 = box
    d = ImageDraw.Draw(img, "RGBA")
    f = font(12)
    ox, oy, W, H = x0 + 36, y1 - 24, (x1 - x0) - 56, (y1 - y0) - 44
    d.line([(ox, oy), (ox + W, oy)], fill=DIM + (255,), width=1)
    d.line([(ox, oy), (ox, oy - H)], fill=DIM + (255,), width=1)
    d.text((ox, oy + 4), "epoch 0", fill=DIM, font=f)
    d.text((ox + W - 52, oy + 4), "epoch %d" % D.E, fill=DIM, font=f)
    for series, ymax, col, label in ((D.loss, 0.7, (255, 210, 64), "training loss (2 labelled members)"), (D.loss_all, 0.7, (190, 140, 255), "loss over all 34 (never trained on)"),
                                     (D.acc, 1.0, (90, 240, 140), "accuracy over all 34")):
        pts = [(ox + k / D.E * W, oy - min(v, ymax) / ymax * H) for k, v in enumerate(series)]
        d.line(pts[:e + 1] if e > 0 else pts[:2], fill=col + (255,), width=3)
        d.line(pts, fill=col + (60,), width=1)
        circle(d, pts[e], 5, fill=col + (255,))
    for j, (col, label) in enumerate((((255, 210, 64), "training loss (2 labelled members)"), ((190, 140, 255), "loss over all 34 (never trained on)"), ((90, 240, 140), "accuracy over all 34 (0 to 1)"))):
        d.text((ox + W * 0.5, oy - H * 0.72 + 15 * j), label, fill=col, font=f)


def frame(D, e, size=(800, 450)):
    img = Image.new("RGBA", size, BG + (255,))
    W, H = size
    f_t, f_s = font(15), font(12)
    d = ImageDraw.Draw(img, "RGBA")
    ok = int(round(D.acc[e] * len(D.nodes)))
    d.text((14, 9), "Tiny GNN, Zachary's karate club (REAL DATA, real training) | epoch %d/%d | %d of 34 right | loss %.3g" % (e, D.E, ok, D.loss[e]), fill=TXT, font=font(14))
    m = 10
    top, hmid = 34, int((H - 34 - 3 * m) * 0.64)
    boxes = [(m, top, W // 2 - m // 2, top + hmid), (W // 2 + m // 2, top, W - m, top + hmid), (m, top + hmid + m, W - m, H - m - 12)]
    panel(img, boxes[0], "friendship network: inner colour = guess, ring = truth", lambda b: network(img, D, e, b), f_s, f_s)
    panel(img, boxes[1], "embedding space = the 2 hidden units", lambda b: embedding(img, D, e, b), f_s, f_s)
    panel(img, boxes[2], "training curves", lambda b: curves(img, D, e, b), f_s, f_s)
    d.text((14, H - 15), "blue = Mr. Hi, orange = Officer, grey = undecided; members 1 and 34 are the only labels the model sees", fill=DIM, font=font(11))
    return img.convert("RGB")


def sheet(D, path):
    epochs = [0, 10, 30, 60, 100, D.E]
    cw, ch = 560, 440
    W, H = 3 * cw + 40, 2 * ch + 90 + 300
    img = Image.new("RGBA", (W, H), BG + (255,))
    d = ImageDraw.Draw(img, "RGBA")
    d.text((16, 10), "Zachary's karate club (REAL DATA): a 2-layer GCN trained from scratch, only members 1 and 34 labelled. Embedding after selected epochs.", fill=TXT, font=font(20))
    for k, e in enumerate(epochs):
        r, c = divmod(k, 3)
        box = (10 + c * (cw + 10), 44 + r * (ch + 10), 10 + c * (cw + 10) + cw, 44 + r * (ch + 10) + ch)
        ok = int(round(D.acc[e] * len(D.nodes)))
        panel(img, box, "epoch %d: %d of 34 right, loss %.3g" % (e, ok, D.loss[e]), lambda b, e=e: embedding(img, D, e, (b[0], b[1] + 20, b[2], b[3]), 1.5), font(14), font(18))
    cbox = (10, 44 + 2 * (ch + 10), W - 10, H - 40)
    panel(img, cbox, "training curves over %d epochs" % D.E, lambda b: curves(img, D, D.E, b), font(14), font(18))
    d.text((16, H - 30), "blue = Mr. Hi, orange = Officer, grey = undecided (|P-0.5| < %.2f); size = confidence; ring = the true faction. Axes: hidden-unit activations, no projection." % D.tau,
           fill=DIM, font=font(14))
    img.convert("RGB").save(path)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace", default=os.path.join(ROOT, "traces", "gnn-karate.trace.json"))
    ap.add_argument("--out-dir", default=os.path.join(ROOT, "out", "gnn"))
    a = ap.parse_args(argv)
    D = Data(a.trace)
    os.makedirs(a.out_dir, exist_ok=True)
    sheet(D, os.path.join(a.out_dir, "demo-sheet.png"))
    eps = sorted(set(int(round(x)) for x in np.linspace(0, D.E, 56)))
    frames = [frame(D, e).quantize(colors=64, method=Image.Quantize.MEDIANCUT) for e in eps]
    dur = [70] * len(frames)
    dur[0], dur[-1] = 900, 2500
    frames[0].save(os.path.join(a.out_dir, "embedding-migration.gif"), save_all=True, append_images=frames[1:], duration=dur, loop=0, optimize=True, disposal=2)
    for name in ("demo-sheet.png", "embedding-migration.gif"):
        print("wrote %s (%.0f KB)" % (name, os.path.getsize(os.path.join(a.out_dir, name)) / 1024))
    frame(D, 120).save(os.path.join(a.out_dir, "demo-frame-e120.png"))


if __name__ == "__main__":
    main()
