#!/bin/bash
# STAGE 1 end to end: real run -> trace -> scene -> every check. Everything is regenerated; nothing is downloaded (numpy + the local tools only).
#   scripts/gnn/run_all.sh [--no-render] [--no-regression]
# Writes: out/gnn/run.json, out/gnn/registry/, out/gnn/artifacts/, traces/gnn-karate.trace.json, scenes/gnn-karate.x3d|.blend, out/gnn/*.png|gif, out/gnn/checks.log
# Needs: python3 + numpy + pytest + Pillow, Blender 5.1 with the x3d_blender_io add-on, the x3d_mcp venv, node + playwright (NODE_PATH), a local Chromium and the pinned
# X_ITE 16.4.3 dist (see scripts/scene/run_all.sh for how to fetch it once). Commits nothing, touches no git repository, does not touch a running Blender.
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
BLENDER=${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}
MCPPY=${MCPPY:-$HOME/Projects/x3d/x3d_mcp/.venv/bin/python}
export NODE_PATH=${NODE_PATH:-/tmp/node_modules}
export CHROME_PATH=${CHROME_PATH:-$HOME/Library/Caches/ms-playwright/chromium-1155/chrome-mac/Chromium.app/Contents/MacOS/Chromium}
export XITE_DIST=${XITE_DIST:-/tmp/xite-pack/pkg/package/dist}
RENDER=1; REGR=1
for a in "$@"; do case "$a" in --no-render) RENDER=0;; --no-regression) REGR=0;; esac; done
mkdir -p out/gnn scenes traces; LOG=out/gnn/checks.log; : > $LOG
rm -rf out/gnn/registry out/gnn/artifacts
step() { echo "=== $1" | tee -a $LOG; }
step "1 pipeline: ingest, validate, split, train, evaluate, register, serve, monitor (real run)"
python3 scripts/gnn/pipeline.py 2>&1 | cut -c1-230 | tee -a $LOG
step "2 adapter: run.json -> traces/gnn-karate.trace.json (+ out/gnn/INSIGHTS.md)"
python3 scripts/adapters/gnn_to_trace.py 2>&1 | tee -a $LOG
step "3 tests (gradient check, determinism, registry round trip, trace schema, scene model, Blender live sandbox)"
python3 -m pytest -q scripts/gnn/test_gnn.py 2>&1 | tail -3 | tee -a $LOG
step "4 compatibility: the UNMODIFIED generic builder still accepts the extended trace"
mkdir -p out/gnn/generic-test
$BLENDER -b --factory-startup -noaudio --python scripts/scene/trace_to_scene.py -- --trace traces/gnn-karate.trace.json --out-x3d out/gnn/generic-test/gnn-generic.x3d --report-json out/gnn/generic-test/report.json 2>&1 | grep -E "RESULT|Error|Traceback" | tee -a $LOG
step "5 scene build: scenes/gnn-karate.x3d (+ .blend)"
$BLENDER -b --factory-startup -noaudio --python scripts/scene/gnn_scene.py -- --gnn-trace traces/gnn-karate.trace.json --gnn-out-x3d scenes/gnn-karate.x3d --gnn-out-blend scenes/gnn-karate.blend --gnn-report out/gnn/build.json 2>&1 | grep -E "attempt|RESULT|Error|Traceback" | tee -a $LOG
rm -f scenes/gnn-karate.blend1
step "6 x3d_mcp validate_x3d + validate_semantic"
$MCPPY scripts/gnn/validate_x3d_gnn.py scenes/gnn-karate.x3d 2>&1 | grep -E "validate_x3d:|Found" | cut -c1-300 | tee -a $LOG
step "7 exported motion vs the per-frame handler (trace-driven tracks)"
python3 scripts/gnn/verify_gnn_x3d.py traces/gnn-karate.trace.json scenes/gnn-karate.x3d out/gnn/build.json | tee -a $LOG
step "8 every number shown in the scene vs the trace"
python3 scripts/gnn/audit_numbers_gnn.py traces/gnn-karate.trace.json scenes/gnn-karate.x3d | tee -a $LOG
step "9 saved .blend re-attach"
$BLENDER -b --factory-startup -noaudio --python scripts/gnn/blender_reattach_test.py -- scenes/gnn-karate.blend 2>&1 | grep -E "REATTACH_TEST|Traceback" | tee -a $LOG
step "10 demo visuals without a 3D viewer (GIF + contact sheet)"
python3 scripts/gnn/make_figures.py | tee -a $LOG
if [ $RENDER = 1 ]; then
  step "11 X_ITE render check (3 timestamps + graph viewpoints), non-blank + differing"
  [ -f "$XITE_DIST/x_ite.min.js" ] || { echo "X_ITE dist missing: $XITE_DIST" | tee -a $LOG; exit 1; }
  rm -f out/gnn/gnn-karate-*.png out/gnn/gnn-karate.render*.json
  node scripts/gnn/render_check_gnn.js scenes/gnn-karate.x3d out/gnn/gnn-karate 0.12,0.45,0.93 CA_VP3_Graphs@0.33 CA_VP4_Network@0.33 CA_VP5_Embedding@0.93 CA_VP6_Pipeline@0.62 CA_VP2_Overview@0.5 2>&1 | tail -1 | cut -c1-400 | tee -a $LOG
  python3 scripts/scene/image_stats.py out/gnn gnn-karate | tail -2 | cut -c1-600 | tee -a $LOG
fi
if [ $REGR = 1 ]; then
  step "12 regression: the Kafka and BigQuery scenes still rebuild byte-identically with the unmodified builder"
  scripts/gnn/regression_compare.sh out/gnn/regression/after 2>&1 | tee -a $LOG
fi
rm -rf scripts/gnn/__pycache__ scripts/scene/__pycache__ scripts/adapters/__pycache__ scripts/gnn/.pytest_cache .pytest_cache
echo done | tee -a $LOG
