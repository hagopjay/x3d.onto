"""Open the saved GNN .blend in a fresh headless Blender, run the script stored inside it, call attach_saved_gnn(), and check that frame changes move the
objects exactly as the trace says (the .blend itself does not animate until the handler is re-attached).
  Blender -b --factory-startup -noaudio --python scripts/gnn/blender_reattach_test.py -- scenes/gnn-karate.blend"""
import json, sys
import bpy
path = sys.argv[sys.argv.index("--") + 1]
bpy.ops.wm.open_mainfile(filepath=path)
ns = {"__name__": "gnn_scene_embedded"}
exec(compile(bpy.data.texts["gnn_scene.py"].as_string(), "gnn_scene.py", "exec"), ns)
sc = next(s for s in bpy.data.scenes if "x3d_trace_text" in s)
bpy.context.window.scene = sc
res = {"handler_before_attach": sum(1 for h in bpy.app.handlers.frame_change_pre if getattr(h, "__name__", "") == "_x3d_trace_frame_handler")}
m = ns["attach_saved_gnn"](sc)
worst, n = 0.0, 0
for fr in (1, 120, 300, 480, 700):
    sc.frame_set(fr)
    t = m.model.frame_to_t(fr)
    for o, tr in m.anim:
        loc, scl = tr.at(t)
        e = max(abs(a - b) for a, b in zip(scl, o.scale))
        if loc is not None:
            e = max(e, max(abs(a - b) for a, b in zip(loc, o.location)))
        worst, n = max(worst, e), n + 1
res.update(animated_objects=len(m.anim), comparisons=n, max_abs_error_after_reattach=worst, scene=sc.name, texts=[t.name for t in bpy.data.texts])
print("REATTACH_TEST " + json.dumps(res))
