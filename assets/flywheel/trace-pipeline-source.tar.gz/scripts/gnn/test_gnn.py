#!/usr/bin/env python3
"""Tests for the karate-club GCN + MLOps demo. Run: python3 -m pytest -q scripts/gnn/test_gnn.py   (or: python3 scripts/gnn/test_gnn.py)
Covers: dataset integrity, analytic gradients vs finite differences, determinism (same seed -> same weights hash), registry round trip + corruption
detection, the pipeline end to end, the x3d-trace/1 trace (schema sanity + insight numbers), the display layout, the pure-python scene model, and
(if Blender is installed) a headless live-mode sandbox build that leaves nothing behind."""
import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile

import numpy as np
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
import gcn, karate, layout, pipeline, serve          # noqa: E402

BLENDER = os.environ.get("BLENDER", "/Applications/Blender.app/Contents/MacOS/Blender")


def _graph():
    A = pipeline.adjacency(karate.edge_list_0idx())
    return A, gcn.normalized_adjacency(A), np.eye(karate.N), np.array(karate.factions())


@pytest.fixture(scope="module")
def run_doc():
    out = tempfile.mkdtemp(prefix="gnn-test-")
    return pipeline.main(["--out", out]), out


# ------------------------------------------------------------------------------------------------ data
def test_dataset_integrity():
    A, _, _, y = _graph()
    assert A.shape == (34, 34) and int(A.sum()) == 156 and len(karate.EDGES) == 78
    assert np.array_equal(A, A.T) and np.trace(A) == 0
    assert A.sum(axis=1).astype(int).tolist() == karate.PUBLISHED_DEGREES
    assert pipeline.connected_components(A) == 1
    assert int((y == 0).sum()) == 17 and int((y == 1).sum()) == 17 and y[0] != y[33]
    assert karate.dataset_sha256() == karate.dataset_sha256() and len(karate.dataset_sha256()) == 64


def test_normalized_adjacency_properties():
    A, Ah, _, _ = _graph()
    assert np.allclose(Ah, Ah.T)
    d = A.sum(axis=1) + 1
    assert np.allclose(Ah, (1 / np.sqrt(d))[:, None] * (A + np.eye(34)) * (1 / np.sqrt(d))[None, :])
    assert np.all(np.linalg.eigvalsh(Ah) <= 1 + 1e-9)                    # spectrum of D^-1/2 (A+I) D^-1/2 lies in [-1, 1]


# ------------------------------------------------------------------------------------------------ gradients
@pytest.mark.parametrize("wd", [0.0, 5e-4])
@pytest.mark.parametrize("seed", [3, 11])
def test_gradients_match_finite_differences(seed, wd):
    _, Ah, X, y = _graph()
    tr = np.array([0, 33])
    params = gcn.init_params(34, 2, 2, seed)
    rng = np.random.default_rng(seed)
    params["W0"] = params["W0"] + rng.normal(0, 0.3, params["W0"].shape)           # move away from the symmetric start
    c = gcn.forward(params, Ah, X)
    assert np.abs(c["Z1"]).min() > 1e-5, "a pre-activation sits on the ReLU kink: pick another seed"
    _, grads, _ = gcn.loss_and_grads(params, Ah, X, y, tr, wd)
    h = 1e-6
    for name in ("W0", "W1"):
        num = np.zeros_like(params[name])
        for idx in np.ndindex(*params[name].shape):
            for sgn in (+1, -1):
                p = {k: v.copy() for k, v in params.items()}
                p[name][idx] += sgn * h
                num[idx] += sgn * gcn.loss_and_grads(p, Ah, X, y, tr, wd)[0] / (2 * h)
        err = np.abs(num - grads[name]).max()
        scale = max(np.abs(num).max(), 1e-12)
        assert err / scale < 1e-5, "%s: max abs error %g (relative %g)" % (name, err, err / scale)


# ------------------------------------------------------------------------------------------------ training + determinism
def test_training_reduces_loss_and_is_deterministic():
    _, Ah, X, y = _graph()
    tr = np.array([0, 33])
    p1, i1, h1 = gcn.train(Ah, X, y, tr, hidden=2, seed=0, lr=0.5, epochs=200, wd=5e-4)
    p2, i2, h2 = gcn.train(Ah, X, y, tr, hidden=2, seed=0, lr=0.5, epochs=200, wd=5e-4)
    assert serve.weights_sha256(p1) == serve.weights_sha256(p2) != serve.weights_sha256(i1)
    assert h1[-1]["loss_train"] < 0.05 < h1[0]["loss_train"]
    assert len(h1) == 201 and h1[0]["epoch"] == 0 and h1[-1]["epoch"] == 200
    p3, _, _ = gcn.train(Ah, X, y, tr, hidden=2, seed=1, lr=0.5, epochs=200, wd=5e-4, log=False)
    assert serve.weights_sha256(p3) != serve.weights_sha256(p1)


def test_two_labels_only_are_used():
    """Changing the faction of an UNLABELLED member must not change the trained weights (only the 2 leaders' labels enter the loss)."""
    _, Ah, X, y = _graph()
    tr = np.array([0, 33])
    y2 = y.copy()
    y2[8] = 1 - y2[8]
    a, _, _ = gcn.train(Ah, X, y, tr, seed=0, epochs=60, log=False)
    b, _, _ = gcn.train(Ah, X, y2, tr, seed=0, epochs=60, log=False)
    assert serve.weights_sha256(a) == serve.weights_sha256(b)


# ------------------------------------------------------------------------------------------------ registry
def test_registry_round_trip_and_corruption(tmp_path):
    _, Ah, X, y = _graph()
    A, _, _, _ = _graph()
    params, _, _ = gcn.train(Ah, X, y, np.array([0, 33]), seed=0, epochs=50, log=False)
    ver, folder, files, nbytes = serve.register(str(tmp_path), "m", params, {"accuracy_all34": 1.0}, {"created_utc": "x"})
    loaded, man = serve.load_registered(str(tmp_path), "m")
    assert man["version"] == ver == serve.weights_sha256(params)[:12]
    assert all(np.array_equal(loaded[k], params[k]) for k in params)
    p1, q1 = serve.Predictor(params, A).predict()
    p2, q2 = serve.Predictor(loaded, A).predict()
    assert np.array_equal(p1, p2) and np.array_equal(q1, q2)
    with open(os.path.join(folder, "W0.npy"), "r+b") as fh:                          # flip one byte of the stored weights
        fh.seek(-1, os.SEEK_END)
        b = fh.read(1)
        fh.seek(-1, os.SEEK_END)
        fh.write(bytes([b[0] ^ 1]))
    with pytest.raises(ValueError):
        serve.load_registered(str(tmp_path), "m", ver)


# ------------------------------------------------------------------------------------------------ pipeline
def test_pipeline_end_to_end(run_doc):
    doc, out = run_doc
    ids = [s["id"] for s in doc["stages"]]
    assert ids == ["ingest", "validate", "split", "train", "evaluate", "register", "serve", "monitor"]
    ends = [s["end_s"] for s in doc["stages"]]
    starts = [s["start_s"] for s in doc["stages"]]
    assert all(s["wall_ms"] > 0 for s in doc["stages"]) and all(starts[i + 1] >= ends[i] for i in range(7))
    ev = doc["evaluation"]
    assert ev["accuracy_all34"] >= 0.94 and ev["confusion"][0][0] + ev["confusion"][0][1] == 17
    assert doc["stages"][1]["metrics"]["checks_passed"] == doc["stages"][1]["metrics"]["checks_run"] == 10
    assert doc["stages"][6]["metrics"]["hash_match"] == 1 and doc["stages"][6]["metrics"]["predictions_match"] == 1
    assert os.path.exists(os.path.join(out, "registry", "karate-gcn", doc["version"], "manifest.json"))
    assert doc["repeat"]["identical"] and doc["monitor"]["k_removed"] == 3 and len(doc["monitor"]["removed_friendships_1idx"]) == 3
    assert len(doc["train_log"]["loss_train"]) == 201 and np.array(doc["train_log"]["emb"]).shape == (201, 34, 2)


def test_pipeline_same_seed_same_hash(run_doc):
    doc, _ = run_doc
    other = pipeline.main(["--out", tempfile.mkdtemp(prefix="gnn-test2-")])
    assert other["weights_sha256"] == doc["weights_sha256"] and other["version"] == doc["version"]
    assert [round(x, 6) for x in other["train_log"]["loss_train"]] == [round(x, 6) for x in doc["train_log"]["loss_train"]]


def test_validate_stage_rejects_a_broken_graph():
    run = pipeline.Run(tempfile.mkdtemp(prefix="gnn-bad-"))
    run.S["edges0"] = karate.edge_list_0idx()[:-1]                                   # drop one friendship: 77 edges
    run.S["y"] = np.array(karate.factions())
    with pytest.raises(RuntimeError):
        pipeline.s_validate(run.S, run)


# ------------------------------------------------------------------------------------------------ layout
def test_layout_is_deterministic_and_spread():
    A, _, _, _ = _graph()
    p1, p2 = layout.fruchterman_reingold(A, seed=2), layout.fruchterman_reingold(A, seed=2)
    assert np.array_equal(p1, p2) and layout.min_pair_distance(p1) >= 0.249 and np.abs(p1).max() <= 1.0 + 1e-9


# ------------------------------------------------------------------------------------------------ trace
def _adapter():
    spec = importlib.util.spec_from_file_location("gnn_to_trace", os.path.join(ROOT, "scripts", "adapters", "gnn_to_trace.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture(scope="module")
def trace(run_doc):
    doc, out = run_doc
    path = os.path.join(out, "t.trace.json")
    _adapter().main(["--run", os.path.join(out, "run.json"), "--out", path, "--insights-md", os.path.join(out, "INSIGHTS.md")])
    return json.load(open(path))


def test_trace_schema_sanity(trace):
    t = trace
    assert t["schema"] == "x3d-trace/1" and t["source"]["kind"] == "mlops-gnn" and t["source"]["synthetic"] is False
    ids = [s["id"] for s in t["stages"]]
    assert len(set(ids)) == 8 and [s["layer"] for s in t["stages"]] == list(range(8))
    assert all(f["from"] in ids and f["to"] in ids for f in t["flows"]) and len(t["flows"]) == 7
    assert abs(t["time"]["duration"] - t["stages"][-1]["end_s"]) < 1e-5
    assert all(isinstance(v, (int, float)) and not isinstance(v, bool) for s in t["stages"] for v in s["metrics"].values())
    n = len(t["series"]["t"])
    assert n == 201 and all(len(v) == n for v in t["series"]["channels"].values()) and t["series"]["t"] == sorted(t["series"]["t"])
    train = next(s for s in t["stages"] if s["stage_key"] == "train")
    assert train["start_s"] <= t["series"]["t"][0] and t["series"]["t"][-1] <= train["end_s"]
    assert len(t["entities"]) == 34 and all(len(e["series"][k]) == n for e in t["entities"] for k in ("t", "x", "y", "p_officer"))
    assert {e["faction"] for e in t["entities"]} == {"Mr. Hi", "Officer"}
    prov = t["source"]["provenance"]
    assert re.fullmatch(r"[0-9a-f]{64}", prov["dataset_sha256"]) and re.fullmatch(r"[0-9a-f]{64}", prov["weights_sha256"])
    assert any("REAL DATA" in x for x in t["notes"]) and any("tiny" in x for x in t["notes"])
    assert t["gnn"]["dataset"]["n_edges"] == len(t["gnn"]["edges"]) == 78 and len(t["gnn"]["nodes"]) == 34


def test_trace_edge_weights_are_the_a_hat_entries(trace):
    A, Ah, _, _ = _graph()
    for a, b, w in trace["gnn"]["edges"]:
        assert abs(w - Ah[a - 1, b - 1]) < 6e-6
    assert np.allclose(trace["gnn"]["self_weights"], np.diag(Ah), atol=6e-6)


def test_insight_texts_only_contain_numbers_from_their_numbers(trace):
    for c in trace["gnn"]["insights"]:
        vals = [float(v) for v in c["numbers"].values()]
        for tok in re.findall(r"(?<![\w.])\d+(?:\.\d+)?(?![\w])", c["text"]):
            v = float(tok)
            assert any(abs(v - x) <= max(0.006 * abs(x), 0.5 * 10 ** -(len(tok.split(".")[1]) if "." in tok else 0)) for x in vals), (c["id"], tok)
        assert c["at"]["stage_from"] in {s["stage_key"] for s in trace["stages"]}


# ------------------------------------------------------------------------------------------------ scene model (pure python)
def test_scene_model_builds_without_blender(trace, tmp_path):
    sys.path.insert(0, os.path.join(ROOT, "scripts", "scene"))
    argv, sys.argv = sys.argv, sys.argv[:1]
    try:
        import gnn_scene
    finally:
        sys.argv = argv
    m = gnn_scene.GnnModel(trace)
    assert 600 < len(m.items) < 1200 and len({it["name"] for it in m.items}) == len(m.items)
    assert abs(sum(b - a for a, b in m.slots.win.values()) - m.pb_play) < 1e-6
    t0, t1 = m.slots.t0, m.slots.t1
    for it in m.items:
        tr = it.get("track")
        if tr is not None:
            for t in (0.0, t0, (t0 + t1) / 2, t1, m.pb_play):
                loc, sc = tr.at(t)
                assert len(sc) == 3 and min(sc) > 0
    syn = [it for it in m.items if it["kind"] == "label" and "SYNTHETIC" in " ".join(it["lines"])]
    assert not syn and m.banner.startswith("REAL DATA")


@pytest.mark.skipif(not os.path.exists(BLENDER), reason="Blender not installed")
def test_blender_live_mode_sandbox_leaves_nothing_behind(trace, tmp_path):
    tpath = tmp_path / "t.trace.json"
    tpath.write_text(json.dumps(trace))
    r = subprocess.run([BLENDER, "-b", "--factory-startup", "-noaudio", "--python", os.path.join(HERE, "blender_live_test.py"), "--", str(tpath)],
                       capture_output=True, text=True, timeout=300)
    assert "GNN_LIVE_TEST_OK" in r.stdout, r.stdout[-1500:] + r.stderr[-800:]


if __name__ == "__main__":
    sys.exit(pytest.main(["-q", os.path.abspath(__file__)]))
