"""Run inside Blender (headless): build the GNN scene in LIVE mode into a new scene, check that the frame handler moves things, then destroy it and check that
nothing is left behind. usage: Blender -b --factory-startup --python scripts/gnn/blender_live_test.py -- TRACE.json"""
import os, sys
import bpy
HERE = os.path.dirname(os.path.abspath(__file__))
tracep = sys.argv[sys.argv.index("--") + 1]
sys.path.insert(0, os.path.join(HERE, "..", "scene"))
sys.argv = sys.argv[:1]
import gnn_scene as G                                                           # noqa: E402

def counts():
    return {k: len(getattr(bpy.data, k)) for k in ("objects", "meshes", "materials", "scenes", "cameras", "lights", "worlds", "collections", "curves")}

before = counts()
m = G.build_gnn(tracep, live=True)
sc = m.scene
anchor = bpy.data.objects["eP1"]
sc.frame_set(1)
p_start = tuple(anchor.location)
sc.frame_set(int(m.model.nf * 0.6))
p_mid = tuple(anchor.location)
moved = max(abs(a - b) for a, b in zip(p_start, p_mid))
handler_ok = any(getattr(h, "__name__", "") == "_x3d_trace_frame_handler" for h in bpy.app.handlers.frame_change_pre)
assert handler_ok and moved > 1.0, (handler_ok, moved)
assert not bpy.data.actions or all(not a.fcurves for a in bpy.data.actions if hasattr(a, "fcurves")), "no fcurves expected"
n_anim = len(m.anim)
m.destroy()
after = counts()
leak = {k: (before[k], after[k]) for k in before if after[k] != before[k]}
print("GNN_LIVE_TEST_OK" if not leak else "GNN_LIVE_TEST_LEAK %s" % leak, "animated=%d moved=%.2f items=%d" % (n_anim, moved, len(m.model.items)))
