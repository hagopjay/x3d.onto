#!/bin/bash
# Rebuild the two EXISTING scenes (Kafka, BigQuery) with the unmodified builder into DIR and compare them with scenes/*.x3d.
# usage: scripts/gnn/regression_compare.sh DIR   -> prints sha256/size of each fresh build and whether it equals the committed scene
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
BLENDER=${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}
D=${1:?usage: regression_compare.sh DIR}; mkdir -p "$D"
for N in kafka-gossip bq-wikipedia; do
  $BLENDER -b --factory-startup -noaudio --python scripts/scene/trace_to_scene.py -- --trace traces/$N.trace.json --out-x3d "$D/$N.x3d" 2>&1 | grep -E "RESULT|Error|Traceback"
  A=$(shasum -a 256 "$D/$N.x3d" | cut -c1-16); B=$(shasum -a 256 scenes/$N.x3d | cut -c1-16)
  echo "$N fresh=$A committed=$B bytes=$(wc -c < "$D/$N.x3d") $([ "$A" = "$B" ] && echo IDENTICAL || echo DIFFERENT)"
done
