"""Display-only 2-D layout of the friendship network (NOT a model output): Fruchterman-Reingold springs from a seeded start,
then a collision-relaxation pass inside the unit square so that no two members are drawn closer than `min_dist`.
Coordinates end up in [-1, 1] x [-1, 1]. Deterministic for a given seed."""
import numpy as np


def fruchterman_reingold(A, seed=1, iters=600, min_dist=0.25):
    n = A.shape[0]
    rng = np.random.default_rng(seed)
    pos = rng.uniform(-1.0, 1.0, size=(n, 2))
    k = np.sqrt(4.0 / n)
    t = 0.2
    for it in range(iters):
        d = pos[:, None, :] - pos[None, :, :]
        dist = np.sqrt((d ** 2).sum(axis=2)) + 1e-9
        rep = (k * k / dist ** 2)[..., None] * d                       # repulsion between every pair
        att = -(A * dist / k)[..., None] * d                           # attraction along friendships
        disp = rep.sum(axis=1) + att.sum(axis=1)
        length = np.sqrt((disp ** 2).sum(axis=1))[:, None] + 1e-9
        pos += disp / length * np.minimum(length, t)
        t = max(0.002, t * (1.0 - (it + 1) / iters))
    pos -= (pos.max(axis=0) + pos.min(axis=0)) / 2
    pos /= np.abs(pos).max()
    for _ in range(3000):                                              # collision relaxation (display only), kept inside the square
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                v = pos[i] - pos[j]
                dd = float(np.hypot(*v))
                if dd < min_dist:
                    v = v / dd if dd > 1e-9 else np.array([1.0, 0.0])
                    push = (min_dist - dd) / 2 + 1e-4
                    pos[i] += v * push
                    pos[j] -= v * push
                    moved = True
        pos = np.clip(pos, -1.0, 1.0)
        if not moved:
            break
    return pos


def min_pair_distance(pos):
    d = pos[:, None, :] - pos[None, :, :]
    dist = np.sqrt((d ** 2).sum(axis=2)) + np.eye(len(pos)) * 1e9
    return float(dist.min())
