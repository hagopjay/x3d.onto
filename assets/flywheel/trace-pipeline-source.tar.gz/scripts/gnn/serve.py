"""A tiny local model registry and a predictor that loads from it (what the 'register' and 'serve' stages really do).

Registry layout (content-addressed: the version is the first 12 hex digits of the weights hash, so re-registering identical
weights lands in the same folder):
    <registry>/<model>/<version>/W0.npy  W1.npy  metrics.json  manifest.json
    <registry>/<model>/index.json          list of versions + which one is latest
"""
import hashlib
import io
import json
import os

import numpy as np

import gcn

PARAM_ORDER = ("W0", "W1")


def _npy_bytes(a):
    buf = io.BytesIO()
    np.lib.format.write_array(buf, np.ascontiguousarray(a, dtype="<f8"))          # deterministic: .npy header + raw float64 bytes
    return buf.getvalue()


def weights_sha256(params):
    """sha256 over the .npy bytes of W0 then W1 (the exact bytes the registry stores)."""
    h = hashlib.sha256()
    for k in PARAM_ORDER:
        h.update(_npy_bytes(params[k]))
    return h.hexdigest()


def sha256_file(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def write_json(path, doc):
    data = (json.dumps(doc, indent=1, sort_keys=True) + "\n").encode("utf-8")
    with open(path, "wb") as fh:
        fh.write(data)
    return data


def register(registry, model, params, metrics, extra_manifest):
    """Write weights + metrics + manifest. Returns (version, folder, files {name: sha256}, bytes_written)."""
    wsha = weights_sha256(params)
    version = wsha[:12]
    folder = os.path.join(registry, model, version)
    os.makedirs(folder, exist_ok=True)
    files, nbytes = {}, 0
    for k in PARAM_ORDER:
        data = _npy_bytes(params[k])
        with open(os.path.join(folder, k + ".npy"), "wb") as fh:
            fh.write(data)
        files[k + ".npy"] = hashlib.sha256(data).hexdigest()
        nbytes += len(data)
    mdata = write_json(os.path.join(folder, "metrics.json"), metrics)
    files["metrics.json"] = hashlib.sha256(mdata).hexdigest()
    nbytes += len(mdata)
    manifest = dict(model=model, version=version, weights_sha256=wsha, metrics_sha256=files["metrics.json"], files=files)
    manifest.update(extra_manifest)
    nbytes += len(write_json(os.path.join(folder, "manifest.json"), manifest))
    idx_path = os.path.join(registry, model, "index.json")
    idx = json.load(open(idx_path)) if os.path.exists(idx_path) else {"model": model, "versions": []}
    idx["versions"] = [v for v in idx["versions"] if v["version"] != version] + [
        {"version": version, "weights_sha256": wsha, "accuracy_all34": metrics.get("accuracy_all34"), "created_utc": extra_manifest.get("created_utc")}]
    idx["latest"] = version
    nbytes += len(write_json(idx_path, idx))
    return version, folder, files, nbytes


def load_registered(registry, model, version=None):
    """Load a registered model from disk and VERIFY its hashes against the manifest. Returns (params, manifest)."""
    mdir = os.path.join(registry, model)
    version = version or json.load(open(os.path.join(mdir, "index.json")))["latest"]
    folder = os.path.join(mdir, version)
    manifest = json.load(open(os.path.join(folder, "manifest.json")))
    params = {}
    for k in PARAM_ORDER:
        path = os.path.join(folder, k + ".npy")
        if sha256_file(path) != manifest["files"][k + ".npy"]:
            raise ValueError("registry corruption: %s does not match its manifest hash" % path)
        params[k] = np.load(path)
    if weights_sha256(params) != manifest["weights_sha256"]:
        raise ValueError("registry corruption: weights hash differs from the manifest")
    return params, manifest


class Predictor:
    """What a serving endpoint would hold: registered weights + the graph it answers for."""

    def __init__(self, params, A):
        self.params, self.A = params, A
        self.Ahat = gcn.normalized_adjacency(A)
        self.X = np.eye(A.shape[0])

    def predict(self, members=None):
        """Faction index and P(Officer) for members (1-indexed list) or for all members."""
        pred, P, _ = gcn.predict(self.params, self.Ahat, self.X)
        rows = np.arange(len(pred)) if members is None else np.asarray(members) - 1
        return pred[rows], P[rows, 1]
