#!/usr/bin/env python3
"""The MLOps wrapper around the karate-club GCN. Every stage is really executed and timed with time.perf_counter():

    ingest -> validate -> split -> train -> evaluate -> register -> serve -> monitor

usage: python3 scripts/gnn/pipeline.py [--out out/gnn] [--seed 0]      -> writes out/gnn/run.json (+ artifacts/, registry/)

run.json is the raw run record; scripts/adapters/gnn_to_trace.py turns it into traces/gnn-karate.trace.json (x3d-trace/1).
Hyper-parameters (lr 0.5, 200 epochs, weight decay 5e-4 from Kipf & Welling) were set from the TRAINING loss curve (0.663 -> 0.013). Disclosure: while exploring
learning rates (0.2/0.5/1.0, 200/400 epochs, seeds 0-9) the accuracies against the real factions were printed too; seed 0 reached the same 0.971 in every setting, so the
choice does not change the headline result. Seed 0 is simply the default seed; the seed sweep (analysis section) reports all 20 seeds, collapses included.
"""
import argparse
import datetime
import hashlib
import json
import os
import platform
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gcn            # noqa: E402
import karate         # noqa: E402
import serve          # noqa: E402

HP = dict(hidden=2, lr=0.5, epochs=200, wd=5e-4, seed=0)
PROBE = dict(n_remove=3, seed=7, n_draws=50)          # monitor stage: remove 3 random friendships (fixed seed), 50 extra random draws
SWEEP_SEEDS = list(range(20))                         # analysis section: the same training, 20 seeds
MODEL = "karate-gcn"
CLK = time.perf_counter


def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()


def code_sha256():
    h = hashlib.sha256()
    for f in ("karate.py", "gcn.py", "serve.py", "pipeline.py"):
        h.update(open(os.path.join(HERE, f), "rb").read())
    return h.hexdigest()


def adjacency(edges_0idx, n=karate.N):
    A = np.zeros((n, n))
    for a, b in edges_0idx:
        A[a, b] = A[b, a] = 1.0
    return A


def connected_components(A):
    n, seen, comps = A.shape[0], set(), 0
    for s in range(n):
        if s in seen:
            continue
        comps += 1
        stack = [s]
        while stack:
            u = stack.pop()
            if u in seen:
                continue
            seen.add(u)
            stack.extend(int(v) for v in np.nonzero(A[u])[0] if v not in seen)
    return comps


def hops_from(A, sources):
    """Breadth-first distance (in friendships) from the nearest of `sources`."""
    d = np.full(A.shape[0], -1)
    frontier = list(sources)
    for s in frontier:
        d[s] = 0
    while frontier:
        nxt = []
        for u in frontier:
            for v in np.nonzero(A[u])[0]:
                if d[v] < 0:
                    d[v] = d[u] + 1
                    nxt.append(int(v))
        frontier = nxt
    return d


def r5(a):
    return np.round(np.asarray(a, dtype=float), 5).tolist()


class Run:
    def __init__(self, out):
        self.out, self.art = out, os.path.join(out, "artifacts")
        self.registry = os.path.join(out, "registry")
        os.makedirs(self.art, exist_ok=True)
        self.stages, self.S, self.t0 = [], {}, CLK()

    def stage(self, sid, name, kind, fn):
        t_in = CLK()
        res = fn(self.S)
        t_out = CLK()
        rec = dict(id=sid, name=name, kind=kind, start_s=t_in - self.t0, end_s=t_out - self.t0, wall_ms=(t_out - t_in) * 1e3,
                   metrics=res.get("metrics", {}), hashes=res.get("hashes", {}), notes=res.get("notes", []), detail=res.get("detail", {}))
        self.stages.append(rec)
        return rec


# ----------------------------------------------------------------------------------------------------- the eight stages
def s_ingest(S, run):
    raw = karate.canonical_bytes()
    path = os.path.join(run.art, "dataset.json")
    with open(path, "wb") as fh:
        fh.write(raw)
    doc = json.load(open(path))                                    # the pipeline continues from the file it just wrote
    S["dataset"] = doc
    S["edges0"] = [(a - 1, b - 1) for a, b in doc["edges_1idx"]]
    S["y"] = np.array(doc["faction_of_member_1idx"])
    sha = sha256_bytes(raw)
    return dict(metrics=dict(records_in=len(karate.EDGES), records_out=len(doc["edges_1idx"]), artifact_bytes=len(raw)),
                hashes={"dataset.json": sha}, notes=["dataset embedded in scripts/gnn/karate.py (Zachary 1977); no download"])


def s_validate(S, run):
    A, edges, y = adjacency(S["edges0"]), S["edges0"], S["y"]
    deg = A.sum(axis=1).astype(int).tolist()
    checks = [
        ("34 members", A.shape[0] == 34),
        ("78 friendships", len(edges) == 78 and int(A.sum() // 2) == 78),
        ("no duplicate friendships", len({tuple(sorted(e)) for e in edges}) == len(edges)),
        ("friendship matrix symmetric", bool(np.array_equal(A, A.T))),
        ("no self-loops", float(np.trace(A)) == 0.0),
        ("graph connected (1 component)", connected_components(A) == 1),
        ("degrees match the published sequence", deg == karate.PUBLISHED_DEGREES),
        ("every member has a faction label in {0,1}", bool(set(y.tolist()) <= {0, 1}) and len(y) == 34),
        ("17 + 17 faction split", int((y == 0).sum()) == 17 and int((y == 1).sum()) == 17),
        ("leaders 1 and 34 are in different factions", int(y[0]) != int(y[33])),
    ]
    failed = [n for n, ok in checks if not ok]
    if failed:
        raise RuntimeError("data validation failed: %s" % failed)
    S["A"] = A
    rep = json.dumps([{"check": n, "passed": ok} for n, ok in checks]).encode()
    return dict(metrics=dict(records_in=len(edges), records_out=len(checks), checks_run=len(checks), checks_passed=len(checks) - len(failed),
                             components=1, artifact_bytes=len(rep)),
                hashes={"validation_report": sha256_bytes(rep)}, detail=dict(checks=[{"check": n, "passed": ok} for n, ok in checks]))


def s_split(S, run):
    A, y = S["A"], S["y"]
    train_rows = np.array(sorted(m - 1 for m in karate.LEADERS))
    unl = np.setdiff1d(np.arange(karate.N), train_rows)
    Ahat = gcn.normalized_adjacency(A)
    S.update(train_rows=train_rows, unl=unl, Ahat=Ahat, X=np.eye(karate.N))
    return dict(metrics=dict(records_in=karate.N, records_out=karate.N, labelled=len(train_rows), unlabelled=len(unl), features=karate.N,
                             artifact_bytes=int(Ahat.nbytes)),
                hashes={"A_hat": sha256_bytes(np.ascontiguousarray(Ahat).tobytes())},
                notes=["labels visible to training: members 1 (Mr. Hi) and 34 (the Officer); features = identity (one-hot member id)"])


def s_train(S, run):
    params, init, hist = gcn.train(S["Ahat"], S["X"], S["y"], S["train_rows"], **HP)
    S.update(params=params, init=init, hist=hist)
    return dict(metrics=dict(records_in=len(S["train_rows"]), records_out=len(hist) - 1, epochs=HP["epochs"], n_params=int(sum(v.size for v in params.values())),
                             final_loss=hist[-1]["loss_train"], artifact_bytes=int(sum(v.nbytes for v in params.values()))),
                hashes={"weights_init": serve.weights_sha256(init), "weights_final": serve.weights_sha256(params)},
                notes=["wall time includes per-epoch logging (loss, accuracy, embedding, messages) and is the FIRST (cold) call in this process; see analysis.repeat for the warm repeat"])


def s_evaluate(S, run):
    A, y, Ahat, X, params = S["A"], S["y"], S["Ahat"], S["X"], S["params"]
    pred, P, cache = gcn.predict(params, Ahat, X)
    conf = np.zeros((2, 2), dtype=int)
    for t, p in zip(y, pred):
        conf[t, p] += 1
    wrong = [int(i) for i in np.nonzero(pred != y)[0]]
    hop = hops_from(A, [m - 1 for m in karate.LEADERS])
    ev_wrong = []
    for i in wrong:
        nb = np.nonzero(A[i])[0]
        ev_wrong.append(dict(member=i + 1, true=int(y[i]), predicted=int(pred[i]), degree=int(len(nb)), friends_in_mr_hi=int((y[nb] == 0).sum()),
                             friends_in_officer=int((y[nb] == 1).sum()), p_officer=float(P[i, 1])))
    same = int(sum(y[a] == y[b] for a, b in S["edges0"]))
    by_hop = {}
    for h in sorted(set(hop.tolist())):
        rows = np.nonzero(hop == h)[0]
        by_hop[str(h)] = dict(members=int(len(rows)), correct=int((pred[rows] == y[rows]).sum()))
    ev = dict(accuracy_all34=gcn.accuracy(pred, y), accuracy_unlabelled32=gcn.accuracy(pred, y, S["unl"]), n_correct=int((pred == y).sum()),
              n_wrong=len(wrong), confusion=conf.tolist(), wrong=ev_wrong, same_faction_edges=same, edges=len(S["edges0"]),
              by_hop=by_hop, hops_to_nearest_leader=hop.tolist(), loss_all34=gcn.cross_entropy(P, y, np.arange(karate.N)),
              pred=pred.tolist(), p_officer=P[:, 1].tolist())
    S.update(ev=ev, pred_eval=pred, P_eval=P)
    blob = json.dumps(ev, sort_keys=True).encode()
    return dict(metrics=dict(records_in=karate.N, records_out=karate.N, accuracy_all34=ev["accuracy_all34"],
                             accuracy_unlabelled32=ev["accuracy_unlabelled32"], correct=ev["n_correct"], wrong=ev["n_wrong"], artifact_bytes=len(blob)),
                hashes={"evaluation": sha256_bytes(blob)}, detail=dict(confusion=conf.tolist(), wrong_members=[w["member"] for w in ev_wrong]))


def s_register(S, run):
    ev = S["ev"]
    metrics = dict(accuracy_all34=ev["accuracy_all34"], accuracy_unlabelled32=ev["accuracy_unlabelled32"], confusion=ev["confusion"],
                   wrong_members=[w["member"] for w in ev["wrong"]], final_loss_train=S["hist"][-1]["loss_train"], hyper_parameters=HP,
                   dataset_sha256=run.S["dataset_sha"], note="evaluated on the same 34-member graph it was trained on (transductive; 2 labels used)")
    created = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    version, folder, files, nbytes = serve.register(run.registry, MODEL, S["params"], metrics,
                                                    dict(created_utc=created, dataset_sha256=run.S["dataset_sha"], code_sha256=code_sha256(),
                                                         numpy=np.__version__, python=platform.python_version()))
    S.update(version=version, reg_folder=folder, reg_files=files)
    return dict(metrics=dict(records_in=1, records_out=len(files) + 2, files_written=len(files) + 2, artifact_bytes=nbytes),
                hashes=dict(files, weights_sha256=serve.weights_sha256(S["params"])), detail=dict(version=version, folder=os.path.relpath(folder, run.out)))


def s_serve(S, run):
    params, manifest = serve.load_registered(run.registry, MODEL, S["version"])               # from DISK, with hash verification
    A = adjacency([(a - 1, b - 1) for a, b in json.load(open(os.path.join(run.art, "dataset.json")))["edges_1idx"]])
    pr = serve.Predictor(params, A)
    pred, p1 = pr.predict()
    hash_match = serve.weights_sha256(params) == serve.weights_sha256(S["params"]) == manifest["weights_sha256"]
    same_pred = bool(np.array_equal(pred, S["pred_eval"])) and bool(np.array_equal(p1, S["P_eval"][:, 1]))
    if not (hash_match and same_pred):
        raise RuntimeError("serve smoke test failed: hash_match=%s same_predictions=%s" % (hash_match, same_pred))
    lat = []
    for _ in range(200):
        t = CLK()
        pr.predict([9])
        lat.append((CLK() - t) * 1e3)
    S["served_params"] = params
    return dict(metrics=dict(records_in=karate.N, records_out=karate.N, hash_match=1, predictions_match=1, latency_ms_p50=float(np.percentile(lat, 50)),
                             latency_ms_p95=float(np.percentile(lat, 95)), artifact_bytes=int(pred.nbytes + p1.nbytes)),
                hashes={"weights_loaded": serve.weights_sha256(params)}, notes=["latency = one 34-node forward pass for member 9, 200 repeats"])


def perturb(A, rng, k):
    edges = [(i, j) for i in range(A.shape[0]) for j in range(i + 1, A.shape[0]) if A[i, j] > 0]
    pick = rng.choice(len(edges), size=k, replace=False)
    B = A.copy()
    removed = [edges[int(p)] for p in sorted(pick)]
    for i, j in removed:
        B[i, j] = B[j, i] = 0.0
    return B, removed


def s_monitor(S, run):
    params, A, y = S["served_params"], S["A"], S["y"]
    pr0 = serve.Predictor(params, A)
    base, _ = pr0.predict()
    acc0 = gcn.accuracy(base, y)
    rng = np.random.default_rng(PROBE["seed"])
    B, removed = perturb(A, rng, PROBE["n_remove"])                    # the fixed-seed probe the brief asks for
    pred_b, _ = serve.Predictor(params, B).predict()
    acc_b = gcn.accuracy(pred_b, y)
    draws = []
    for _ in range(PROBE["n_draws"]):                                   # extra: the same probe, 50 more random draws
        Bd, _ = perturb(A, rng, PROBE["n_remove"])
        pd, _ = serve.Predictor(params, Bd).predict()
        draws.append(gcn.accuracy(pd, y))
    det = dict(baseline_accuracy=acc0, perturbed_accuracy=acc_b, accuracy_change=acc_b - acc0, changed_predictions=int((pred_b != base).sum()),
               removed_friendships_1idx=[[a + 1, b + 1] for a, b in removed], draws_accuracy_mean=float(np.mean(draws)), draws_accuracy_min=float(np.min(draws)),
               draws_accuracy_max=float(np.max(draws)), draws=PROBE["n_draws"], seed=PROBE["seed"], k_removed=PROBE["n_remove"],
               isolated_members=[int(i) + 1 for i in np.nonzero(B.sum(axis=1) == 0)[0]])
    S["monitor"] = det
    blob = json.dumps(det, sort_keys=True).encode()
    return dict(metrics=dict(records_in=PROBE["n_remove"], records_out=PROBE["n_draws"] + 1, probes=PROBE["n_draws"] + 1, accuracy_change=det["accuracy_change"],
                             changed_predictions=det["changed_predictions"], artifact_bytes=len(blob)),
                hashes={"monitor_report": sha256_bytes(blob)}, detail=det)


STAGES = [("ingest", "Ingest dataset", "ingest", s_ingest), ("validate", "Validate data", "validate", s_validate), ("split", "Split / mask + features", "split", s_split),
          ("train", "Train GCN", "train", s_train), ("evaluate", "Evaluate", "evaluate", s_evaluate), ("register", "Register model", "register", s_register),
          ("serve", "Serve smoke test", "serve", s_serve), ("monitor", "Monitor: edge-removal probe", "monitor", s_monitor)]


def seed_sweep():
    """Analysis (NOT a pipeline stage): the same training for several seeds, to show how much the result depends on initialisation."""
    A = adjacency([(a - 1, b - 1) for a, b in karate.EDGES])
    Ahat, X, y = gcn.normalized_adjacency(A), np.eye(karate.N), np.array(karate.factions())
    rows, t0 = [], CLK()
    for s in SWEEP_SEEDS:
        hp = dict(HP, seed=s)
        p, init, _ = gcn.train(Ahat, X, y, np.array([0, 33]), log=False, **{k: hp[k] for k in ("hidden", "lr", "epochs", "wd", "seed")})
        pred, P, c = gcn.predict(p, Ahat, X)
        rows.append(dict(seed=s, accuracy=gcn.accuracy(pred, y), init_accuracy=gcn.accuracy(gcn.predict(init, Ahat, X)[0], y), final_loss=gcn.loss_and_grads(p, Ahat, X, y, np.array([0, 33]), hp["wd"], c)[0],
                         dead_members=int((c["H1"].sum(axis=1) == 0).sum())))
    acc = [r["accuracy"] for r in rows]
    ia = [r["init_accuracy"] for r in rows]
    return dict(seeds=SWEEP_SEEDS, rows=rows, accuracy_min=min(acc), accuracy_median=float(np.median(acc)), accuracy_max=max(acc),
                init_accuracy_min=min(ia), init_accuracy_median=float(np.median(ia)), init_accuracy_max=max(ia),
                n_at_least_94=int(sum(a >= 0.94 for a in acc)), n_collapsed=int(sum(r["dead_members"] >= 10 for r in rows)), wall_ms=(CLK() - t0) * 1e3)


def repeat_check(S):
    """Analysis (NOT a pipeline stage): train again with the same seed in the same (now warm) process; the weights hash must be identical."""
    t = CLK()
    p, _, _ = gcn.train(S["Ahat"], S["X"], S["y"], S["train_rows"], log=True, **HP)
    ms = (CLK() - t) * 1e3
    return dict(weights_sha256=serve.weights_sha256(p), identical=serve.weights_sha256(p) == serve.weights_sha256(S["params"]), warm_train_wall_ms=ms)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(HERE, "..", "..", "out", "gnn"))
    ap.add_argument("--seed", type=int, default=HP["seed"])
    a = ap.parse_args(argv)
    HP["seed"] = a.seed
    out = os.path.abspath(a.out)
    run = Run(out)
    run.S["dataset_sha"] = karate.dataset_sha256()
    created = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    for sid, name, kind, fn in STAGES:
        rec = run.stage(sid, name, kind, lambda S, fn=fn: fn(S, run))
        print("%-9s %8.3f ms  %s" % (sid, rec["wall_ms"], json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in rec["metrics"].items()})[:150]))
    total = CLK() - run.t0
    S = run.S
    hist = S["hist"]
    sweep = seed_sweep()
    rep = repeat_check(S)
    doc = dict(schema="gnn-run/1", created_utc=created, run_id="gnn-karate-" + serve.weights_sha256(S["params"])[:8],
               env=dict(python=platform.python_version(), numpy=np.__version__, platform=platform.platform(), machine=platform.machine(), code_sha256=code_sha256()),
               hp=HP, probe=PROBE, pipeline_wall_ms=total * 1e3, stages=run.stages, dataset_sha256=S["dataset_sha"], model=MODEL, version=S["version"],
               weights_sha256=serve.weights_sha256(S["params"]), evaluation=S["ev"], monitor=S["monitor"], seed_sweep=sweep, repeat=rep,
               train_log=dict(epoch=[h["epoch"] for h in hist], t_wall_s=[round(h["t_wall_s"], 6) for h in hist], t_run_s=[round(h["t_abs"] - run.t0, 6) for h in hist],
                              loss_train=r5([h["loss_train"] for h in hist]), loss_all=r5([h["loss_all"] for h in hist]),
                              acc_all=r5([h["acc_all"] for h in hist]), acc_unlabelled=r5([h["acc_unlabelled"] for h in hist]),
                              grad_norm=r5([h["grad_norm"] for h in hist]),
                              emb=[r5(h["emb"]) for h in hist], p_officer=[r5(h["p_officer"]) for h in hist], vote=[r5(h["vote"]) for h in hist],
                              pred=[h["pred"].tolist() for h in hist]),
               ahat=dict(edges=[[int(i) + 1, int(j) + 1, float(S["Ahat"][i, j])] for i, j in S["edges0"]], self_loops=[float(S["Ahat"][i, i]) for i in range(karate.N)]))
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "run.json"), "w") as fh:
        json.dump(doc, fh, separators=(",", ":"))
    ev = S["ev"]
    print("pipeline wall %.1f ms | accuracy all34 %.4f (%d/34), wrong members %s | weights %s | registry version %s" % (
        total * 1e3, ev["accuracy_all34"], ev["n_correct"], [w["member"] for w in ev["wrong"]], doc["weights_sha256"][:12], S["version"]))
    print("monitor: remove 3 edges -> accuracy %.4f (change %+.4f); %d draws mean %.4f min %.4f" % (
        S["monitor"]["perturbed_accuracy"], S["monitor"]["accuracy_change"], PROBE["n_draws"], S["monitor"]["draws_accuracy_mean"], S["monitor"]["draws_accuracy_min"]))
    print("repeat (warm) train %.1f ms; identical weights hash: %s" % (rep["warm_train_wall_ms"], rep["identical"]))
    print("seed sweep (%d seeds): acc min %.3f median %.3f max %.3f; >=0.94: %d; collapsed (dead ReLU): %d" % (
        len(SWEEP_SEEDS), sweep["accuracy_min"], sweep["accuracy_median"], sweep["accuracy_max"], sweep["n_at_least_94"], sweep["n_collapsed"]))
    return doc


if __name__ == "__main__":
    main()
