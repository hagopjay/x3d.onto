"""Run inside Blender: import an X3D file with the fork's importer and export it again with the fork's exporter (the 'Blender round trip' of the tether test).
Blender -b --factory-startup --python scripts/flywheel/blender_roundtrip.py -- IN.x3d OUT.x3d"""
import sys
import addon_utils
import bpy
a = sys.argv[sys.argv.index("--") + 1:]
bpy.ops.wm.read_factory_settings(use_empty=True)
addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
r1 = bpy.ops.import_scene.x3d(filepath=a[0])
# FINDING: the importer turns <Text> into FONT objects and the exporter tessellates them into meshes (about 13 ms per character, >100 s for 63 labels),
# so labels are left out of this round trip (the tether record does not depend on them)
fonts = [o for o in bpy.context.scene.objects if o.type == "FONT"]
n_fonts, n_chars = len(fonts), sum(len(o.data.body) for o in fonts)
for o in fonts:
    bpy.data.objects.remove(o)
for o in bpy.context.scene.objects:
    o.select_set(True)
r2 = bpy.ops.export_scene.x3d(filepath=a[1], check_existing=False, x3d_version="X3D40", use_selection=False, use_animation=True, animation_step=4)
print("ROUNDTRIP", r1, r2, "objects", len(bpy.context.scene.objects))
print("ROUNDTRIP_JSON", {"fonts_dropped": n_fonts, "font_chars": n_chars})
