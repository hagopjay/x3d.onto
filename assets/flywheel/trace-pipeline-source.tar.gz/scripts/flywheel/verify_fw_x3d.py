#!/usr/bin/env python3
"""Check that the exported X3D reproduces what the frame handler computes from the trace (no motion lost or invented by the exporter / compaction).
Rebuilds the pure-python GnnModel with the cfg recorded in the build report and compares every animated track with the exported interpolators
(linear interpolation, as any X3D browser does) or the Transform's static value where the interpolator was removed as constant.
  KEY frames   : the frames the exporter sampled; must agree to <= 3e-3 (compaction eps 2e-3 + rounding).
  ALL frames   : informational: the deviation BETWEEN keys (linear interpolation of a track that is not linear inside one key interval).
usage: python3 scripts/gnn/verify_gnn_x3d.py TRACE.json SCENE.x3d BUILD_REPORT.json"""
import bisect, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scene"))
sys.argv, _argv = sys.argv[:1], sys.argv
import flywheel_scene as G                                          # noqa: E402
sys.argv = _argv


def lin(keys, vals, f):
    i = bisect.bisect_right(keys, f)
    if i <= 0:
        return vals[0]
    if i >= len(keys):
        return vals[-1]
    u = (f - keys[i - 1]) / (keys[i] - keys[i - 1]) if keys[i] > keys[i - 1] else 0.0
    return tuple(a + (b - a) * u for a, b in zip(vals[i - 1], vals[i]))


def main(trace_path, x3d_path, rep_path):
    trace, rep = json.load(open(trace_path)), json.load(open(rep_path))
    model = G.FlywheelModel(trace, step=rep["step"], n_frames=rep["frames"])
    s = open(x3d_path, encoding="utf-8").read()
    interp = {}
    for m in re.finditer(r'<PositionInterpolator DEF="(PI|SI)_(\w+)" key="([^"]*)" keyValue="([^"]*)"', s):
        keys = [float(x) for x in m.group(3).split()]
        flat = [float(x) for x in m.group(4).split()]
        interp[(m.group(1), m.group(2))] = (keys, [tuple(flat[i * 3:(i + 1) * 3]) for i in range(len(keys))])
    xf = {}
    for m in re.finditer(r'<Transform DEF="OB_(\w+)" translation="([^"]*)" rotation="[^"]*" scale="([^"]*)"', s):
        xf[m.group(1)] = (tuple(float(x) for x in m.group(2).split()), tuple(float(x) for x in m.group(3).split()))
    nf, step = model.nf, rep["step"]
    key_frames = list(range(1, nf + 1, step)) + ([nf] if (nf - 1) % step else [])
    worst = {k: [0.0, None] for k in ("key_translation", "key_scale", "all_translation", "all_scale")}
    allerr = {"t": [], "s": []}
    counts = dict(animated_objects=0, with_interpolator=0, static=0, missing=0)
    for it in model.items:
        tr = it.get("track")
        if tr is None:
            continue
        name = it["name"]
        if name not in xf:
            counts["missing"] += 1
            print("MISSING Transform for", name)
            continue
        counts["animated_objects"] += 1
        t0, s0 = xf[name]
        counts["with_interpolator" if (("PI", name) in interp or ("SI", name) in interp) else "static"] += 1
        for frame in range(1, nf + 1):
            f = (frame - 1) / (nf - 1)
            loc, sc = tr.at(f * model.D)
            iskey = frame in key_frames
            if loc is not None and max(sc) > 1e-4:
                want = (loc[0], loc[2], -loc[1])
                got = lin(*interp[("PI", name)], f) if ("PI", name) in interp else t0
                e = max(abs(a - b) for a, b in zip(want, got))
                allerr["t"].append(e)
                for k, ok in (("all_translation", True), ("key_translation", iskey)):
                    if ok and e > worst[k][0]:
                        worst[k] = [e, (name, frame)]
            got = lin(*interp[("SI", name)], f) if ("SI", name) in interp else s0
            e = max(abs(a - b) for a, b in zip(sc, got))
            allerr["s"].append(e)
            for k, ok in (("all_scale", True), ("key_scale", iskey)):
                if ok and e > worst[k][0]:
                    worst[k] = [e, (name, frame)]
    pct = lambda a, q: sorted(a)[int(q * (len(a) - 1))] if a else 0.0
    out = dict(counts=counts, frames=nf, step=step, key_frames=len(key_frames),
               worst={k: [round(v[0], 6), v[1]] for k, v in worst.items()},
               between_keys_p99=dict(translation=round(pct(allerr["t"], 0.99), 5), scale=round(pct(allerr["s"], 0.99), 5)),
               note="key-frame error must be <= 3e-3 (compaction eps + rounding); between-key error is how far linear interpolation strays from the per-frame handler")
    print(json.dumps(out))
    return 0 if max(worst["key_translation"][0], worst["key_scale"][0]) <= 3e-3 and counts["missing"] == 0 else 2


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
