#!/usr/bin/env python3
"""Tests for the flywheel showcase: honesty of the trace, consistency of the real loop results, tether verdicts, scene model. python3 -m pytest -q scripts/flywheel/test_flywheel.py"""
import json, os, re, sys
import pytest
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
TR = os.path.join(ROOT, "traces", "x3d-flywheel.trace.json")
LOOP = os.path.join(ROOT, "out", "flywheel", "loop.json")
FACTS = os.path.join(ROOT, "out", "flywheel", "facts.json")
VENDOR = re.compile(r"gemini|gpt-|glm-|nemotron|vertex|openai|nvidia", re.I)


@pytest.fixture(scope="module")
def trace():
    return json.load(open(TR))


def test_trace_is_real_and_has_no_vendor_or_model_names(trace):
    assert trace["schema"] == "x3d-trace/1" and trace["source"]["kind"] == "x3d-flywheel" and trace["source"]["synthetic"] is False
    assert not VENDOR.search(json.dumps(trace)), "project rule: no vendor or model names on public pages"
    assert not VENDOR.search(open(os.path.join(ROOT, "scenes", "x3d-flywheel.x3d"), encoding="utf-8").read())
    assert trace["source"]["provenance"]["loop_placeholder"] is False


def test_every_fact_has_a_grade_and_a_source():
    facts = json.load(open(FACTS))
    assert len(facts) >= 18 and all(v["grade"] in ("C", "R") and v["source"] for v in facts.values())
    assert facts["x3duom.4_1"]["value"]["concrete_nodes"] == 267 and "GaussianSplats" in facts["x3duom.4_1"]["value"]["new_in_4_1"]


def test_real_loop_results_are_consistent():
    R = json.load(open(LOOP))["results"]
    assert R["defect"]["xsd_valid"] is True and R["defect"]["semantic_errors"] > 0          # the defect is invisible to XSD but not to the semantic checks
    assert R["repair"]["semantic_errors_after"] == 0 and R["validate"]["xsd_valid"] and R["validate"]["errors"] == 0
    assert R["validate"]["cold_ms"] > R["validate"]["warm_ms"] > 0 and R["render"]["nonblank_pct"] > 30


def test_tether_verdicts_match_the_documented_design():
    T = json.load(open(LOOP))["results"]["tether"]
    assert T["verdict"] == "verified" and len(T["steps"]) >= 7
    st = {t["what"]: t["status"] for t in T["tamper"]}
    assert st["edit after the last step"] == "stale" and st["delete a step"] == "broken-chain" and st["flip the LAST step"] == "verified"


def test_stamped_scene_verifies():
    f = json.load(open(os.path.join(ROOT, "out", "flywheel", "final.json")))     # written by run_loop.py final (x3dprov.verify on the stamped file; needs lxml, so recorded)
    assert f["verify"]["status"] == "verified" and f["verify"]["steps"] == 3 and f["xsd_valid"] and f["semantic"][0] == 0


def test_insight_numbers_are_in_the_trace(trace):
    for c in trace["flywheel"]["insights"]:
        vals = [float(v) for v in c["numbers"].values() if isinstance(v, (int, float))]
        for tok in re.findall(r"(?<![\w.,])\d+(?:\.\d+)?(?![\w,])", c["text"].replace(",", "")):
            strs = " ".join(str(v) for v in c["numbers"].values() if isinstance(v, str))                 # version strings such as 2.6.4
            assert tok in strs or any(abs(float(tok) - x) <= max(0.006 * abs(x), 0.5) for x in vals), (c["id"], tok)
        assert c["grade"] in ("C", "R")


def test_scene_model_builds(trace):
    sys.path.insert(0, os.path.join(ROOT, "scripts", "scene"))
    argv, sys.argv = sys.argv, sys.argv[:1]
    try:
        import flywheel_scene
    finally:
        sys.argv = argv
    m = flywheel_scene.FlywheelModel(trace)
    assert 250 < len(m.items) < 500 and len({i["name"] for i in m.items}) == len(m.items) and not m.syn
