import sys, addon_utils, bpy, collections
bpy.ops.wm.read_factory_settings(use_empty=True)
addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
bpy.ops.import_scene.x3d(filepath=sys.argv[sys.argv.index("--")+1])
rows=[(len(o.data.loops), len(o.data.vertices), o.name, o.data.name, len(o.data.uv_layers), len(o.data.attributes)) for o in bpy.context.scene.objects if o.type=="MESH"]
rows.sort(reverse=True)
print("STATS meshes", len(rows), "distinct data", len({o.data.name for o in bpy.context.scene.objects if o.type=="MESH"}), "total loops", sum(r[0] for r in rows))
for r in rows[:4]: print("TOP", r)
print("TYPES", dict(collections.Counter(o.type for o in bpy.context.scene.objects)))
