import sys, time, addon_utils, bpy
bpy.ops.wm.read_factory_settings(use_empty=True)
addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
bpy.ops.import_scene.x3d(filepath=sys.argv[sys.argv.index("--")+1])
fonts=[o for o in bpy.context.scene.objects if o.type=="FONT"]
print("FONTS", len(fonts), "chars", sum(len(o.data.body) for o in fonts), flush=True)
for o in list(fonts): bpy.data.objects.remove(o)
for o in bpy.context.scene.objects: o.select_set(True)
t=time.perf_counter(); r=bpy.ops.export_scene.x3d(filepath="/tmp/nofont.x3d", check_existing=False, x3d_version="X3D40", use_animation=False)
print("EXPORT without FONT objects", r, "%.2fs"%(time.perf_counter()-t), flush=True)
