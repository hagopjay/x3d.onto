import time, addon_utils, bpy
bpy.ops.wm.read_factory_settings(use_empty=True)
addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
for n in (1,4,16):
    bpy.ops.wm.read_factory_settings(use_empty=True); addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
    for i in range(n):
        bpy.ops.object.text_add(location=(0,i*2,0)); bpy.context.object.data.body="member 9: the model says Officer"
    for o in bpy.context.scene.objects: o.select_set(True)
    t=time.perf_counter(); bpy.ops.export_scene.x3d(filepath="/tmp/f1.x3d", check_existing=False, x3d_version="X3D40", use_selection=True); print("FONTEXPORT n=%d %.2fs"%(n,time.perf_counter()-t), flush=True)
