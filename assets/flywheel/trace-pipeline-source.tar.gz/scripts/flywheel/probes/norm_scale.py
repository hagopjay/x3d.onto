import sys, time, addon_utils, bpy
addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
def run(n, normals):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
    for i in range(n):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3, location=(i*3,0,0))
    for o in bpy.context.scene.objects: o.select_set(True)
    t=time.perf_counter(); bpy.ops.export_scene.x3d(filepath="/tmp/ns.x3d", check_existing=False, x3d_version="X3D40", use_normals=normals, use_selection=True)
    return time.perf_counter()-t
for n in (8,16,32,64):
    print("SCALE n=%d normals=False %.2fs"%(n, run(n,False)), flush=True)
