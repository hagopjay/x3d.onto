import sys, time, addon_utils, bpy
bpy.ops.wm.read_factory_settings(use_empty=True)
addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
t=time.perf_counter(); r=bpy.ops.import_scene.x3d(filepath=sys.argv[sys.argv.index("--")+1]); print("IMPORT", r, "%.2fs"%(time.perf_counter()-t), "objects", len(bpy.data.objects))
