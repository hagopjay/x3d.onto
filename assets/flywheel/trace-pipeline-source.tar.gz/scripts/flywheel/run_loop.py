#!/usr/bin/env python3
"""run_loop.py: executes the toolchain loop FOR REAL on the flywheel scene and writes out/flywheel/loop.json.
  mode loop :  ground (MCP describe_node) -> build (Blender headless + fork exporter, pass-1 scene) -> validate (MCP xsd + semantic) -> repair (a profile defect is INJECTED on purpose,
               MCP validate_semantic finds it, MCP repair_x3d fixes it) -> revalidate -> render (X_ITE headless, non-blank %) -> Blender round trip (fork import + export) -> stamp (x3dprov chain + verify + tamper tests)
  mode final:  validate + render + stamp the pass-2 scene and write the stamped scenes/x3d-flywheel.x3d
Run with the x3d_mcp venv python (needs the mcp client):  ~/Projects/x3d/x3d_mcp/.venv/bin/python scripts/flywheel/run_loop.py [loop|final]"""
import asyncio, json, os, re, subprocess, sys, time
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
OUT = os.path.join(ROOT, "out", "flywheel")
X = os.path.expanduser("~/Projects/x3d")
MCP = X + "/x3d_mcp"
BLENDER = os.environ.get("BLENDER", "/Applications/Blender.app/Contents/MacOS/Blender")
sys.path.insert(0, X + "/x3d.ML/src")
import x3dprov                                                  # noqa: E402
ENV = dict(os.environ, NODE_PATH=os.environ.get("NODE_PATH", "/tmp/node_modules"), XITE_DIST=os.environ.get("XITE_DIST", "/tmp/xite-pack/pkg/package/dist"),
           CHROME_PATH=os.environ.get("CHROME_PATH", os.path.expanduser("~/Library/Caches/ms-playwright/chromium-1155/chrome-mac/Chromium.app/Contents/MacOS/Chromium")))
CLK = time.perf_counter
RENDER_MODE = "full"
TYPES = ["X3D", "Transform", "Shape", "Appearance", "PhysicalMaterial", "IndexedFaceSet", "Coordinate", "PositionInterpolator", "TimeSensor", "Text", "FontStyle", "Billboard", "Viewpoint", "DirectionalLight", "NavigationInfo", "Background", "IndexedLineSet"]


def git(d):
    return subprocess.check_output(["git", "-C", d, "rev-parse", "--short", "HEAD"], text=True).strip()


def counts(sem):
    m = re.search(r"Found (\d+) error\(s\), (\d+) warning\(s\), (\d+) info\(s\)", sem)
    return tuple(int(x) for x in m.groups()) if m else (-1, -1, -1)


def codes(sem):
    return sorted(set(re.findall(r"\*\*\[([\w-]+)\]\*\*", sem.split("## Info")[0])))


def nonblank_pct(png):
    return float(subprocess.check_output(["python3", os.path.join(ROOT, "scripts/flywheel/nonblank.py"), png], text=True).strip())


def render(x3d, prefix, frac="0.5", mode="full"):
    """Lean X_ITE render (scripts/flywheel/render_quick.js) with a cache keyed by the scene's content hash. mode: full | cached (reuse a cache hit, else render) | skip (reuse the newest cache entry)."""
    import hashlib, glob
    key = hashlib.sha256(open(x3d, "rb").read()).hexdigest()[:16]
    cdir = os.path.join(OUT, "cache"); os.makedirs(cdir, exist_ok=True)
    cf = os.path.join(cdir, "render-%s.json" % key)
    shot = "%s-f000.png" % prefix
    if mode in ("cached", "skip") and os.path.exists(cf):
        c = json.load(open(cf)); c["cached"] = True
        return shot, c["nonblank_pct"], c
    if mode == "skip":
        olds = sorted(glob.glob(os.path.join(cdir, "render-*.json")), key=os.path.getmtime)
        if olds:
            c = json.load(open(olds[-1])); c["cached"] = True; c["stale_cache"] = True
            return shot, c["nonblank_pct"], c
    t = CLK()
    err = None
    for attempt in (1, 2):                                      # a loaded machine can time the page out once: retry, and never cache a failure
        if os.path.exists(shot):
            os.remove(shot)
        p = subprocess.run(["node", os.path.join(ROOT, "scripts/flywheel/render_quick.js"), x3d, prefix, frac], env=ENV, capture_output=True, text=True, timeout=400, cwd=ROOT)
        try:
            err = json.loads(p.stdout.strip().splitlines()[-1]).get("error")
        except Exception:
            err = "no output from render_quick.js: " + (p.stderr or "")[-200:]
        if os.path.exists(shot) and not err:
            break
    pct = nonblank_pct(shot) if os.path.exists(shot) else 0.0
    c = dict(nonblank_pct=pct, render_ms=(CLK() - t) * 1e3, key=key, attempts=attempt, error=err)
    if os.path.exists(shot) and not err:
        json.dump(c, open(cf, "w"))
    return shot, pct, c


async def session():
    p = StdioServerParameters(command=MCP + "/.venv/bin/python", args=["-m", "src.server"], cwd=MCP)
    return stdio_client(p)


def T(res):
    return "".join(getattr(c, "text", "") for c in res.content)


async def loop_mode():
    os.makedirs(OUT, exist_ok=True)
    stages, R, t0 = [], {}, CLK()

    def mark(key, t_in, metrics=None):
        t_out = CLK()
        stages.append(dict(key=key, start_s=t_in - t0, end_s=t_out - t0, wall_ms=(t_out - t_in) * 1e3, metrics=metrics or {}))

    async with (await session()) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            call = lambda n, a: s.call_tool(n, a)
            # 1 ground: ask the spec (X3DUOM via MCP) about every node type the exporter will write
            t = CLK(); nf = 0; ok = 0
            for ty in TYPES:
                d = T(await call("describe_node", {"node_type": ty}))
                try:
                    j = json.loads(d)
                    nf += len(j.get("fields", [])) if isinstance(j, dict) else 0; ok += 1
                except ValueError:
                    ok += 1 if len(d) > 50 else 0
            R["grounding"] = dict(types=ok, fields=nf, ms=(CLK() - t) * 1e3)
            mark("ground", t, dict(records_out=ok))
            # 2 build: Blender headless + fork exporter
            t = CLK()
            subprocess.run([BLENDER, "-b", "--factory-startup", "-noaudio", "--python", ROOT + "/scripts/scene/flywheel_scene.py", "--", "--fw-trace", ROOT + "/traces/x3d-flywheel.trace.json",
                            "--fw-out-x3d", OUT + "/loop.x3d", "--fw-report", OUT + "/loop.build.json"], capture_output=True, text=True, timeout=600)
            mark("build", t, dict(records_out=1))
            rep = json.load(open(OUT + "/loop.build.json"))
            R["file"] = dict(bytes=rep["bytes"], objects=rep["objects"], interpolators=rep["interpolators"], interpolator_pct=rep["interpolator_pct"])
            xml = open(OUT + "/loop.x3d", encoding="utf-8").read()
            chain = x3dprov.add_step(xml, dict(op="generate", agent="flywheel_scene.py + x3d_blender_io", agent_ref=git(X + "/x3d-blender-io"), tool="Blender 5.1 headless"))
            # 3 validate
            t = CLK(); t0_val = t
            v = json.loads(T(await call("validate_x3d", {"content": xml, "encoding": "xml"})))
            sem = T(await call("validate_semantic", {"content": xml}))
            e, wn, inf = counts(sem)
            cold_ms = (CLK() - t) * 1e3
            tw = CLK()                                          # the same validation again: warm (schemas already loaded)
            await call("validate_x3d", {"content": xml, "encoding": "xml"}); await call("validate_semantic", {"content": xml})
            warm_ms = (CLK() - tw) * 1e3
            R["validate"] = dict(xsd_valid=bool(v.get("valid")), errors=e, warnings=wn, infos=inf, cold_ms=cold_ms, warm_ms=warm_ms)
            t = tw
            mark("validate", t0_val, dict(records_out=inf))
            chain = x3dprov.add_step(chain, dict(op="validate", validator="x3d_mcp", validator_ref=git(MCP), xsd=True, xsd_valid=R["validate"]["xsd_valid"], semantic_error_codes=codes(sem), verdict="valid" if e == 0 and v.get("valid") else "invalid"))
            # 4 repair: INJECT a profile defect (deliberate), find it with MCP, repair with MCP
            t = CLK()
            bad = re.sub(r'profile="[^"]*"', 'profile="Core"', xml, count=1)
            chain = x3dprov.add_step(chain, dict(op="transform", tool="defect injection", detail="profile set to Core on purpose (the commonest real failure class: profile-component)"), xml_after=bad)
            vb = json.loads(T(await call("validate_x3d", {"content": bad, "encoding": "xml"})))
            semb = T(await call("validate_semantic", {"content": bad}))
            eb = counts(semb)[0]
            chain = x3dprov.add_step(chain, dict(op="validate", validator="x3d_mcp", validator_ref=git(MCP), xsd=True, xsd_valid=bool(vb.get("valid")), semantic_error_codes=codes(semb), verdict="invalid"))
            rp = json.loads(T(await call("repair_x3d", {"content": bad})))
            fixed = rp["fixed"]
            sema = T(await call("validate_semantic", {"content": fixed}))
            R["defect"] = dict(kind="profile=Core", xsd_valid=bool(vb.get("valid")), semantic_errors=eb, codes=codes(semb))
            R["repair"] = dict(semantic_errors_after=counts(sema)[0], fixes=len(rp.get("fixes", rp.get("applied", []))) if isinstance(rp, dict) else 0, keys=sorted(rp.keys()))
            mark("repair", t, dict(records_out=eb))
            chain = x3dprov.add_step(chain, dict(op="repair", kind="deterministic", tool="x3d_mcp repair_x3d", fixes=R["repair"]["fixes"], round=1, report_shown=eb), xml_after=fixed)
            # 5 revalidate
            t = CLK()
            v2 = json.loads(T(await call("validate_x3d", {"content": fixed, "encoding": "xml"})))
            e2 = counts(T(await call("validate_semantic", {"content": fixed})))[0]
            mark("revalidate", t, dict(records_out=e2))
            chain = x3dprov.add_step(chain, dict(op="validate", validator="x3d_mcp", validator_ref=git(MCP), xsd=True, xsd_valid=bool(v2.get("valid")), semantic_error_codes=[], verdict="valid" if e2 == 0 and v2.get("valid") else "invalid"))
            open(OUT + "/loop.fixed.x3d", "w", encoding="utf-8").write(chain)
            # 6 render (X_ITE headless)
            t = CLK()
            shot, pct, rc = render(OUT + "/loop.fixed.x3d", OUT + "/loop", mode=RENDER_MODE)
            R["render"] = dict(nonblank_pct=pct, load_ok=(os.path.exists(shot) and not rc.get("error")) or bool(rc.get("cached")), shot=os.path.relpath(shot, ROOT), cached=bool(rc.get("cached")), render_ms=rc.get("render_ms"), error=rc.get("error"), attempts=rc.get("attempts"))
            mark("render", t, dict(records_out=1))
            chain = x3dprov.add_step(chain, dict(op="render", renderer="X_ITE 16.4.3 headless (software GL)", nonblank_ratio=round(pct / 100, 4), load_ok=R["render"]["load_ok"]))
            # 7 Blender round trip with the fork (does the record survive?)
            t = CLK()
            open(OUT + "/loop.rt-in.x3d", "w", encoding="utf-8").write(chain)
            rtp = subprocess.run([BLENDER, "-b", "--factory-startup", "-noaudio", "--python", ROOT + "/scripts/flywheel/blender_roundtrip.py", "--", OUT + "/loop.rt-in.x3d", OUT + "/loop.rt-out.x3d"], capture_output=True, text=True, timeout=300)
            mj = re.search(r"ROUNDTRIP_JSON (\{.*\})", rtp.stdout)
            fonts = eval(mj.group(1)) if mj else {}
            rt = open(OUT + "/loop.rt-out.x3d", encoding="utf-8").read() if os.path.exists(OUT + "/loop.rt-out.x3d") else ""
            n_in, n_out = len(x3dprov.read_steps(chain)), len(x3dprov.read_steps(rt))
            R["roundtrip"] = dict(meta_kept=(n_out == n_in and n_in > 0), steps_before=n_in, steps_after=n_out, bytes_in=len(chain.encode()), bytes_out=len(rt.encode()), **fonts)
            mark("roundtrip", t, dict(records_out=n_out))
            final = x3dprov.add_step(chain, dict(op="transform", tool="Blender round trip (x3d_blender_io import + export)", agent_ref=git(X + "/x3d-blender-io"), record_kept_by_blender=R["roundtrip"]["meta_kept"]), xml_after=rt or chain)
            # 8 stamp: verify + tamper tests
            t = CLK()
            ver = x3dprov.verify(final)
            tam = []
            mut = re.sub(r'(keyValue=")([0-9.\-]+)', lambda m: m.group(1) + str(float(m.group(2)) + 1.0), final, count=1)
            tam.append(dict(what="edit after the last step", status=x3dprov.verify(mut)["status"]))
            steps = x3dprov.read_steps(final)
            dele = re.sub(r'<meta name="x3dprov\.step\.2"[^>]*/>', "", final, count=1)
            tam.append(dict(what="delete a step", status=x3dprov.verify(dele)["status"]))
            last = steps[-1][1]
            flip = final.replace(last.replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;"), last.replace("true", "false").replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;"), 1)
            tam.append(dict(what="flip the LAST step", status=x3dprov.verify(flip)["status"]))
            R["tether"] = dict(verdict=ver["status"], steps=[dict(op=json.loads(c)["op"], hash8=json.loads(c)["output_sha256"][:8], agent=json.loads(c).get("agent") or json.loads(c).get("tool") or json.loads(c).get("validator") or json.loads(c).get("renderer")) for n, c in steps], tamper=tam, problems=ver["problems"])
            mark("stamp", t, dict(records_out=len(steps)))
    loop = dict(placeholder=False, stages=stages, results=R, finished_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    json.dump(loop, open(OUT + "/loop.json", "w"), indent=1)
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import history
    history.append(loop)
    print("LOOP", " | ".join("%s %.1f ms" % (s["key"], s["wall_ms"]) for s in stages))
    print("validate", R["validate"], "| defect", R["defect"]["semantic_errors"], "errors (xsd_valid=%s) -> after repair %s" % (R["defect"]["xsd_valid"], R["repair"]["semantic_errors_after"]), "| render %.1f%%" % R["render"]["nonblank_pct"])
    print("roundtrip", R["roundtrip"], "| tether", R["tether"]["verdict"], [(x["what"], x["status"]) for x in R["tether"]["tamper"]])


async def final_mode():
    """Pass 2: the scene built from the real loop results: validate with MCP, render, stamp, write scenes/x3d-flywheel.x3d."""
    xml = open(ROOT + "/scenes/x3d-flywheel.x3d", encoding="utf-8").read()
    async with (await session()) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            t = CLK()
            v = json.loads(T(await s.call_tool("validate_x3d", {"content": xml, "encoding": "xml"})))
            sem = T(await s.call_tool("validate_semantic", {"content": xml}))
            vms = (CLK() - t) * 1e3
    e, wn, inf = counts(sem)
    shot, pct, rc = render(ROOT + "/scenes/x3d-flywheel.x3d", OUT + "/final", mode=RENDER_MODE)
    chain = x3dprov.add_step(xml, dict(op="generate", agent="flywheel_scene.py + x3d_blender_io", agent_ref=git(X + "/x3d-blender-io"), tool="Blender 5.1 headless, pass 2 (built from the real loop results)"))
    chain = x3dprov.add_step(chain, dict(op="validate", validator="x3d_mcp", validator_ref=git(MCP), xsd=True, xsd_valid=bool(v.get("valid")), semantic_error_codes=codes(sem), verdict="valid" if e == 0 and v.get("valid") else "invalid", ms=round(vms, 1)))
    chain = x3dprov.add_step(chain, dict(op="render", renderer="X_ITE 16.4.3 headless (software GL)", nonblank_ratio=round(pct / 100, 4), load_ok=os.path.exists(shot) or bool(rc.get("cached")), cached=bool(rc.get("cached"))))
    open(ROOT + "/scenes/x3d-flywheel.x3d", "w", encoding="utf-8").write(chain)
    ver = x3dprov.verify(chain)
    print("FINAL xsd_valid=%s semantic errors=%d infos=%d render=%.1f%% tether=%s steps=%d" % (v.get("valid"), e, inf, pct, ver["status"], ver["steps"]))
    json.dump(dict(xsd_valid=bool(v.get("valid")), semantic=[e, wn, inf], render_pct=pct, verify=ver), open(OUT + "/final.json", "w"), indent=1)


if __name__ == "__main__":
    if "--render" in sys.argv:
        RENDER_MODE = sys.argv[sys.argv.index("--render") + 1]
    asyncio.run(final_mode() if (sys.argv[1:] or ["loop"])[0] == "final" else loop_mode())
