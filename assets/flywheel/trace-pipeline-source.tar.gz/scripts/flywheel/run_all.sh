#!/bin/bash
# The X3D flywheel showcase end to end: facts -> (pass 1 scene) -> REAL loop on it -> real trace -> (pass 2 scene) -> stamp -> every check. About 6 minutes (the X_ITE renders dominate).
#   scripts/flywheel/run_all.sh        Needs: x3d_mcp venv, Blender 5.1 + the fork add-on, node/playwright/Chromium/X_ITE dist (see scripts/gnn/run_all.sh), x3d.ML checkout (x3dprov)
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
BLENDER=${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}; MCPPY=${MCPPY:-$HOME/Projects/x3d/x3d_mcp/.venv/bin/python}
export NODE_PATH=${NODE_PATH:-/tmp/node_modules} XITE_DIST=${XITE_DIST:-/tmp/xite-pack/pkg/package/dist}
export CHROME_PATH=${CHROME_PATH:-$HOME/Library/Caches/ms-playwright/chromium-1155/chrome-mac/Chromium.app/Contents/MacOS/Chromium}
mkdir -p out/flywheel scenes traces; LOG=out/flywheel/checks.log; : > $LOG; step() { echo "=== $1" | tee -a $LOG; }
step "1 facts (MCP queries, X3DUOM parse, fork + recorded live run)"; $MCPPY scripts/flywheel/collect_facts.py 2>&1 | grep -E "^facts" | tee -a $LOG
step "2 pass 1: stub trace + the REAL loop (ground, build, validate, defect+repair, revalidate, render, Blender round trip, stamp)"
python3 scripts/flywheel/make_trace.py --stub | tee -a $LOG; $MCPPY scripts/flywheel/run_loop.py loop 2>&1 | grep -E "^LOOP|^validate|^roundtrip|Error|Traceback" | cut -c1-600 | tee -a $LOG
step "3 pass 2: real trace -> scene -> stamp (x3dprov) + MCP validate + render"
python3 scripts/flywheel/make_trace.py | tee -a $LOG
$BLENDER -b --factory-startup -noaudio --python scripts/scene/flywheel_scene.py -- --fw-trace traces/x3d-flywheel.trace.json --fw-out-x3d scenes/x3d-flywheel.x3d --fw-report out/flywheel/build.json 2>&1 | grep -E "RESULT|Error|Traceback" | tee -a $LOG
$MCPPY scripts/flywheel/run_loop.py final 2>&1 | grep -E "^FINAL|Error|Traceback" | tee -a $LOG
step "4 tests"; python3 -m pytest -q scripts/flywheel/test_flywheel.py 2>&1 | tail -2 | tee -a $LOG
step "5 exported motion vs trace"; python3 scripts/flywheel/verify_fw_x3d.py traces/x3d-flywheel.trace.json scenes/x3d-flywheel.x3d out/flywheel/build.json | cut -c1-300 | tee -a $LOG
step "6 numbers shown vs trace"; python3 scripts/gnn/audit_numbers_gnn.py traces/x3d-flywheel.trace.json scenes/x3d-flywheel.x3d | tee -a $LOG
step "7 X_ITE render check"; rm -f out/flywheel/fw-*.png
node scripts/flywheel/render_check_fw.js scenes/x3d-flywheel.x3d out/flywheel/fw 0.12,0.55,0.93 CA_VP3_Wheel@0.45 CA_VP4_Tether@0.95 CA_VP5_Evidence@0.78 CA_VP2_Overview@0.5 2>&1 | tail -1 | cut -c1-200 | tee -a $LOG
python3 scripts/scene/image_stats.py out/flywheel fw | tail -2 | head -1 | tee -a $LOG
rm -rf scripts/*/__pycache__ .pytest_cache; echo done | tee -a $LOG
