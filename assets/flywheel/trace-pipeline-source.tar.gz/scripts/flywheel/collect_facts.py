#!/usr/bin/env python3
"""Collects the REAL facts the flywheel showcase shows, each with a grade: C = measured/queried right now by this script, R = recorded elsewhere (path given).
Writes out/flywheel/facts.json. Model names of the recorded live run are anonymised (model A..E) per the project rule for public pages."""
import asyncio, glob, json, os, re, statistics, subprocess, sys, time
import xml.etree.ElementTree as ET
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
X = os.path.expanduser("~/Projects/x3d")
MCP = X + "/x3d_mcp"
ADDON = os.path.expanduser("~/Library/Application Support/Blender/5.1/extensions/user_default/x3d_blender_io")
F = {}


def put(key, value, grade, source):
    F[key] = dict(value=value, grade=grade, source=source)


def git(d):
    try:
        return subprocess.check_output(["git", "-C", d, "rev-parse", "--short", "HEAD"], text=True).strip()
    except Exception:
        return None


async def mcp_facts():
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    p = StdioServerParameters(command=MCP + "/.venv/bin/python", args=["-m", "src.server"], cwd=MCP)
    txt = lambda r: "".join(getattr(c, "text", "") for c in r.content)
    async with stdio_client(p) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            t0 = time.perf_counter()
            tools = (await s.list_tools()).tools
            put("mcp.tools", dict(count=len(tools), names=[t.name for t in tools]), "C", "MCP list_tools")
            comps = txt(await s.call_tool("list_components", {}))
            put("mcp.components_raw", comps[:1500], "C", "MCP list_components")
            prof = txt(await s.call_tool("list_profiles", {}))
            put("mcp.profiles_raw", prof[:900], "C", "MCP list_profiles")
            gs = txt(await s.call_tool("describe_node", {"node_type": "GaussianSplats"}))
            put("mcp.describe_GaussianSplats", gs[:1200], "C", "MCP describe_node (a 4.1-only node)")
            par = txt(await s.call_tool("node_parents", {"node_type": "Shape"}))
            put("mcp.node_parents_Shape", par[:600], "C", "MCP node_parents (ontology relationship query)")
            q = txt(await s.call_tool("query_ontology", {"sparql": "SELECT (COUNT(*) AS ?n) WHERE { ?s ?p ?o }"}))
            put("mcp.ontology_triples_raw", q[:400], "C", "MCP query_ontology SPARQL count")
            q2 = txt(await s.call_tool("query_ontology", {"sparql": "PREFIX owl: <http://www.w3.org/2002/07/owl#> SELECT (COUNT(DISTINCT ?c) AS ?n) WHERE { ?c a owl:Class }"}))
            put("mcp.ontology_classes_raw", q2[:400], "C", "MCP query_ontology SPARQL count")
            put("mcp.facts_wall_ms", round((time.perf_counter() - t0) * 1e3, 1), "C", "wall time of these MCP calls (incl. ontology load)")


def schema_facts():
    sd = MCP + "/src/validation/schemas"
    uom = ET.parse(sd + "/X3dUnifiedObjectModel-4.1.xml").getroot()
    conc = [c.get("name") for c in uom.find("ConcreteNodes")]
    old = {c.get("name") for c in ET.parse(sd + "/X3dUnifiedObjectModel-4.0.xml").getroot().find("ConcreteNodes")}
    new = sorted(set(conc) - old)
    put("x3duom.4_1", dict(concrete_nodes=len(conc), abstract_node_types=len(uom.find("AbstractNodeTypes")), field_types=len(uom.find("FieldTypes")),
                           statements=len(uom.find("Statements")), concrete_nodes_4_0=len(old), new_in_4_1=new), "C", "X3dUnifiedObjectModel-4.1.xml vs 4.0.xml parsed now")
    js = json.load(open(sd + "/x3d-4.0-JSONSchema.json"))
    put("schemas", dict(files=sorted(os.listdir(sd)), json_schema_defs=len(js.get("$defs", {})), xsd_4_1_bytes=os.path.getsize(sd + "/x3d-4.1.xsd"),
                        ontology_ttl_bytes=os.path.getsize(sd + "/X3dOntology4.0.ttl")), "C", "x3d_mcp/src/validation/schemas")


def fork_facts():
    man = open(ADDON + "/blender_manifest.toml").read()
    ver = re.search(r'^version = "([^"]+)"', man, re.M).group(1)
    binfo = re.search(r'"version": \((\d+), (\d+), (\d+)\)', open(ADDON + "/__init__.py").read())
    put("fork.addon", dict(manifest_version=ver, bl_info_version=".".join(binfo.groups()), fork_head=git(X + "/x3d-blender-io"), modules=sorted(os.path.basename(p) for p in glob.glob(ADDON + "/*.py")),
                           tagline=re.search(r'tagline = "([^"]+)"', man).group(1)), "C", "installed add-on manifest + __init__ (note: manifest and bl_info versions differ)")
    put("mcp.head", git(MCP), "C", "git rev-parse x3d_mcp")
    put("fork.test_suite", dict(cases=194, core_pass=143, core_total=147, warnings=19, roadmap_missing=26, vs_version="2.6.1 (a4238a6)", skinning_error_mm=2),
        "R", "x3d-blender-io/docs/test-suite/SUITE_COMMENTARY.md (recorded run, X_ITE 16.5.1)")
    import importlib.util
    spec = importlib.util.spec_from_file_location("x3d_registry_probe", ADDON + "/x3d_registry.py")
    mod = importlib.util.module_from_spec(spec); sys.modules["x3d_registry_probe"] = mod; spec.loader.exec_module(mod)
    put("fork.registry_nodes", len(mod.REGISTRY), "C", "installed add-on x3d_registry.REGISTRY (field-spec registry, not the full exporter coverage)")
    src = sum(len(open(p).read().splitlines()) for p in glob.glob(ADDON + "/*.py"))
    put("fork.source_lines", src, "C", "line count of the installed add-on *.py")


def live_facts():
    d = json.load(open(X + "/x3d.ML/demo/data/live.json"))
    names = {}
    for it in d["items"]:
        names.setdefault(it["m"], len(names))
    label = lambda m: "model " + "ABCDE"[names[m]]
    per, codes = {}, {}
    vms_all, call_all = [], []
    for it in d["items"]:
        a = it["A"]
        m = label(it["m"])
        e = per.setdefault(m, dict(scenes=0, first=0, end=0, calls=0, call_s=[], tok_out=0))
        e["scenes"] += 1; e["first"] += 1 if a[0]["ok"] else 0; e["end"] += 1 if a[-1]["ok"] else 0; e["calls"] += len(a)
        for at in a:
            e["call_s"].append(at["ms"] / 1000); call_all.append(at["ms"] / 1000); vms_all.append(float(at["vms"])); e["tok_out"] += at.get("to", 0)
        if not a[0]["ok"]:
            if not a[0]["x"]:
                codes["xsd"] = codes.get("xsd", 0) + 1
            for l in a[0].get("se") or []:
                mm = re.search(r"\*\*\[([\w-]+)\]\*\*", l)
                if mm:
                    codes[mm.group(1)] = codes.get(mm.group(1), 0) + 1
    out = []
    for m, e in sorted(per.items()):
        out.append(dict(model=m, scenes=e["scenes"], first_try_valid=e["first"], valid_at_end=e["end"], calls=e["calls"], median_call_s=round(statistics.median(e["call_s"]), 1)))
    put("live_run", dict(models=out, scenes=len(d["items"]), calls=sum(o["calls"] for o in out), median_validate_ms=round(statistics.median(vms_all), 2),
                         p90_validate_ms=round(sorted(vms_all)[int(0.9 * len(vms_all))], 2), median_call_s=round(statistics.median(call_all), 1), first_fail_codes=dict(sorted(codes.items(), key=lambda kv: -kv[1])[:6]),
                         valid_not_visible="7 of 178 scenes valid at the end draw nothing in X_ITE", date=d["meta"].get("date"), validator=d["meta"]["validator"], max_attempts=d["meta"]["max_attempts"]),
        "R", "x3d.ML/demo/data/live.json (recorded 17 Oct 2026; aggregates recomputed here; 'valid_not_visible' from x3d.ML/docs/LIVE-RUN-FINDINGS.md finding 6)")


def misc():
    put("runtimes", dict(x_ite_local="16.4.3 (pinned dist used for every render check here)", x_ite_live_run="16.5.0 (x3d.ML live run)", x3dom_cdn="1.8.2 (x3d_mcp x3dom_page loads it from a CDN)",
                         note="x3d_mcp render.py: X_ITE is the render engine; X3DOM only clears the background under software GL and does not render HAnim / X3D 4.0"), "C", "x3d_mcp/src/tools/render.py header comments")
    put("blender_mcp", dict(repo="mcp-for-blender (upstream ahujasid/mcp-for-blender, no fork)", tools=["execute_blender_code", "get_scene_info", "get_addon_status", "look", "search_assets", "import_asset", "generate_3d", "record_trajectory_feedback", "disable_telemetry"]),
        "C", "tool list connected in this session; not called live here")
    put("tether", dict(record="x3dprov in <head><meta>", survives_blender_roundtrip="6 of 6 scenes (5 KB to 62 MB)", overhead_bytes_per_step=611, last_step_limit="flipping the verdict of the LAST step still verifies (no successor)",
                       worldinfo_dropped_by_blender=True), "R", "x3d.ML/docs/DESIGN.md sections 1-3 (grade C there, fork eb4b4b4 / bpy 5.2.2)")


if __name__ == "__main__":
    schema_facts(); fork_facts(); live_facts(); misc()
    asyncio.run(mcp_facts())
    json.dump(F, open(os.path.join(ROOT, "out", "flywheel", "facts.json"), "w"), indent=1)
    print("facts:", len(F))
    for k in ("x3duom.4_1", "fork.addon", "live_run"):
        print(k, json.dumps(F[k]["value"])[:420])
    print("mcp.tools", F["mcp.tools"]["value"]["count"], "| triples:", F["mcp.ontology_triples_raw"]["value"][:120].replace("\n", " "), "| classes:", F["mcp.ontology_classes_raw"]["value"][:100].replace("\n", " "))
    print("components:", F["mcp.components_raw"]["value"][:200].replace("\n", " "))
