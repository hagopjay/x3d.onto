#!/usr/bin/env python3
"""Records the flywheel scene as an animated GIF: renders N frames of the REAL exported scene in X_ITE (render_quick.js) and assembles them with PIL.
usage: python3 scripts/flywheel/make_gif.py [--frames 48] [--size 960x540] [--vp CA_VP3_Wheel] [--out out/flywheel/flywheel.gif]"""
import argparse, glob, os, subprocess, sys
from PIL import Image
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
ap = argparse.ArgumentParser()
ap.add_argument("--frames", type=int, default=48); ap.add_argument("--size", default="960x540"); ap.add_argument("--vp"); ap.add_argument("--out", default=os.path.join(ROOT, "out", "flywheel", "flywheel.gif"))
a = ap.parse_args()
env = dict(os.environ, NODE_PATH=os.environ.get("NODE_PATH", "/tmp/node_modules"), XITE_DIST=os.environ.get("XITE_DIST", "/tmp/xite-pack/pkg/package/dist"),
           CHROME_PATH=os.environ.get("CHROME_PATH", os.path.expanduser("~/Library/Caches/ms-playwright/chromium-1155/chrome-mac/Chromium.app/Contents/MacOS/Chromium")))
tmp = os.path.join(ROOT, "out", "flywheel", "gifframes"); os.makedirs(tmp, exist_ok=True)
for f in glob.glob(tmp + "/*.png"):
    os.remove(f)
fr = ",".join("%.4f" % (i / a.frames) for i in range(a.frames))
cmd = ["node", os.path.join(ROOT, "scripts/flywheel/render_quick.js"), os.path.join(ROOT, "scenes/x3d-flywheel.x3d"), tmp + "/g", fr, "--size", a.size] + (["--vp", a.vp] if a.vp else [])
p = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=1500)
print(p.stdout.strip().splitlines()[-1] if p.stdout.strip() else p.stderr[-300:])
files = sorted(glob.glob(tmp + "/g-f*.png"))
frames = [Image.open(f).convert("RGB").quantize(colors=96, method=Image.Quantize.MEDIANCUT) for f in files]
dur = [250] * len(frames); dur[-1] = 1500
frames[0].save(a.out, save_all=True, append_images=frames[1:], duration=dur, loop=0, optimize=True, disposal=2)
print("wrote %s (%.1f MB, %d frames)" % (a.out, os.path.getsize(a.out) / 1e6, len(frames)))
