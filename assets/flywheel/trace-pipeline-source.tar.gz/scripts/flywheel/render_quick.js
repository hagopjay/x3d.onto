// Lean X_ITE render: one browser session, no free-running waits. Serves SCENE over 127.0.0.1 only.
//   node render_quick.js SCENE OUT_PREFIX FRACS [--vp CA_VP3_Wheel] [--size 1280x720]     FRACS = comma list of animation fractions
// Writes OUT_PREFIX-f000.png, -f001.png ... in the order of FRACS and prints {frames, load_ms, shot_ms}.
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const args = process.argv.slice(2);
const [scene, prefix, fracArg] = args;
const opt = k => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : null; };
const vp = opt('--vp'), [W, H] = (opt('--size') || '1280x720').split('x').map(Number);
const fracs = fracArg.split(',').map(Number);
const dist = process.env.XITE_DIST, chrome = process.env.CHROME_PATH;
const html = `<!doctype html><meta charset="utf-8"><link rel="stylesheet" href="/vendor/x_ite/x_ite.css"><style>html,body{margin:0;background:#000}x3d-canvas{width:${W}px;height:${H}px;display:block}</style>
<script src="/vendor/x_ite/x_ite.min.js"></script><x3d-canvas id="c" src="/scene.x3d" contextMenu="false" splashScreen="false" notification="false"></x3d-canvas>`;
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  let file = null;
  if (u === '/' ) { res.writeHead(200, { 'content-type': 'text/html' }); return res.end(html); }
  if (u === '/scene.x3d') file = path.resolve(scene);
  else if (u.startsWith('/vendor/x_ite/')) { file = path.resolve(dist, '.' + u.slice('/vendor/x_ite'.length)); if (!file.startsWith(path.resolve(dist) + path.sep)) file = null; }
  if (!file || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200, { 'content-type': file.endsWith('.js') ? 'text/javascript' : file.endsWith('.css') ? 'text/css' : 'model/x3d+xml' });
  fs.createReadStream(file).pipe(res);
});
(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const t0 = Date.now();
  const browser = await chromium.launch({ executablePath: chrome, headless: true, args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: W, height: H } });
  const out = { frames: 0 };
  try {
    await page.goto(`http://127.0.0.1:${server.address().port}/`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => { const b = document.getElementById('c')?.browser; return b && b.currentScene && b.currentScene.rootNodes.length > 20; }, null, { timeout: 120000 });
    await page.evaluate(vpName => {
      const b = document.getElementById('c').browser, sc = b.currentScene;
      const timer = sc.getNamedNode('SceneTimer'); timer.loop = false; timer.enabled = false;
      window.__interp = Array.from(sc.rootNodes).filter(n => /Interpolator$/.test(n.getNodeTypeName()));
      window.__seek = async f => { for (const n of window.__interp) n.set_fraction = f; await b.nextFrame(); await b.nextFrame(); };
      if (vpName) sc.getNamedNode(vpName).set_bind = true;
    }, vp);
    out.load_ms = Date.now() - t0;
    const t1 = Date.now();
    for (let i = 0; i < fracs.length; i++) {
      await page.evaluate(f => window.__seek(f), fracs[i]);
      await page.screenshot({ path: `${prefix}-f${String(i).padStart(3, '0')}.png` });
      out.frames++;
    }
    out.shot_ms = Date.now() - t1;
  } catch (e) { out.error = String(e.message || e).slice(0, 300); }
  await browser.close(); server.close();
  console.log(JSON.stringify(out));
})();
