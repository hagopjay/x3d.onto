#!/bin/bash
# One turn of the flywheel: run the REAL loop on the current scene (built from the previous turn's results), rebuild the scene from this turn's results, stamp it, check it,
# record the run in out/flywheel/history.json (tied to the git commit) and print what changed against the previous run.
#   scripts/flywheel/iterate.sh quick    (default, about 30 s: the render result of the newest earlier run is reused and labelled cached)
#   scripts/flywheel/iterate.sh full     (about 1.5 min: real X_ITE renders of the loop file and the final scene)
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
MODE=${1:-quick}
BLENDER=${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}; MCPPY=${MCPPY:-$HOME/Projects/x3d/x3d_mcp/.venv/bin/python}
export NODE_PATH=${NODE_PATH:-/tmp/node_modules} XITE_DIST=${XITE_DIST:-/tmp/xite-pack/pkg/package/dist}
export CHROME_PATH=${CHROME_PATH:-$HOME/Library/Caches/ms-playwright/chromium-1155/chrome-mac/Chromium.app/Contents/MacOS/Chromium}
mkdir -p out/flywheel; LOG=out/flywheel/iterate.log; : > $LOG
t0=$(date +%s); lap() { echo "  [$(( $(date +%s) - t0 )) s] $1" | tee -a $LOG; }
R1=skip; R2=skip; [ "$MODE" = full ] && { R1=full; R2=full; }
echo "iterate $MODE on $(git rev-parse --short HEAD 2>/dev/null) $(git status --porcelain -- scripts/flywheel scripts/scene 2>/dev/null | head -1 | sed 's/.*/(uncommitted changes)/')" | tee -a $LOG
if [ ! -f out/flywheel/facts.json ] || [ -n "$(find out/flywheel/facts.json -mmin +1440 2>/dev/null)" ]; then $MCPPY scripts/flywheel/collect_facts.py 2>&1 | grep -E "^facts" | tee -a $LOG; lap "facts refreshed"; else lap "facts reused (younger than 24 h)"; fi
if [ ! -f out/flywheel/loop.json ]; then python3 scripts/flywheel/make_trace.py --stub | tail -1 >> $LOG; else python3 scripts/flywheel/make_trace.py | tail -1 >> $LOG; fi
lap "pass-1 trace (from the previous turn's loop results)"
$MCPPY scripts/flywheel/run_loop.py loop --render $R1 2>&1 | grep -E "^LOOP|^validate|^roundtrip|Error|Traceback" | cut -c1-420 | tee -a $LOG; lap "REAL loop done"
python3 scripts/flywheel/make_trace.py | tail -1 >> $LOG
$BLENDER -b --factory-startup -noaudio --python scripts/scene/flywheel_scene.py -- --fw-trace traces/x3d-flywheel.trace.json --fw-out-x3d scenes/x3d-flywheel.x3d --fw-report out/flywheel/build.json 2>&1 | grep -E "RESULT|Error|Traceback" | tee -a $LOG; lap "scene rebuilt"
$MCPPY scripts/flywheel/run_loop.py final --render $R2 2>&1 | grep -E "^FINAL|Error|Traceback" | tee -a $LOG; lap "scene validated + stamped"
python3 -m pytest -q scripts/flywheel/test_flywheel.py 2>&1 | tail -1 | tee -a $LOG
python3 scripts/flywheel/verify_fw_x3d.py traces/x3d-flywheel.trace.json scenes/x3d-flywheel.x3d out/flywheel/build.json | python3 -c "import sys,json;d=json.loads(sys.stdin.read());print('motion key-frame error: translation %.4f scale %.4f' % (d['worst']['key_translation'][0], d['worst']['key_scale'][0]))" | tee -a $LOG
python3 scripts/gnn/audit_numbers_gnn.py traces/x3d-flywheel.trace.json scenes/x3d-flywheel.x3d | head -1 | cut -c1-200 | tee -a $LOG
cp scenes/x3d-flywheel.x3d out/flywheel/scene.x3d 2>/dev/null
lap "checks done"; echo; python3 scripts/flywheel/history.py | tail -12 | tee -a $LOG
rm -rf scripts/*/__pycache__ .pytest_cache
