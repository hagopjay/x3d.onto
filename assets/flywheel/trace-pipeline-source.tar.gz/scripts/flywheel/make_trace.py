#!/usr/bin/env python3
"""make_trace.py: out/flywheel/facts.json + out/flywheel/loop.json -> traces/x3d-flywheel.trace.json (x3d-trace/1, kind 'x3d-flywheel').
loop.json is written by run_loop.py (a REAL run of the toolchain loop). With --stub a placeholder loop is written first (pass 1: the scene has to exist
before the loop can validate it; the scene then shows 'placeholder' until pass 2). Grades: C measured now, R recorded elsewhere (source path on every card)."""
import argparse, datetime, json, os, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
OUT = os.path.join(ROOT, "out", "flywheel")
STAGE_KEYS = ["ground", "build", "validate", "repair", "revalidate", "render", "roundtrip", "stamp"]


def stub_loop():
    st = [dict(key=k, wall_ms=1.0, start_s=i * 0.002, end_s=i * 0.002 + 0.001, metrics={}) for i, k in enumerate(STAGE_KEYS)]
    return dict(placeholder=True, stages=st, results=dict(
        validate=dict(xsd_valid=True, errors=0, infos=0), defect=dict(kind="profile=Core", semantic_errors=0), repair=dict(semantic_errors_after=0, fixes=0),
        roundtrip=dict(meta_kept=None, steps_before=0, steps_after=0), render=dict(nonblank_pct=0.0, load_ok=None), file=dict(bytes=0, objects=0, interpolator_pct=0.0, interpolators=0),
        tether=dict(steps=[], verdict="not run", tamper=[]), grounding=dict(types=0, fields=0, ms=0.0)))


def g3(v):
    return float("%.3g" % v)


def build(facts, loop, hist):
    F = {k: v["value"] for k, v in facts.items()}
    R = loop["results"]
    live, uom, tools = F["live_run"], F["x3duom.4_1"], F["mcp.tools"]
    onto_t = int(json.loads(F["mcp.ontology_triples_raw"])["rows"][0]["n"])
    onto_c = int(json.loads(F["mcp.ontology_classes_raw"])["rows"][0]["n"])
    fork, suite = F["fork.addon"], F["fork.test_suite"]
    pct = lambda a, b: int(round(100 * a / b))
    models = [dict(m, first_pct=int(round(100 * m["first_try_valid"] / m["scenes"])), end_pct=int(round(100 * m["valid_at_end"] / m["scenes"]))) for m in live["models"]]
    by = {m["model"]: m for m in models}
    best = max(models, key=lambda m: m["first_try_valid"] / m["scenes"])
    worst = min(models, key=lambda m: m["first_try_valid"] / m["scenes"])
    ft_lo, ft_hi = pct(worst["first_try_valid"], worst["scenes"]), pct(best["first_try_valid"], best["scenes"])
    mc = by["model C"]
    codes = live["first_fail_codes"]
    calls = [m["median_call_s"] for m in models]
    stg = {s["key"]: s for s in loop["stages"]}
    ms = lambda k: g3(stg[k]["wall_ms"])
    tet = R["tether"]
    tam = {t["what"]: t["status"] for t in tet["tamper"]}
    stations = [
        dict(key="spec", name="X3D 4.1 · X3DUOM", headline="%d nodes" % uom["concrete_nodes"], grade="C", source="X3dUnifiedObjectModel-4.1.xml parsed now",
             lines=["%d concrete nodes (%d in 4.0, %d new in 4.1)" % (uom["concrete_nodes"], uom["concrete_nodes_4_0"], len(uom["new_in_4_1"])), "new in 4.1: " + ", ".join(uom["new_in_4_1"]),
                    "%d abstract types, %d field types, %d statements" % (uom["abstract_node_types"], uom["field_types"], uom["statements"]),
                    "ontology: %s triples, %d classes; JSON Schema %d defs" % ("{:,}".format(onto_t), onto_c, F["schemas"]["json_schema_defs"])]),
        dict(key="agent", name="AI agents", headline="%d-%d%% first try" % (ft_lo, ft_hi), grade="R", source="x3d.ML/demo/data/live.json (17 Oct 2026)",
             lines=["recorded run: %d models, %d scenes, %d calls" % (len(models), live["scenes"], live["calls"]), "valid on the first try: %d%% to %d%% depending on the model" % (ft_lo, ft_hi),
                    "median model call %s s to %s s" % (g3(min(calls)), g3(max(calls))), "XML is the language the models know best"]),
        dict(key="mcp", name="x3d_mcp server", headline="%d tools" % tools["count"], grade="C", source="MCP list_tools + this loop's timings",
             lines=["%d tools: create, compose, validate, repair, convert, animate, ontology, render" % tools["count"], "validation = XSD + JSON Schema + semantic checks",
                    "median validation %s ms (p90 %s ms) in the recorded run" % (live["median_validate_ms"], live["p90_validate_ms"]), "this loop: validate %s ms warm (%s ms cold), repair %s ms" % (g3(R["validate"]["warm_ms"]), g3(R["validate"]["cold_ms"]), ms("repair"))]),
        dict(key="fork", name="Blender + x3d_blender_io", headline="%d/%d core" % (suite["core_pass"], suite["core_total"]), grade="R", source="x3d-blender-io/docs/test-suite (v2.6.1 run)",
             lines=["fork add-on %s (HEAD %s), %d modules" % (fork["manifest_version"], fork["fork_head"], len(fork["modules"])), "export suite: %d cases, %d of %d core pass, %d fidelity warnings" % (suite["cases"], suite["core_pass"], suite["core_total"], suite["warnings"]),
                    "this scene: %s objects, %s KB exported in %s ms" % ("{:,}".format(R["file"]["objects"]), g3(R["file"]["bytes"] / 1024), ms("build")), "X3D 4.0/4.1: PBR, HAnim, splats, animation sampling"]),
        dict(key="bmcp", name="blender_mcp", headline="%d tools" % len(F["blender_mcp"]["tools"]), grade="C", source="tool list of the connected server (not called live here)",
             lines=["%d tools: execute_blender_code, get_scene_info, look, import_asset ..." % len(F["blender_mcp"]["tools"]), "lets an agent drive Blender and LOOK at the result", "upstream project, not a fork",
                    "this run drove Blender headless instead (no live window touched)"]),
        dict(key="runtime", name="X_ITE · X3DOM", headline="%s%% drawn" % g3(R["render"]["nonblank_pct"]), grade="C", source="this loop's render check + x3d_mcp render.py comments",
             lines=["X_ITE %s renders X3D 4.0 incl. HAnim" % "16.4.3", "X3DOM 1.8.2: only clears the background under software GL", "this loop's render: %s%% of pixels differ from the background" % g3(R["render"]["nonblank_pct"]),
                    "valid is not visible: 7 of 178 valid scenes drew nothing (recorded run)"]),
        dict(key="verdict", name="Verdict + repair", headline="%d%% to %d%%" % (pct(mc["first_try_valid"], mc["scenes"]), pct(mc["valid_at_end"], mc["scenes"])), grade="R", source="x3d.ML/demo/data/live.json; repair step measured in this loop",
             lines=["validator report fed back to the model: %d%% to %d%% valid (model C, %d scenes)" % (pct(mc["first_try_valid"], mc["scenes"]), pct(mc["valid_at_end"], mc["scenes"]), mc["scenes"]),
                    "first-try failures: xsd %d, profile-component %d scenes" % (codes.get("xsd", 0), codes.get("profile-component", 0)), "injected profile defect: XSD says valid, semantic finds %d errors" % R["defect"]["semantic_errors"],
                    "x3d_mcp repair: %d errors to %d in %s ms" % (R["defect"]["semantic_errors"], R["repair"]["semantic_errors_after"], ms("repair"))]),
        dict(key="tether", name="x3dprov tether", headline=tet["verdict"], grade="C", source="x3d.ML/src/x3dprov.py run on this loop",
             lines=["%d hash-chained steps ride in the file's head meta" % len(tet["steps"]), "verify: %s" % tet["verdict"], "Blender round trip kept the record: %s" % R["roundtrip"]["meta_kept"],
                    "edit after last step: %s; delete a step: %s" % (tam.get("edit after the last step", "-"), tam.get("delete a step", "-"))]),
    ]
    iv = R["file"]["interpolator_pct"]
    cards = [
        ("ground", "GROUND THE AGENT IN THE SPEC", "Ask the spec, not memory: X3DUOM 4.1 lists %d concrete nodes and %d are new in 4.1. This loop grounded %d node types (%d fields) through MCP describe_node in %s ms." % (
            uom["concrete_nodes"], len(uom["new_in_4_1"]), R["grounding"]["types"], R["grounding"]["fields"], g3(R["grounding"]["ms"])),
         dict(x3d_version=4.1, concrete_nodes=uom["concrete_nodes"], new_in_4_1=len(uom["new_in_4_1"]), node_types=R["grounding"]["types"], fields=R["grounding"]["fields"], ms=g3(R["grounding"]["ms"])), "C", "spec"),
        ("firsttry", "FIRST DRAFTS ARE USUALLY WRONG", "Across %d models the first attempt was valid only %d%% to %d%% of the time; XML is familiar to them, but the spec is strict." % (len(models), ft_lo, ft_hi),
         dict(models=len(models), first_try_low_percent=ft_lo, first_try_high_percent=ft_hi), "R", "agent"),
        ("validate", "VALIDATE EVERY ATTEMPT", "Validation took a median %s ms in the recorded run against model calls of %s to %s s; here a %s KB scene took %s ms warm (%s ms on the first, cold call that loads the schemas). It is never the bottleneck." % (
            live["median_validate_ms"], g3(min(calls)), g3(max(calls)), g3(R["file"]["bytes"] / 1024), g3(R["validate"]["warm_ms"]), g3(R["validate"]["cold_ms"])),
         dict(median_validate_ms=live["median_validate_ms"], call_low_s=g3(min(calls)), call_high_s=g3(max(calls)), scene_kb=g3(R["file"]["bytes"] / 1024), warm_ms=g3(R["validate"]["warm_ms"]), cold_ms=g3(R["validate"]["cold_ms"])), "R", "mcp"),
        ("bridge", "BLENDER IS THE BRIDGE", "The fork exported this scene (%s objects, %s KB) and passes %d of %d core cases in its %d-case suite. A finding: the add-on manifest says %s but its generator tag says %s." % (
            "{:,}".format(R["file"]["objects"]), g3(R["file"]["bytes"] / 1024), suite["core_pass"], suite["core_total"], suite["cases"], fork["manifest_version"], fork["bl_info_version"]),
         dict(objects=R["file"]["objects"], kb=g3(R["file"]["bytes"] / 1024), core_pass=suite["core_pass"], core_total=suite["core_total"], cases=suite["cases"], manifest_version=fork["manifest_version"], generator_version=fork["bl_info_version"]), "C", "fork"),
        ("look", "AGENTS SHOULD LOOK", "Valid is not visible: 7 of 178 valid scenes drew nothing in X_ITE. An agent that can render and look (blender_mcp look, MCP render_image) catches that.",
         dict(valid_but_blank=7, valid_scenes=178), "R", "bmcp"),
        ("runtime", "RENDER IN THE REAL RUNTIME", "This loop's render drew %s%% of the pixels. X_ITE renders X3D 4.0 including HAnim; X3DOM under software GL only clears the background, so a pass in one runtime is not a pass in all." % g3(R["render"]["nonblank_pct"]),
         dict(x3d_version=4.0, drawn_percent=g3(R["render"]["nonblank_pct"])), "C", "runtime"),
        ("loop", "SEND THE REPORT BACK", "Feeding the validator's own report back took model C from %d%% to %d%% valid. The commonest first failures are mechanical (xsd %d, profile-component %d scenes); here an injected profile defect passed XSD but had %d semantic errors, and MCP repair cleared them in %s ms." % (
            pct(mc["first_try_valid"], mc["scenes"]), pct(mc["valid_at_end"], mc["scenes"]), codes.get("xsd", 0), codes.get("profile-component", 0), R["defect"]["semantic_errors"], ms("repair")),
         dict(first_try_percent=pct(mc["first_try_valid"], mc["scenes"]), at_end_percent=pct(mc["valid_at_end"], mc["scenes"]), xsd_scenes=codes.get("xsd", 0), profile_component_scenes=codes.get("profile-component", 0),
              semantic_errors=R["defect"]["semantic_errors"], repair_ms=ms("repair")), "R", "verdict"),
        ("tether", "CHAIN EVERY STEP INTO THE FILE", "%d steps (generate, validate, defect, validate, repair, validate, render, Blender round trip) are hash-chained in the file's head meta: verify says %s. Editing after the last step gives %s, deleting a step %s; flipping the LAST verdict still verifies." % (
            len(tet["steps"]), tet["verdict"], tam.get("edit after the last step", "-"), tam.get("delete a step", "-")),
         dict(steps=len(tet["steps"])), "C", "tether"),
        ("bytes", "ANIMATION IS THE BYTES", "%s%% of this scene's bytes are %s interpolators; the shapes are cheap. Budget the keys (animation step, compaction), not the meshes." % (g3(iv), "{:,}".format(R["file"]["interpolators"])),
         dict(interpolator_percent=g3(iv), interpolators=R["file"]["interpolators"]), "C", "fork"),
        ("findings", "FEED FINDINGS BACK", "This loop found: the exporter writes text labels as meshes (%s labels, %s characters were left out of the Blender round trip, which then grew from %s KB to %s KB); the manifest says %s but the generator tag says %s; the registry covers %d node specs. Fixes go into the fork and the spec tooling, then the loop runs again." % (
            "{:,}".format(R["roundtrip"].get("fonts_dropped", 0)), "{:,}".format(R["roundtrip"].get("font_chars", 0)), g3(R["roundtrip"].get("bytes_in", 0) / 1024), g3(R["roundtrip"].get("bytes_out", 0) / 1024),
            fork["manifest_version"], fork["bl_info_version"], F["fork.registry_nodes"]),
         dict(labels=R["roundtrip"].get("fonts_dropped", 0), characters=R["roundtrip"].get("font_chars", 0), kb_before=g3(R["roundtrip"].get("bytes_in", 0) / 1024), kb_after=g3(R["roundtrip"].get("bytes_out", 0) / 1024),
              manifest_version=fork["manifest_version"], generator_version=fork["bl_info_version"], registry_nodes=F["fork.registry_nodes"]), "C", "all"),
    ]
    order = [s["key"] for s in stations]
    ins = []
    for i, (cid, title, text, nums, grade, st) in enumerate(cards):
        at = dict(station=order.index(st)) if st in order else dict(outro=1)
        ins.append(dict(id=cid, title=title, text=text, numbers=nums, grade=grade, station=st, at=at))
    ins[8]["at"], ins[9]["at"] = dict(outro=0), dict(outro=1)
    ins[4]["at"] = dict(station=4)
    ins[5]["at"] = dict(station=5)
    st_out = []
    for i, k in enumerate(STAGE_KEYS):
        s = stg[k]
        m = dict(wall_ms=round(s["wall_ms"], 4)); m.update({a: b for a, b in (s.get("metrics") or {}).items() if isinstance(b, (int, float))})
        m.setdefault("records_out", 1)
        st_out.append(dict(id="S%d" % i, name=k, kind=k, layer=i, start_s=round(s["start_s"], 6), end_s=round(s["end_s"], 6), parallelism=1, metrics=m, stage_key=k))
    flows = [{"from": "S%d" % i, "to": "S%d" % (i + 1), "records": 1, "bytes": 0, "start_s": st_out[i]["end_s"], "end_s": st_out[i + 1]["start_s"]} for i in range(len(st_out) - 1)]
    dur = st_out[-1]["end_s"]
    trace = dict(
        schema="x3d-trace/1",
        source=dict(kind="x3d-flywheel", synthetic=False, title="The X3D flywheel: spec, agents, MCP, Blender and runtimes tethered by a hash chain", run_id="x3d-flywheel-" + str(F["mcp.head"]),
                    created_utc=loop.get("finished_utc") or "1970-01-01T00:00:00Z",                  # deterministic for a given loop run
                    engine=dict(name="x3d_mcp + x3d_blender_io fork + X_ITE + x3dprov", version="x3d_mcp %s, fork %s, X_ITE 16.4.3" % (F["mcp.head"], fork["fork_head"])),
                    data=dict(description="real tool outputs from this machine (MCP, X3DUOM, add-on) plus a recorded live run of 358 model calls (models anonymised)", origin="The X3D toolchain on this machine (x3d_mcp, x3d-blender-io, x3d.ML: hagsmac forks)",
                              rows_or_bytes_read=live["calls"], license_note="no model or vendor names; the recorded run is private project data"),
                    provenance=dict(facts={k: dict(grade=v["grade"], source=v["source"]) for k, v in facts.items()}, tether_steps=tet["steps"], loop_placeholder=bool(loop.get("placeholder")))),
        time=dict(unit="s", duration=round(dur, 6)), stages=st_out, flows=flows, series=dict(t=[], channels={}), entities=[],
        metrics=dict(mcp_tools=tools["count"], x3duom_concrete_nodes=uom["concrete_nodes"], ontology_triples=onto_t, fork_core_pass=suite["core_pass"], fork_core_total=suite["core_total"],
                     validate_ms=ms("validate"), repair_ms=ms("repair"), render_drawn_percent=g3(R["render"]["nonblank_pct"]), tether_steps=len(tet["steps"]), scene_objects=R["file"]["objects"], scene_kb=g3(R["file"]["bytes"] / 1024)),
        notes=["REAL: the facts on the stations are queried or measured on this machine now (grade C) or recorded elsewhere with a path (grade R); each card names its source.",
               "REAL: the loop (ground, build, validate, repair, revalidate, Blender round trip, render, stamp) was executed for this scene; its timings are on the stage strip." + (" PLACEHOLDER: pass 1, the loop has not validated this build yet." if loop.get("placeholder") else ""),
               "A defect was INJECTED on purpose (profile set to Core) to exercise validate and repair; it is not a natural failure.",
               "The recorded live run (17 Oct 2026, 50 prompts, 5 models) is shown anonymised as model A to E; one run per prompt, so percentages describe those scenes, not the models.",
               "The scene shows the chain of the previous pass; a file cannot contain the hash of its own final bytes, so the stamped file carries the full chain in its head meta.",
               "Playback is STRETCHED: each station gets a fixed slot; stage milliseconds are real."],
        flywheel=dict(version=1, history=hist[-6:], stations=stations, insights=ins, live=dict(models=models, median_validate_ms=live["median_validate_ms"], p90_validate_ms=live["p90_validate_ms"], codes=codes, median_call_s=live["median_call_s"]),
                      tether=tet, findings=[c[2] for c in cards[-1:]], results=R, onto=dict(triples=onto_t, classes=onto_c)))
    return trace


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--stub", action="store_true")
    ap.add_argument("--out", default=os.path.join(ROOT, "traces", "x3d-flywheel.trace.json"))
    a = ap.parse_args(argv)
    lp = os.path.join(OUT, "loop.json")
    if a.stub or not os.path.exists(lp):
        json.dump(stub_loop(), open(lp, "w"), indent=1)
    facts, loop = json.load(open(os.path.join(OUT, "facts.json"))), json.load(open(lp))
    hp = os.path.join(OUT, "history.json")
    hist = json.load(open(hp)) if os.path.exists(hp) else []
    tr = build(facts, loop, hist)
    json.dump(tr, open(a.out, "w"), separators=(",", ":"))
    print("wrote %s (%.0f KB) placeholder=%s cards=%d" % (a.out, os.path.getsize(a.out) / 1024, bool(loop.get("placeholder")), len(tr["flywheel"]["insights"])))


if __name__ == "__main__":
    main()
