#!/usr/bin/env python3
"""Run history for the flywheel loop. Every REAL loop run is saved under out/flywheel/runs/<utc>.json and summarised in out/flywheel/history.json together with
the git commit of this repo (and whether the tree was dirty), so run N can be diffed against run N-1 and tied to the change that caused it.
  python3 scripts/flywheel/history.py            print the last runs and the delta of the latest against the previous
  (imported by run_loop.py: append(loop))"""
import json, os, subprocess, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
OUT = os.path.join(ROOT, "out", "flywheel")
HIST = os.path.join(OUT, "history.json")


def repo_state():
    try:
        head = subprocess.check_output(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
        dirty = bool(subprocess.check_output(["git", "-C", ROOT, "status", "--porcelain", "--", "scripts/flywheel", "scripts/scene/flywheel_scene.py", "scripts/scene/gnn_scene.py"], text=True).strip())
        return dict(head=head, dirty=dirty)
    except Exception:
        return dict(head=None, dirty=None)


def summarise(loop):
    R, st = loop["results"], {s["key"]: s["wall_ms"] for s in loop["stages"]}
    return dict(utc=loop["finished_utc"], repo=repo_state(), stage_ms={k: round(v, 1) for k, v in st.items()}, total_ms=round(sum(st.values()), 1),
                validate_cold_ms=round(R["validate"]["cold_ms"], 1), validate_warm_ms=round(R["validate"]["warm_ms"], 1), semantic_errors_defect=R["defect"]["semantic_errors"],
                semantic_errors_after_repair=R["repair"]["semantic_errors_after"], semantic_infos=R["validate"]["infos"], render_pct=round(R["render"]["nonblank_pct"], 2),
                render_cached=bool(R["render"].get("cached")), tether=R["tether"]["verdict"], tether_steps=len(R["tether"]["steps"]), scene_kb=round(R["file"]["bytes"] / 1024, 1),
                objects=R["file"]["objects"], interpolator_pct=R["file"]["interpolator_pct"], roundtrip_kb=round(R["roundtrip"].get("bytes_out", 0) / 1024, 1))


def load():
    return json.load(open(HIST)) if os.path.exists(HIST) else []


def append(loop):
    os.makedirs(os.path.join(OUT, "runs"), exist_ok=True)
    json.dump(loop, open(os.path.join(OUT, "runs", loop["finished_utc"].replace(":", "") + ".json"), "w"), indent=1)
    h = load()
    if not any(r["utc"] == loop["finished_utc"] for r in h):
        h.append(summarise(loop))
    json.dump(h, open(HIST, "w"), indent=1)
    return h


def compare(h=None):
    h = h or load()
    if not h:
        return "no runs yet"
    cur, prev = h[-1], (h[-2] if len(h) > 1 else None)
    lines = ["run %d of %d  %s  repo %s%s" % (len(h), len(h), cur["utc"], cur["repo"]["head"], " (dirty)" if cur["repo"]["dirty"] else "")]
    keys = [("total_ms", "loop total ms"), ("validate_cold_ms", "validate cold ms"), ("validate_warm_ms", "validate warm ms"), ("semantic_errors_defect", "defect errors"), ("semantic_errors_after_repair", "errors after repair"),
            ("semantic_infos", "semantic infos"), ("render_pct", "render drawn %"), ("tether_steps", "tether steps"), ("scene_kb", "scene KB"), ("objects", "objects")]
    for k, label in keys:
        a = cur[k]
        if prev is None:
            lines.append("  %-22s %10s" % (label, a))
        else:
            b = prev[k]
            d = a - b
            lines.append("  %-22s %10s  (prev %s, %s%s)" % (label, a, b, "+" if d > 0 else "", round(d, 2)) if d else "  %-22s %10s  (same)" % (label, a))
    lines.append("  tether %s | stage ms: %s" % (cur["tether"], " ".join("%s %.0f" % kv for kv in cur["stage_ms"].items())))
    return "\n".join(lines)


if __name__ == "__main__":
    h = load()
    for r in h[-8:]:
        print(r["utc"], r["repo"]["head"], "dirty" if r["repo"]["dirty"] else "clean", "total %.0f ms" % r["total_ms"], "warm %.0f ms" % r["validate_warm_ms"], "render %.1f%%" % r["render_pct"], r["tether"])
    print(compare(h))
