import sys
import numpy as np
from PIL import Image
a = np.asarray(Image.open(sys.argv[1]).convert("RGB")).astype(np.int16)
bg = np.median(a[:8, :8].reshape(-1, 3), axis=0)
print(float((np.abs(a - bg).max(axis=2) > 12).mean() * 100))
