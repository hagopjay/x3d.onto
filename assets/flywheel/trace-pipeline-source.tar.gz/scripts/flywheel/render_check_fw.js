// flywheel scene copy of render_check.js (binds CA_VP1_Demo first).
// Serves the file and a tiny HTML page over 127.0.0.1 only, takes screenshots at given animation fractions, stops the server.
//   NODE_PATH=/tmp/node_modules CHROME_PATH=<Chromium binary> XITE_DIST=<x_ite dist dir> \
//     node render_check.js SCENE.x3d OUT_PREFIX 0.2,0.62,0.9 [VIEWPOINT_DEF ...]
// Writes OUT_PREFIX-t<fraction>.png for each fraction (Overview viewpoint) and OUT_PREFIX-<DEF>.png for each extra viewpoint
// (at the middle fraction), plus OUT_PREFIX.render.json with console messages and a few probe values.
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const [scene, prefix, fracArg, ...vps] = process.argv.slice(2);
const dist = process.env.XITE_DIST, chrome = process.env.CHROME_PATH;
const fracs = (fracArg || '0.2,0.6,0.9').split(',').map(Number);
const html = `<!doctype html><meta charset="utf-8"><link rel="stylesheet" href="/vendor/x_ite/x_ite.css">
<style>html,body{margin:0;background:#000}x3d-canvas{width:1280px;height:720px;display:block}</style>
<script src="/vendor/x_ite/x_ite.min.js"></script>
<x3d-canvas id="c" src="/scene.x3d" contextMenu="false" splashScreen="false" notification="false"></x3d-canvas>`;
const mime = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.x3d': 'model/x3d+xml', '.html': 'text/html', '.png': 'image/png', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  let file = null;
  if (u === '/favicon.ico') { res.writeHead(204); return res.end(); }
  if (u === '/' || u === '/index.html') { res.writeHead(200, { 'content-type': 'text/html' }); return res.end(html); }
  if (u === '/scene.x3d') file = path.resolve(scene);
  else if (u.startsWith('/vendor/x_ite/')) { file = path.resolve(dist, '.' + u.slice('/vendor/x_ite'.length)); if (!file.startsWith(path.resolve(dist) + path.sep)) file = null; }
  if (!file || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'content-type': mime[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});
(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const port = server.address().port;
  const browser = await chromium.launch({ executablePath: chrome, headless: true,
    args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const logs = [];
  page.on('console', m => { if (['error', 'warning'].includes(m.type())) logs.push(m.type() + ': ' + m.text().slice(0, 240)); });
  page.on('response', r => { if (r.status() >= 400) logs.push('http ' + r.status() + ' ' + r.url().replace(/^http:\/\/127.0.0.1:\d+/, '')); });
  page.on('pageerror', e => logs.push('pageerror: ' + String(e.message).slice(0, 240)));
  const out = { port, fracs, shots: [], logs, probes: {} };
  try {
    await page.goto(`http://127.0.0.1:${port}/`, { waitUntil: 'domcontentloaded' });
    await page.waitForFunction(() => { const b = document.getElementById('c')?.browser; return b && b.currentScene && b.currentScene.rootNodes.length > 20; }, null, { timeout: 120000 });
    await page.waitForTimeout(1500);
    // 1) free-running playback: the exported TimeSensor drives the interpolators by itself; two shots 3.5 s apart must differ
    await page.screenshot({ path: `${prefix}-free-a.png` });
    await page.waitForTimeout(3500);
    await page.screenshot({ path: `${prefix}-free-b.png` });
    out.info = await page.evaluate(() => {
      const b = document.getElementById('c').browser, sc = b.currentScene;
      const nodes = Array.from(sc.rootNodes);
      const kinds = {};
      for (const n of nodes) { const k = n.getNodeTypeName(); kinds[k] = (kinds[k] || 0) + 1; }
      const timer = sc.getNamedNode('SceneTimer');
      timer.loop = false; timer.enabled = false;          // we drive the interpolators ourselves
      window.__interp = nodes.filter(n => /Interpolator$/.test(n.getNodeTypeName()));
      window.__seek = f => { for (const n of window.__interp) n.set_fraction = f; };
      return { version: X3D.X3D_VERSION ?? null, rootNodeKinds: kinds, interpolators: window.__interp.length, cycleInterval: timer.cycleInterval };
    });
    // X_ITE applies a new fraction on the next frame: wait for two rendered frames before looking at (or screenshotting) the scene
    const settle = f => page.evaluate(async f => { const b = document.getElementById('c').browser; window.__seek(f); await b.nextFrame(); await b.nextFrame(); }, f);
    const shot = async (name, f) => {
      await settle(f);
      await page.waitForTimeout(300);
      const file = `${prefix}-${name}.png`;
      await page.screenshot({ path: file });
      out.shots.push({ name, fraction: f, file });
    };
    await page.evaluate(() => { const sc = document.getElementById('c').browser.currentScene; const v = sc.getNamedNode('CA_VP1_Demo'); if (v) v.set_bind = true; });
    for (const f of fracs) await shot('t' + String(Math.round(f * 100)).padStart(2, '0'), f);
    for (const spec of vps) {
      const [vp, at] = spec.split('@');
      const ok = await page.evaluate(d => { try { const sc = document.getElementById('c').browser.currentScene; const v = sc.getNamedNode(d); v.set_bind = true; return true; } catch (e) { return false; } }, vp);
      if (ok) await shot(vp.replace(/^CA_/, ''), at ? Number(at) : fracs[Math.floor(fracs.length / 2)]);
      else out.logs.push('missing viewpoint ' + vp);
    }
    // probe: a carrier's translation at three fractions proves the transforms move, not just the pixels
    out.probes = {};
    for (const name of ['OB_PKT0', 'OB_PAD0', 'OB_BNC0', 'OB_CURSOR']) {
      const vals = [];
      for (const f of [0.1, 0.5, 0.9]) {
        await settle(f);
        vals.push(await page.evaluate(n => { try { const x = document.getElementById('c').browser.currentScene.getNamedNode(n); return [Array.from(x.translation), Array.from(x.scale)]; } catch (e) { return null; } }, name));
      }
      out.probes[name] = vals;
    }
    out.webgl = await page.evaluate(() => { const c = document.createElement('canvas'); const g = c.getContext('webgl2'); return g ? g.getParameter(g.VERSION) : null; });
  } catch (e) {
    out.error = String(e.message || e).slice(0, 400);
  }
  fs.writeFileSync(`${prefix}.render.json`, JSON.stringify(out, null, 1));
  await browser.close();
  server.close();
  console.log(JSON.stringify({ shots: out.shots.map(s => s.file), error: out.error || null, logs: out.logs.slice(0, 8), info: out.info, webgl: out.webgl }));
})();
