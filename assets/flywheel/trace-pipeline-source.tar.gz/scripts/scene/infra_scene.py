#!/usr/bin/env python3
"""infra_scene.py: the 'k8s-blueprint' scene. Generic stage machine (trace_to_scene.Model, untouched) + a dependency-graph module: every Kubernetes
resource is a box in its layer (foundations -> workloads -> exposure/control), every resolved reference an edge with packets that flow in the
'resolve' slot, lint results as pips, CPU requests as bars. Reuses the helpers of gnn_scene.py (tracks, floor, polish, builder).

Headless:  Blender -b --factory-startup -noaudio --python scripts/scene/infra_scene.py -- --infra-trace traces/k8s-karate.trace.json --infra-out-x3d scenes/k8s-karate.x3d [--infra-report J]
HONESTY: the trace is SYNTHETIC (authored blueprint); the scene says so on the wall banner and a plate. Numbers come from the trace; derived: playback stretch, layout, bar heights."""
import copy
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(globals().get("__file__") or os.path.join(os.environ.get("GNN_SCENE_DIR", "."), "infra_scene.py")))
sys.path.insert(0, HERE)
_argv, sys.argv = sys.argv, sys.argv[:1]
import gnn_scene as G                                       # noqa: E402  (loads the generic builder as G.tts)
sys.argv = _argv
tts, bpy = G.tts, G.bpy
MIN_SCALE, SegTrack, PolyTrack, window_track = G.MIN_SCALE, G.SegTrack, G.PolyTrack, G.window_track
FRACTIONS = dict(parse=0.14, index=0.14, resolve=0.20, lint=0.26, budget=0.26)
KIND_RGB = dict(ServiceAccount=(0.55, 0.62, 0.75), ConfigMap=(0.15, 0.7, 0.7), PersistentVolumeClaim=(0.6, 0.4, 0.9), Job=(1.0, 0.55, 0.15), Deployment=(0.2, 0.55, 1.0),
                CronJob=(0.95, 0.8, 0.2), Service=(0.3, 0.85, 0.4), HorizontalPodAutoscaler=(0.9, 0.3, 0.7), PodDisruptionBudget=(0.6, 0.85, 0.3), NetworkPolicy=(0.95, 0.35, 0.3))
EDGE_RGB = dict(config=(0.2, 0.85, 0.85), storage=(0.7, 0.5, 1.0), identity=(0.65, 0.7, 0.8), selects=(1.0, 0.75, 0.25), scales=(1.0, 0.75, 0.25), protects=(1.0, 0.75, 0.25), guards=(1.0, 0.75, 0.25))
PX0, PX1, PY0, PY1 = -0.5, 40.5, -24.0, -8.0
COLX = [7.0, 20.5, 34.0]


class Slots:
    def __init__(self, stages, pb):
        self.pb, self.win, t = pb, {}, 0.0
        for s in stages:
            k = s["stage_key"]
            self.win[k] = (t, t + FRACTIONS[k] * pb)
            t += FRACTIONS[k] * pb
        last = stages[-1]["stage_key"]
        self.win[last] = (self.win[last][0], pb)

    def card_window(self, at):
        a, b = self.win[at["stage_from"]][0], self.win[at["stage_to"]][1]
        if "part" in at:
            lo, hi = at["part"]
            a, b = a + lo * (b - a), a + hi * (b - a)
        return a, b


def display_trace(tr, S, pb):
    d = copy.deepcopy(tr)
    d.pop("blueprint", None)
    d["time"]["duration"] = pb
    for s in d["stages"]:
        s["start_s"], s["end_s"] = S.win[s["stage_key"]]
    ids = {s["id"]: s for s in d["stages"]}
    for f in d["flows"]:
        f["start_s"], f["end_s"] = ids[f["from"]]["end_s"], ids[f["to"]]["start_s"]
    d["series"], d["entities"] = {"t": [], "channels": {}}, []
    return d


class InfraModel(tts.Model):
    def __init__(self, trace, **cfg):
        cfg = dict(dict(n_frames=480, step=4, amb_total=20, amb_cap=3), **{k: v for k, v in cfg.items() if v is not None})
        self.gtr, self.B = trace, trace["blueprint"]
        self.pb_play = (int(cfg["n_frames"]) - 1) / int(cfg.get("fps", tts.DEFAULTS["fps"]))
        self.slots = Slots(trace["stages"], self.pb_play)
        self.gmap = []
        super().__init__(display_trace(trace, self.slots, self.pb_play), **cfg)
        self.items = [it for it in self.items if not (it["kind"] == "label" and it["mode"] == "flat" and abs(it["loc"][1] - (self.ymin_m - 1.3)) < 1e-6)]

    def _stages(self):
        super()._stages()
        wmax = max(s["metrics"]["wall_ms"] for s in self.gtr["stages"])
        st = {s["id"]: s for s in self.gtr["stages"]}
        self.stage_rgb = {}
        for it in self.items:
            if it["kind"] == "block":
                rgb = tts.ramp(st[it["sid"]]["metrics"]["wall_ms"] / wmax)
                it["mat"]["rgb"] = rgb
                self.stage_rgb[it["sid"]] = rgb
                self.pos[it["sid"]]["rgb"] = rgb

    def mapping_lines(self):
        base = [l for l in super().mapping_lines() if not l.startswith("block colour") and not l.startswith("floor ruler")]
        return base + ["block colour = that stage's wall_ms / the slowest stage's (blue, amber, red); real wall-clock per stage is printed on the strip"] + self.gmap

    def _bars(self):
        self.fam, self.gauges, self.bar_peak, self.gauge_y = {}, [], {}, self.ymax_m + 2.4
        for s_ in self.tr["stages"]:
            p = self.pos[s_["id"]]
            self.label([s_["stage_key"].upper()], (p["x"], p["y"], p["sz"] + 0.9), 0.5, (1, 1, 1))

    def _timeline(self):
        S, pb = self.slots, self.pb_play
        x0, x1 = -1.0, (len(self.layers) - 1) * self.dx + 1.0
        Wr, yt = x1 - x0, -4.9
        xs = lambda t: x0 + Wr * min(max(t / pb, 0.0), 1.0)
        tot = self.B["totals"]
        chips = dict(parse=lambda m: ["%d bytes" % m["bytes_in"], "%d documents" % m["documents"]], index=lambda m: ["%d resources" % m["resources"], "%d kinds" % m["kinds"]],
                     resolve=lambda m: ["%d references" % m["references"], "%d dangling" % m["dangling"]], lint=lambda m: ["%d/%d checks" % (m["checks_passed"], m["checks_run"]), "pass"],
                     budget=lambda m: ["%.0f m CPU" % m["cpu_requests_m"], "%.0f Mi memory" % m["memory_requests_mi"]])
        self.add("plate", "STRIP_BASE", loc=((x0 + x1) / 2, yt - 0.4, 0.0), size=(Wr + 0.3, 2.2, 0.05), mat=dict(kind="pbr", rgb=G.C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        for s_ in self.gtr["stages"]:
            a, b = S.win[s_["stage_key"]]
            xc = (xs(a) + xs(b)) / 2
            self.add("plate", "SEG_" + s_["id"], loc=(xc, yt, 0.06), size=(xs(b) - xs(a) - 0.12, 0.9, 0.08), mat=dict(kind="pbr", rgb=self.stage_rgb[s_["id"]], alpha=1.0, rough=0.5, emit=0.35))
            self.label([s_["stage_key"]], (xc, yt + 0.14, 0.16), 0.38, (1, 1, 1), mode="flat")
            self.label(["%s ms" % tts.fmt_num(float("%.3g" % s_["metrics"]["wall_ms"]))], (xc, yt - 0.26, 0.16), 0.36, (1, 1, 0.8), mode="flat")
            self.label(chips[s_["stage_key"]](s_["metrics"]), (xc, yt - 0.8, 0.06), 0.34, (0.78, 0.86, 0.95), mode="flat", valign="top")
        self.caption = "playback %.0f s = %.1f ms of real analysis (%.0fx slower): every stage gets a fixed slot" % (pb, self.gtr["time"]["duration"] * 1e3, pb / self.gtr["time"]["duration"])
        self.label([self.caption], (x0, yt - 1.9, 0.02), 0.3, (0.9, 0.9, 0.6), mode="flat", align="left")
        self.add("plate", "CURSOR", loc=(x0, yt, 0.2), size=(0.08, 1.4, 0.4), mat=dict(kind="emit", rgb=(1, 1, 0.6), alpha=1.0),
                 track=SegTrack([(-1.0, 0.0, (x0, yt, 0.2), (x0, yt, 0.2), 1, 1), (0.0, pb, (x0, yt, 0.2), (x1, yt, 0.2), 1, 1), (pb, pb + 10, (x1, yt, 0.2), (x1, yt, 0.2), 1, 1)], base=(0.08, 1.4, 0.4)))
        self.flat_banner_y = PY0 - 8.0
        self.grow(x0 - 1.0, yt - 2.4, x1 + 1.0, yt + 0.8)
        self.mapping.append("stage strip: segment width = its slot of the loop, text = real measured ms + the stage's result; cursor = playback time")

    def _rig(self):
        super()._rig()
        x0, y0, x1, y1 = self.bb
        Hh, cx = self.wall["H"], (x0 + x1) / 2

        def cam(name, desc, tgt, el, pts):
            e = math.radians(el)
            dv = (0.0, -math.cos(e), math.sin(e))
            d = self._fit(tgt, dv, pts, 50.0, margin=0.97)
            return dict(name=name, desc=desc, loc=tuple(tgt[i] + dv[i] * d for i in range(3)), target=tgt, fov=50.0)
        box = lambda xa, xb, ya, yb, zs=(0.0, 3.0): [(x, y, z) for x in (xa, xb) for y in (ya, yb) for z in zs]
        ya = self.flat_banner_y - 0.8
        self.cams = [cam("VP1_Demo", "Demo: stage strip, dependency graph, subtitles", (cx, (ya + 2.0) / 2, 0.5), 47.0, box(x0, x1, ya, 2.5, (0.0, 4.5))),
                     cam("VP2_Overview", "Overview: everything including the title wall", (cx, (y0 + y1) / 2, 1.5), 40.0, box(x0, x1, y0, y1, (0.0, Hh))),
                     cam("VP3_Graph", "Close-up: the dependency graph", (cx, (PY0 + PY1) / 2, 0.0), 58.0, box(PX0 - 0.5, PX1 + 0.5, PY0 - 3.5, PY1 + 0.5, (0.0, 5.0))),
                     cam("VP4_Pipeline", "Close-up: analysis stages with real timings", (cx, -2.0, 0.5), 36.0, box(x0, x1, -8.0, 2.0, (0.0, 4.0))),
                     cam("VP5_Top", "Top view", (cx, (y0 + y1) / 2, 0.0), 89.0, [(x, y, 0.0) for x in (x0, x1) for y in (y0, y1)]),
                     cam("VP6_Wall", "Close-up: title wall", (cx, self.wall["y"], Hh / 2), 6.0, box(x0, x1, self.wall["y"] - 0.2, self.wall["y"] + 0.2, (0.0, Hh)))]

    def _entities(self):
        self.ents, self.ent_end_y = [], 0.0
        B, S, dk = self.B, self.slots, self.dk
        nodes = [n for n in B["nodes"] if not n["frame"]]
        # floor + grid
        x0, x1, y0, y1 = -8.0, 50.0, PY0 - 12.0, 12.0
        self.add("plate", "FLOOR", loc=((x0 + x1) / 2, (y0 + y1) / 2, -0.1), size=(x1 - x0, y1 - y0, 0.04), mat=dict(kind="pbr", rgb=(0.016, 0.02, 0.032), alpha=1.0, rough=0.95, emit=0.0))
        grid = dict(kind="emit", rgb=(0.05, 0.065, 0.10), alpha=1.0)
        for gx in range(-5, 50, 5):
            self.add("plate", "GX%d" % (gx + 5), loc=(gx, (y0 + y1) / 2, -0.07), size=(0.03, y1 - y0, 0.01), mat=grid)
        for gy in range(int(y0) + 2, int(y1), 5):
            self.add("plate", "GY%d" % (gy + 40), loc=((x0 + x1) / 2, gy, -0.07), size=(x1 - x0, 0.03, 0.01), mat=grid)
        gy_c = (PY0 + PY1) / 2
        self.add("plate", "PANEL", loc=((PX0 + PX1) / 2, gy_c, -0.02), size=(PX1 - PX0, PY1 - PY0, 0.08), mat=dict(kind="pbr", rgb=G.C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        e = 0.07
        for nm, (cx, cy, sw, sh) in dict(a=((PX0 + PX1) / 2, PY0, PX1 - PX0, e), b=((PX0 + PX1) / 2, PY1, PX1 - PX0, e), c=(PX0, gy_c, e, PY1 - PY0), d=(PX1, gy_c, e, PY1 - PY0)).items():
            self.add("plate", "PF" + nm, loc=(cx, cy, 0.05), size=(sw, sh, 0.06), mat=dict(kind="pbr", rgb=G.C_FRAME, alpha=1.0, rough=0.9, emit=0.5))
        for li, t in enumerate(("1 · FOUNDATIONS: config, storage, identity", "2 · WORKLOADS: what runs", "3 · EXPOSURE + CONTROL: who reaches it, how it scales")):
            self.label([t], (COLX[li], PY1 - 0.7, 0.03), 0.42, G.C_DIM, mode="flat")
        self.label(["namespace %s · %d resources · %d references" % (B["namespace"], len(B["nodes"]), len(B["edges"]))], ((PX0 + PX1) / 2, PY0 - 0.8, 0.02), 0.5, G.C_TEXT, mode="flat")
        # nodes
        cmax = max([n["cpu_m"] for n in nodes] + [1.0])
        pos, idx = {}, {}
        by_layer = {}
        for n in nodes:
            by_layer.setdefault(n["layer"], []).append(n)
        for li, lst in by_layer.items():
            lst.sort(key=lambda n: n["order"])
            sp = min(4.2, (PY1 - PY0 - 4.0) / max(len(lst), 1))
            for j, n in enumerate(lst):
                n["_xy"] = (COLX[li], gy_c - 0.4 + ((len(lst) - 1) / 2 - j) * sp)
        t_idx0, t_idx1 = S.win["index"]
        for k, n in enumerate(nodes):
            x, y = n["_xy"]
            hgt = 1.3 + 1.6 * n["cpu_m"] / cmax
            size = (3.4, 1.6, hgt)
            a = t_idx0 + (t_idx1 - t_idx0) * 0.8 * k / max(len(nodes) - 1, 1)
            self.add("block", "N%d" % k, loc=(x, y, 0.0), size=size, mat=dict(kind="pbr", rgb=KIND_RGB[n["kind"]], alpha=1.0, rough=0.4, emit=0.3),
                     track=PolyTrack([a, a + 0.5], None, [MIN_SCALE, 1.0], base=size))
            lab = self.label(["%s · %s" % (n["kind"], n["name"])], (x, y - 1.3, 0.03), 0.34, (1, 1, 1), mode="flat")
            lab["track"] = PolyTrack([a, a + 0.5], [lab["loc"]] * 2, [MIN_SCALE, 1.0])
            pos[n["id"]] = (x, y, hgt)
            idx[n["id"]] = k
            n["_hgt"] = hgt
        # edges and packets
        t_r0, t_r1 = S.win["resolve"]
        ports_out, ports_in = {}, {}
        E = [e for e in B["edges"] if e["from"] in pos and e["to"] in pos]
        for i, e in enumerate(E):
            ko, ki = ports_out.get(e["from"], 0), ports_in.get(e["to"], 0)
            ports_out[e["from"]], ports_in[e["to"]] = ko + 1, ki + 1
            sx, sy, _ = pos[e["from"]]
            dx_, dy_, _ = pos[e["to"]]
            e["_p0"] = (sx - 1.7, sy + (ko - 1) * 0.35, 0.8)
            e["_p1"] = (dx_ + 1.7, dy_ + (ki - 1) * 0.35, 0.8)
        for i, e in enumerate(E):
            p0, p1 = e["_p0"], e["_p1"]
            L = math.dist(p0, p1)
            ta = t_r0 + (t_r1 - t_r0) * 0.45 * i / max(len(E) - 1, 1)
            self.add("tube", "ED%d" % i, p0=p0, p1=p1, r=0.07, mat=dict(kind="pbr", rgb=EDGE_RGB[e["type"]], alpha=0.8, rough=0.3, emit=0.4),
                     track=PolyTrack([ta, ta + 0.5], [p0, p0], [(MIN_SCALE, 1, 1), (1, 1, 1)], base=(L, 0.07, 0.07)))
            self.add("sphere", "EH%d" % i, loc=p1, size=(0.17,) * 3, mat=dict(kind="emit", rgb=EDGE_RGB[e["type"]], alpha=1.0),
                     track=PolyTrack([ta, ta + 0.5], [p1, p1], [MIN_SCALE, 1.0], base=(0.17,) * 3))
            ux, uy = (p1[0] - p0[0]) / L, (p1[1] - p0[1]) / L
            q0, q1 = (p0[0] - ux * 0.9, p0[1] - uy * 0.9, 0.8), (p1[0] + ux * 0.9, p1[1] + uy * 0.9, 0.8)
            for m in range(3):
                t = ta + 0.6 + 0.9 * m
                self.add("particle", "PK%d_%d" % (i, m), track=PolyTrack([0.0, t, t + 1.4, self.pb_play], [q0, q0, q1, q1], [1.0] * 4, base=(0.13,) * 3), mat=dict(kind="emit", rgb=(1, 1, 1), alpha=1.0))
        self.stats["edges"] = len(E)
        # lint pips, alarms
        t_l0, t_l1 = S.win["lint"]
        for k, n in enumerate(nodes):
            x, y = n["_xy"]
            a = t_l0 + (t_l1 - t_l0) * 0.6 * k / max(len(nodes) - 1, 1)
            bad = bool(n["failing_rules"])
            rgb = (1.0, 0.2, 0.3) if bad else (0.3, 0.95, 0.45)
            self.add("sphere", "LP%d" % k, loc=(x + 1.25, y - 0.45, n["_hgt"] + 0.3), size=(0.24,) * 3, mat=dict(kind="emit", rgb=rgb, alpha=1.0), track=PolyTrack([a, a + 0.4], None, [MIN_SCALE, 1.0], base=(0.24,) * 3))
            if bad:
                segs, t = [], a + 0.5
                while t + 1.2 <= S.pb - 0.1:
                    segs.append((t, t + 1.2, (x, y, 0.1), (x, y, 0.1), 0.8, 2.6))
                    t += 1.4
                self.add("ring", "LA%d" % k, track=SegTrack(segs, base=(1, 1, 1), jump=dk), mat=dict(kind="emit", rgb=(1.0, 0.2, 0.3), alpha=1.0))
                txt = "; ".join("%s %s" % (r, next(c["text"] for c in B["checks"] if c["rule"] == r)) for r in n["failing_rules"])
                self.label(tts.wrap("FINDING: " + txt, 40), (x, y - 1.85, 0.03), 0.3, (1.0, 0.45, 0.5), mode="flat", valign="top")
                self.items[-1]["track"] = window_track(a + 0.3, S.pb, self.items[-1]["loc"], dk)
        # budget bars
        t_b0, t_b1 = S.win["budget"]
        wl = [n for n in nodes if n["cpu_m"] > 0]
        for k, n in enumerate(wl):
            x, y = n["_xy"]
            a = t_b0 + (t_b1 - t_b0) * 0.4 * k / max(len(wl) - 1, 1)
            h = 0.4 + 3.2 * n["cpu_m"] / cmax
            self.add("bar", "CB%d" % k, loc=(x + 2.6, y, 0.0), size=(0.7, 0.7, h), mat=dict(kind="pbr", rgb=(1.0, 0.8, 0.25), alpha=1.0, rough=0.4, emit=0.6),
                     track=PolyTrack([a, a + 0.8], None, [(1, 1, MIN_SCALE), (1, 1, 1)], base=(0.7, 0.7, h)))
            lab = self.label(["%.0f m CPU" % n["cpu_m"], "x%d replicas" % n["replicas"]] if n["replicas"] > 1 else ["%.0f m CPU" % n["cpu_m"]], (x + 2.6, y, h + 0.7), 0.3, (1.0, 0.9, 0.5))
            lab["track"] = PolyTrack([a, a + 0.8], [lab["loc"]] * 2, [MIN_SCALE, 1.0])
        # legend (edge types) + synthetic plate
        xk = PX0 + 0.5
        for lab, key, w in (("config", "config", 2.4), ("storage", "storage", 2.6), ("identity", "identity", 2.7), ("selects / scales / protects / guards", "selects", 9.0)):
            self.add("sphere", "LG_" + key, loc=(xk + 0.15, PY0 - 1.7, 0.2), size=(0.17,) * 3, mat=dict(kind="emit", rgb=EDGE_RGB[key], alpha=1.0))
            self.label([lab], (xk + 0.45, PY0 - 1.7, 0.03), 0.32, G.C_TEXT, mode="flat", align="left")
            xk += w + 0.6
        self.label(["box height = CPU requests · green pip = passes every rule, red = a finding · bars = CPU requests x replicas"], ((PX0 + PX1) / 2, PY0 - 2.6, 0.03), 0.3, G.C_DIM, mode="flat")
        self.add("plate", "SYN_BG", loc=((PX0 + PX1) / 2, PY0 - 5.9, 0.0), size=(PX1 - PX0 + 1, 4.2, 0.03), mat=dict(kind="pbr", rgb=(0.02, 0.028, 0.045), alpha=0.92, rough=0.9, emit=0.0))
        self.label(["SYNTHETIC BLUEPRINT · the analysis is real, the cluster is not"], ((PX0 + PX1) / 2, PY0 - 3.7, 0.03), 0.5, (1.0, 0.55, 0.2), mode="flat")
        xc = (PX0 + PX1) / 2
        for c in B["insights"]:
            a, b = S.card_window(c["at"])
            b -= dk
            hl = self.label([c["title"]], (xc, PY0 - 5.0, 0.04), 0.72, (1, 1, 1), mode="flat")
            hl["track"] = window_track(a, b, hl["loc"], dk)
            dl = self.label(tts.wrap(c["text"], self.cap_chars(PX1 - PX0 - 2.0, 0.44))[:3], (xc, PY0 - 5.8, 0.04), 0.44, (0.8, 0.9, 1.0), mode="flat", valign="top")
            dl["track"] = window_track(a, b, dl["loc"], dk)
        self.grow(PX0 - 1, PY0 - 8.4, PX1 + 1, PY1 + 1.0)
        self.gmap += ["box = one Kubernetes resource (colour = kind), height = its CPU requests; layers = foundations, workloads, exposure/control",
                      "edge = a reference found in the YAML (config, storage, identity, selectors, autoscaling); packets flow referrer -> referenced during the resolve slot",
                      "pips = lint results per resource (rules R1-R9); bars = CPU requests x replicas; every number comes from the trace (blueprint)"]


def build_infra(trace_path, live=True, **cfg):
    trace = json.load(open(trace_path))
    return G.build_gnn_from_trace(trace, re.sub(r"\W", "_", os.path.basename(trace_path).split(".trace")[0])[:24], live=live, model_cls=InfraModel, **cfg)


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(prog="infra_scene")
    ap.add_argument("--infra-trace", required=True)
    ap.add_argument("--infra-out-x3d", required=True)
    ap.add_argument("--infra-report")
    a = ap.parse_args(argv)
    os.makedirs(os.path.dirname(os.path.abspath(a.infra_out_x3d)), exist_ok=True)
    tts._fresh_blender()
    m = build_infra(a.infra_trace, live=False)
    info = G.export_x3d(m, a.infra_out_x3d)
    md = m.model
    rep = dict(trace=os.path.basename(a.infra_trace), x3d=a.infra_out_x3d, bytes=info["bytes"], kb=round(info["bytes"] / 1024, 1), step=4, frames=md.nf, fps=md.fps, msg_loops=0,
               objects_exported=sum(1 for o in m.scene.objects if not o.get("x3d_skip")), banner=md.banner, mapping=md.mapping_lines(), stats=md.stats, viewpoints=[c["name"] for c in md.cams])
    print("RESULT %.1f KB objects=%d banner=%s -> %s" % (rep["kb"], rep["objects_exported"], md.banner, a.infra_out_x3d))
    if a.infra_report:
        json.dump(rep, open(a.infra_report, "w"), indent=1, default=str)


if bpy is not None and "--infra-trace" in sys.argv:
    main(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:])
