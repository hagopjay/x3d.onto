#!/usr/bin/env python3
"""flywheel_scene.py: 'The X3D flywheel' showcase. A wheel of eight stations (spec, agents, MCP, Blender+fork, blender_mcp, runtimes, verdict, tether) with packets
circling it, a hub that shows the active station's REAL facts, the hash-chain tether (x3dprov steps of the loop run), evidence bars from the recorded live run, a stage
strip with the real timings of the loop, and heuristic cards. Built on the generic builder (untouched) and the helpers of gnn_scene.py.

Headless:  Blender -b --factory-startup -noaudio --python scripts/scene/flywheel_scene.py -- --fw-trace traces/x3d-flywheel.trace.json --fw-out-x3d scenes/x3d-flywheel.x3d [--fw-report J]
Every number comes from the trace (facts graded C = measured now, R = recorded elsewhere); display-only: playback stretch, log scale of the latency bars, layout."""
import copy
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(globals().get("__file__") or os.path.join(os.environ.get("GNN_SCENE_DIR", "."), "flywheel_scene.py")))
sys.path.insert(0, HERE)
_argv, sys.argv = sys.argv, sys.argv[:1]
import gnn_scene as G                                       # noqa: E402
sys.argv = _argv
tts, bpy = G.tts, G.bpy
MIN_SCALE, SegTrack, PolyTrack, window_track = G.MIN_SCALE, G.SegTrack, G.PolyTrack, G.window_track
CX, CY, RR = 22.0, -19.0, 7.2
ANGLES = [90, 45, 0, -45, -90, -135, 180, 135]
RGB = dict(spec=(0.2, 0.55, 1.0), agent=(0.8, 0.4, 1.0), mcp=(0.2, 0.85, 0.7), fork=(1.0, 0.55, 0.15), bmcp=(1.0, 0.78, 0.2), runtime=(0.4, 0.9, 0.4), verdict=(1.0, 0.3, 0.45), tether=(1.0, 0.88, 0.4))
SHORT = {"xsd": "xsd", "profile-component": "profile-comp", "containerfield-type-mismatch": "cf-type", "containerfield-unknown": "cf-unknown", "duplicate-def": "dup-def", "interpolator-key-length": "key-length", "tuple-count": "tuple-count"}
UNIT = 30.0                                                  # card timeline units: 8 stations x 3.2 + 2 outro cards x 2.2


def sp(k, r=RR):
    a = math.radians(ANGLES[k])
    return CX + r * math.cos(a), CY + r * math.sin(a)


def display_trace(tr, pb):
    d = copy.deepcopy(tr)
    d.pop("flywheel", None)
    d["time"]["duration"] = pb
    n = len(d["stages"])
    for i, s in enumerate(d["stages"]):
        s["start_s"], s["end_s"] = pb * i / n, pb * (i + 1) / n
    ids = {s["id"]: s for s in d["stages"]}
    for f in d["flows"]:
        f["start_s"], f["end_s"] = ids[f["from"]]["end_s"], ids[f["to"]]["start_s"]
    d["series"], d["entities"] = {"t": [], "channels": {}}, []
    return d


class FlywheelModel(tts.Model):
    def __init__(self, trace, **cfg):
        cfg = dict(dict(n_frames=720, step=4, amb_total=14, amb_cap=2), **{k: v for k, v in cfg.items() if v is not None})
        self.gtr, self.W = trace, trace["flywheel"]
        self.pb_play = (int(cfg["n_frames"]) - 1) / int(cfg.get("fps", tts.DEFAULTS["fps"]))
        self.u = self.pb_play / UNIT
        self.gmap = []
        super().__init__(display_trace(trace, self.pb_play), **cfg)
        self.items = [it for it in self.items if not (it["kind"] == "label" and it["mode"] == "flat" and abs(it["loc"][1] - (self.ymin_m - 1.3)) < 1e-6)]

    # ---- generic parts
    def _stages(self):
        super()._stages()
        wmax = max(s["metrics"]["wall_ms"] for s in self.gtr["stages"])
        st = {s["id"]: s for s in self.gtr["stages"]}
        self.stage_rgb = {}
        for it in self.items:
            if it["kind"] == "block":
                rgb = tts.ramp(math.log1p(st[it["sid"]]["metrics"]["wall_ms"]) / math.log1p(wmax))
                it["mat"]["rgb"] = rgb
                self.stage_rgb[it["sid"]] = rgb
                self.pos[it["sid"]]["rgb"] = rgb

    def mapping_lines(self):
        base = [l for l in super().mapping_lines() if not l.startswith("block colour") and not l.startswith("floor ruler")]
        return base + ["block colour = log(wall_ms) of that loop stage relative to the slowest (blue, amber, red); the numbers on the strip are real measured milliseconds"] + self.gmap

    def _bars(self):
        self.fam, self.gauges, self.bar_peak, self.gauge_y = {}, [], {}, self.ymax_m + 2.4
        for s_ in self.tr["stages"]:
            p = self.pos[s_["id"]]
            self.label([s_["stage_key"].upper()], (p["x"], p["y"], p["sz"] + 0.9), 0.45, (1, 1, 1))

    def _timeline(self):
        pb = self.pb_play
        x0, x1 = -1.0, (len(self.layers) - 1) * self.dx + 1.0
        Wr, yt = x1 - x0, -4.9
        xs = lambda t: x0 + Wr * min(max(t / pb, 0.0), 1.0)
        R = self.W["results"]
        chips = dict(ground=lambda m: ["%d node types" % R["grounding"]["types"], "%d fields" % R["grounding"]["fields"]], build=lambda m: ["%s objects" % "{:,}".format(R["file"]["objects"]), "%s KB" % tts.fmt_num(float("%.3g" % (R["file"]["bytes"] / 1024)))],
                     validate=lambda m: ["xsd valid", "%d infos" % R["validate"]["infos"]], repair=lambda m: ["defect: %d errors" % R["defect"]["semantic_errors"], "after repair %d" % R["repair"]["semantic_errors_after"]],
                     revalidate=lambda m: ["xsd valid", "0 errors"], roundtrip=lambda m: ["record kept:", str(R["roundtrip"]["meta_kept"])],
                     render=lambda m: ["%s%% pixels" % tts.fmt_num(float("%.3g" % R["render"]["nonblank_pct"])), "cached render" if R["render"].get("cached") else "drawn"], stamp=lambda m: ["%d steps" % len(R["tether"]["steps"]), R["tether"]["verdict"]])
        self.add("plate", "STRIP_BASE", loc=((x0 + x1) / 2, yt - 0.4, 0.0), size=(Wr + 0.3, 2.2, 0.05), mat=dict(kind="pbr", rgb=G.C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        for i, s_ in enumerate(self.gtr["stages"]):
            a, b = pb * i / 8, pb * (i + 1) / 8
            xc = (xs(a) + xs(b)) / 2
            self.add("plate", "SEG_" + s_["id"], loc=(xc, yt, 0.06), size=(xs(b) - xs(a) - 0.12, 0.9, 0.08), mat=dict(kind="pbr", rgb=self.stage_rgb[s_["id"]], alpha=1.0, rough=0.5, emit=0.35))
            self.label([s_["stage_key"]], (xc, yt + 0.14, 0.16), 0.36, (1, 1, 1), mode="flat")
            self.label(["%s ms" % tts.fmt_num(float("%.3g" % s_["metrics"]["wall_ms"]))], (xc, yt - 0.26, 0.16), 0.34, (1, 1, 0.8), mode="flat")
            self.label(chips[s_["stage_key"]](s_["metrics"]), (xc, yt - 0.8, 0.06), 0.3, (0.78, 0.86, 0.95), mode="flat", valign="top")
        self.caption = "the strip = the REAL loop run on this scene (measured ms; stretched over %.0f s of playback); the wheel = what each part of the toolchain contributes" % pb
        self.label([self.caption], (x0, yt - 1.9, 0.02), 0.3, (0.9, 0.9, 0.6), mode="flat", align="left")
        self.add("plate", "CURSOR", loc=(x0, yt, 0.2), size=(0.08, 1.4, 0.4), mat=dict(kind="emit", rgb=(1, 1, 0.6), alpha=1.0),
                 track=SegTrack([(-1.0, 0.0, (x0, yt, 0.2), (x0, yt, 0.2), 1, 1), (0.0, pb, (x0, yt, 0.2), (x1, yt, 0.2), 1, 1), (pb, pb + 10, (x1, yt, 0.2), (x1, yt, 0.2), 1, 1)], base=(0.08, 1.4, 0.4)))
        self.flat_banner_y = -42.0
        self.grow(x0 - 1.0, yt - 2.4, x1 + 1.0, yt + 0.8)
        self.mapping.append("stage strip: the loop stages with their real measured milliseconds and results; cursor = playback time")

    def _rig(self):
        super()._rig()
        x0, y0, x1, y1 = self.bb
        Hh, cx = self.wall["H"], (x0 + x1) / 2

        def cam(name, desc, tgt, el, pts, fov=50.0):
            e = math.radians(el)
            dv = (0.0, -math.cos(e), math.sin(e))
            d = self._fit(tgt, dv, pts, fov, margin=0.97)
            return dict(name=name, desc=desc, loc=tuple(tgt[i] + dv[i] * d for i in range(3)), target=tgt, fov=fov)
        box = lambda xa, xb, ya, yb, zs=(0.0, 3.0): [(x, y, z) for x in (xa, xb) for y in (ya, yb) for z in zs]
        ya = self.flat_banner_y - 0.8
        self.cams = [cam("VP1_Demo", "Demo: loop strip, the wheel, tether, evidence, heuristic cards", (cx, (ya + 2.0) / 2, 0.5), 50.0, box(x0, x1, ya, 2.5, (0.0, 4.5))),
                     cam("VP2_Overview", "Overview: everything including the title wall", (cx, (y0 + y1) / 2, 1.5), 40.0, box(x0, x1, y0, y1, (0.0, Hh))),
                     cam("VP3_Wheel", "Close-up: the flywheel", (CX, CY, 0.0), 62.0, box(CX - 12, CX + 12, CY - 12, CY + 11, (0.0, 4.5))),
                     cam("VP4_Tether", "Close-up: the hash-chain tether", (2.0, CY, 4.0), 42.0, box(-3.5, 8.0, CY - 9, CY + 7, (0.0, 12.0))),
                     cam("VP5_Evidence", "Close-up: evidence from the recorded live run", (41.5, CY - 1.0, 1.0), 55.0, box(35.0, 48.0, -30.0, -8.0, (0.0, 5.5))),
                     cam("VP6_Pipeline", "Close-up: the loop stages with real timings", (cx, -2.0, 0.5), 36.0, box(x0, x1, -8.0, 2.0, (0.0, 4.0))),
                     cam("VP7_Top", "Top view", (cx, (y0 + y1) / 2, 0.0), 89.0, [(x, y, 0.0) for x in (x0, x1) for y in (y0, y1)], 55.0),
                     cam("VP8_Wall", "Close-up: title wall", (cx, self.wall["y"], Hh / 2), 6.0, box(x0, x1, self.wall["y"] - 0.2, self.wall["y"] + 0.2, (0.0, Hh)))]

    # ---- the showcase
    def _entities(self):
        self.ents, self.ent_end_y = [], 0.0
        self._floor()
        self._wheel()
        self._tether()
        self._evidence()
        self._meter()
        self._cards()

    def _floor(self):
        x0, x1, y0, y1 = -8.0, 58.0, -54.0, 12.0
        self.add("plate", "FLOOR", loc=((x0 + x1) / 2, (y0 + y1) / 2, -0.1), size=(x1 - x0, y1 - y0, 0.04), mat=dict(kind="pbr", rgb=(0.016, 0.02, 0.032), alpha=1.0, rough=0.95, emit=0.0))
        grid = dict(kind="emit", rgb=(0.05, 0.065, 0.10), alpha=1.0)
        for gx in range(-5, 58, 5):
            self.add("plate", "GX%d" % (gx + 5), loc=(gx, (y0 + y1) / 2, -0.07), size=(0.03, y1 - y0, 0.01), mat=grid)
        for gy in range(-55, 12, 5):
            self.add("plate", "GY%d" % (gy + 50), loc=((x0 + x1) / 2, gy, -0.07), size=(x1 - x0, 0.03, 0.01), mat=grid)

    def _wheel(self):
        W, u, dk = self.W, self.u, self.dk
        S = W["stations"]
        self.add("ring", "RING", loc=(CX, CY, 0.06), size=(RR, RR, RR), mat=dict(kind="emit", rgb=(0.22, 0.3, 0.45), alpha=1.0))
        for k, st in enumerate(S):
            x, y = sp(k)
            rgb = RGB[st["key"]]
            self.add("block", "PED%d" % k, loc=(x, y, 0.0), size=(2.8, 2.8, 0.7), mat=dict(kind="pbr", rgb=tuple(0.55 * c for c in rgb), alpha=1.0, rough=0.5, emit=0.2))
            ic = dict(kind="pbr", rgb=rgb, alpha=1.0, rough=0.25, emit=0.5)
            if st["key"] == "spec":
                for j in range(3):
                    self.add("plate", "IC%d_%d" % (k, j), loc=(x, y, 1.0 + 0.42 * j), size=(1.9 - 0.25 * j, 1.5, 0.16), mat=ic)
            elif st["key"] in ("mcp", "verdict"):
                self.add("plate", "IC%d" % k, loc=(x, y, 1.6), size=(1.4, 1.4, 1.4), mat=ic)
                self.add("sphere", "ICp%d" % k, loc=(x + 1.0, y, 1.6), size=(0.35,) * 3, mat=dict(kind="emit", rgb=(1, 1, 1), alpha=1.0))
            elif st["key"] == "tether":
                for j in range(3):
                    self.add("ring2", "IC%d_%d" % (k, j), loc=(x, y, 1.0 + 0.5 * j), size=(0.9, 0.9, 1.0), mat=dict(kind="emit", rgb=rgb, alpha=1.0))
            elif st["key"] == "agent":                      # a mind with three thoughts orbiting it
                self.add("sphere", "IC%d" % k, loc=(x, y, 1.7), size=(0.8,) * 3, mat=ic)
                for j in range(3):
                    a_ = math.radians(120 * j + 20)
                    self.add("sphere", "ICo%d_%d" % (k, j), loc=(x + 1.25 * math.cos(a_), y + 1.25 * math.sin(a_), 1.7 + 0.3 * j), size=(0.25,) * 3, mat=dict(kind="emit", rgb=rgb, alpha=1.0))
            elif st["key"] == "runtime":                    # two screens
                for j, dx_ in enumerate((-0.75, 0.75)):
                    self.add("plate", "IC%d_%d" % (k, j), loc=(x + dx_, y, 1.5), size=(1.2, 0.12, 1.0), mat=ic)
                    self.add("plate", "ICs%d_%d" % (k, j), loc=(x + dx_, y - 0.08, 1.5), size=(0.9, 0.05, 0.7), mat=dict(kind="emit", rgb=(0.9, 1.0, 0.9), alpha=1.0))
            elif st["key"] == "bmcp":                       # a bridge between two spheres
                for dx_ in (-1.0, 1.0):
                    self.add("sphere", "IC%d_%d" % (k, int(dx_)), loc=(x + dx_, y, 1.6), size=(0.55,) * 3, mat=ic)
                self.add("tube", "ICt%d" % k, p0=(x - 1.0, y, 1.6), p1=(x + 1.0, y, 1.6), r=0.12, mat=dict(kind="emit", rgb=rgb, alpha=1.0))
            else:                                           # Blender: sphere in a ring
                self.add("sphere", "IC%d" % k, loc=(x, y, 1.7), size=(0.95,) * 3, mat=ic)
                self.add("ring2", "ICr%d" % k, loc=(x, y, 1.7), size=(1.5, 1.5, 1.0), mat=dict(kind="emit", rgb=rgb, alpha=1.0))
            ox, oy = sp(k, RR + 3.0)
            self.label([st["name"]], (ox, oy + 0.35, 0.04), 0.55, (1, 1, 1), mode="flat")
            self.label([st["headline"]], (ox, oy - 0.45, 0.04), 0.45, rgb, mode="flat")
            a, b = k * 3.2 * u, (k + 1) * 3.2 * u
            self.add("plate", "PAD%d" % k, loc=(x, y, 0.03), size=(4.1, 4.1, 0.05), mat=dict(kind="emit", rgb=rgb, alpha=1.0), track=window_track(a, b - dk, (x, y, 0.03), dk, base=(4.1, 4.1, 0.05)))
            # hub card: the active station's facts (grade + source on the last line)
            hl = self.label([st["name"]], (CX, CY + 4.6, 0.04), 0.7, rgb, mode="flat")
            hl["track"] = window_track(a, b - dk, hl["loc"], dk)
            body = []
            for ln in st["lines"]:
                body += tts.wrap("• " + ln, self.cap_chars(12.2, 0.44))
            body += tts.wrap("[%s] %s" % (st["grade"], st["source"]), self.cap_chars(12.2, 0.44))
            bl = self.label(body, (CX - 6.0, CY + 3.5, 0.04), 0.44, (0.9, 0.95, 1.0), mode="flat", align="left", valign="top")
            bl["track"] = window_track(a, b - dk, bl["loc"], dk)
        # packets circle the wheel (clockwise): the XML draft, the verdict, the stamp
        T, N = self.pb_play / 2.0, 120
        for pi, (rgb, ph) in enumerate(((((0.9, 1.0, 1.0)), 0.0), ((0.3, 1.0, 0.5), 1 / 3.0), ((1.0, 0.85, 0.3), 2 / 3.0))):
            ts = [self.pb_play * j / (2 * N) for j in range(2 * N + 1)]
            locs = [(CX + RR * math.cos(math.radians(90) - 2 * math.pi * (t / T + ph)), CY + RR * math.sin(math.radians(90) - 2 * math.pi * (t / T + ph)), 0.9) for t in ts]
            self.add("sphere", "PKT%d" % pi, loc=locs[0], size=(0.3,) * 3, mat=dict(kind="emit", rgb=rgb, alpha=1.0), track=PolyTrack(ts, locs, None, base=(0.3,) * 3))
        # the inner loop: agent <-> MCP (XML out, validator report back)
        pts = [(CX + 5.4 * math.cos(math.radians(a)), CY + 5.4 * math.sin(math.radians(a))) for a in (0, 11, 22, 33, 45)]
        for j in range(4):
            p0, p1 = (pts[j][0], pts[j][1], 0.5), (pts[j + 1][0], pts[j + 1][1], 0.5)
            self.add("tube", "ARC%d" % j, p0=p0, p1=p1, r=0.07, mat=dict(kind="pbr", rgb=(1.0, 0.7, 0.2), alpha=0.8, rough=0.3, emit=0.5))
        self.label(["draft out, validator report back"], (CX + 6.9, CY + 2.2, 0.03), 0.3, (1.0, 0.75, 0.3), mode="flat", align="left")
        for pi, (rgb, off) in enumerate(((((0.9, 1.0, 1.0)), 0.0), ((1.0, 0.7, 0.2), 0.5))):
            ts = [j * 0.3 for j in range(int(self.pb_play / 0.3) + 1)]
            locs = []
            for t in ts:
                f = 0.5 - 0.5 * math.cos(2 * math.pi * (t / 2.4 + off))
                a = math.radians(45 * f)
                locs.append((CX + 5.4 * math.cos(a), CY + 5.4 * math.sin(a), 0.7))
            self.add("sphere", "BNC%d" % pi, loc=locs[0], size=(0.22,) * 3, mat=dict(kind="emit", rgb=rgb, alpha=1.0), track=PolyTrack(ts, locs, None, base=(0.22,) * 3))
        self.grow(-4.0, CY - RR - 3.5, 48.0, CY + RR + 5.0)
        self.gmap += ["wheel: eight stations of the toolchain; the lit pad is the station whose real facts the hub shows (grade C = measured now, R = recorded, source named); packets circle clockwise",
                      "inner arc: the agent sends a draft, the validator's report comes back (the loop that closes the gap between first try and valid)"]

    def _tether(self):
        T = self.W["tether"]
        steps = T["steps"]
        x, y0 = 2.0, CY - 6.0
        self.add("plate", "TPAN", loc=(x, CY, -0.02), size=(10.0, 17.0, 0.08), mat=dict(kind="pbr", rgb=G.C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        self.label(["THE TETHER"], (x, CY - 7.5, 0.04), 0.75, (1.0, 0.88, 0.4), mode="flat")
        self.label(["x3dprov: hash-chained steps in the file's head meta"], (x, CY - 8.4, 0.04), 0.3, G.C_DIM, mode="flat")
        a7, b7 = 7 * 3.2 * self.u, 8 * 3.2 * self.u
        for i, st in enumerate(steps):
            z = 0.2 + i * 1.18
            a = self.u * (0.4 + i * 22.0 / max(len(steps), 1))                  # the chain grows link by link while the wheel turns
            size = (3.0, 1.5, 0.8)
            self.add("block", "TB%d" % i, loc=(x - 1.0, CY - 1.0, z), size=size, mat=dict(kind="pbr", rgb=(1.0, 0.82, 0.3), alpha=1.0, rough=0.4, emit=0.45), track=PolyTrack([a, a + 0.5], None, [MIN_SCALE, 1.0], base=size))
            lab = self.label(["%d  %s" % (i + 1, st["op"]), st["hash8"]], (x + 2.1, CY - 1.0, z + 0.5), 0.36, (1, 1, 1))
            lab["track"] = PolyTrack([a, a + 0.5], [lab["loc"]] * 2, [MIN_SCALE, 1.0])
            if i:
                self.add("bar", "TL%d" % i, loc=(x - 1.0, CY - 1.0, z - 0.4), size=(0.18, 0.18, 0.55), mat=dict(kind="emit", rgb=(1.0, 0.9, 0.5), alpha=1.0), track=PolyTrack([a, a + 0.5], None, [MIN_SCALE, 1.0], base=(0.18, 0.18, 0.55)))
        if steps:
            zt = 0.2 + len(steps) * 1.18
            self.add("sphere", "TV", loc=(x - 1.0, CY - 1.0, zt + 0.5), size=(0.55,) * 3, mat=dict(kind="emit", rgb=(0.3, 1.0, 0.5) if T["verdict"] == "verified" else (1.0, 0.4, 0.4), alpha=1.0),
                     track=PolyTrack([b7 - 0.5, b7], None, [MIN_SCALE, 1.0], base=(0.55,) * 3))
            v = self.label(["verify: " + T["verdict"]], (x - 1.0, CY - 1.0, zt + 1.4), 0.5, (0.3, 1.0, 0.5) if T["verdict"] == "verified" else (1.0, 0.4, 0.4))
            v["track"] = PolyTrack([b7 - 0.5, b7], [v["loc"]] * 2, [MIN_SCALE, 1.0])
        else:
            self.label(["appears after the loop has run"], (x, CY, 0.05), 0.4, G.C_DIM, mode="flat")
        # tamper tests (real verify() results on edited copies)
        o0 = 25.6 * self.u
        for j, tt in enumerate(T["tamper"]):
            lab = self.label(tts.wrap("%s: %s" % (tt["what"], tt["status"]), 30), (x - 4.4, CY - 4.4 - 0.9 * j, 0.04), 0.3, (1.0, 0.8, 0.5), mode="flat", align="left", valign="top")
            lab["track"] = window_track(o0, self.pb_play, lab["loc"], self.dk)
        # cable from the tether station to the column
        sx, sy = sp(7)
        p0, p1 = (sx - 1.5, sy, 0.5), (x + 5.0, CY + 5.0, 0.5)
        L = math.dist(p0, p1)
        self.add("tube", "CABLE", p0=p0, p1=p1, r=0.14, mat=dict(kind="pbr", rgb=(1.0, 0.85, 0.3), alpha=0.9, rough=0.3, emit=0.6))
        self.gmap += ["tether column: the x3dprov steps of the loop run (op + first 8 hex of the output hash); verify says verified / stale / broken-chain; tamper lines are real verify() results on edited copies"]

    def _evidence(self):
        L = self.W["live"]
        x0 = 36.6
        self.add("plate", "EPAN", loc=(41.5, CY - 0.5, -0.02), size=(11.4, 21.0, 0.08), mat=dict(kind="pbr", rgb=G.C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        self.label(["EVIDENCE"], (41.5, CY + 9.7, 0.04), 0.75, G.C_TEXT, mode="flat")
        self.label(["recorded live run, 17 Oct 2026 (grade R), models anonymised"], (41.5, CY + 8.7, 0.04), 0.3, G.C_DIM, mode="flat")
        a6 = 6 * 3.2 * self.u
        # chart 1: valid on the first try vs after the loop
        yb = CY + 3.0
        self.label(["valid first try (blue) vs after the report loop (green), % of scenes"], (41.5, yb + 4.6, 0.04), 0.3, G.C_TEXT, mode="flat")
        for i, m in enumerate(L["models"]):
            x = x0 + 0.4 + i * 1.95
            for j, (key, rgb, t0) in enumerate((("first_pct", (0.4, 0.6, 0.95), a6), ("end_pct", (0.3, 0.95, 0.5), a6 + 1.6))):
                h = 0.05 + 3.6 * m[key] / 100.0
                self.add("bar", "EB%d_%d" % (i, j), loc=(x + 0.7 * j, yb, 0.0), size=(0.6, 0.6, h), mat=dict(kind="pbr", rgb=rgb, alpha=1.0, rough=0.4, emit=0.45), track=PolyTrack([t0, t0 + 1.0], None, [(1, 1, MIN_SCALE), (1, 1, 1)], base=(0.6, 0.6, h)))
                lab = self.label(["%d" % m[key]], (x + 0.7 * j, yb, h + 0.5), 0.38, (1, 1, 1))
                lab["track"] = PolyTrack([t0, t0 + 1.0], [lab["loc"]] * 2, [MIN_SCALE, 1.0])
            self.label([m["model"].replace("model ", "")], (x + 0.35, yb - 0.7, 0.03), 0.4, G.C_TEXT, mode="flat")
        # chart 2: validator vs model call latency (log scale, display only)
        yb2 = CY - 4.2
        a2 = 2 * 3.2 * self.u
        self.label(["time per step, log scale: validation vs a model call"], (41.5, yb2 + 3.9, 0.04), 0.3, G.C_TEXT, mode="flat")
        calls = [m["median_call_s"] for m in L["models"]]
        bars = [("validate", L["median_validate_ms"], "%s ms" % tts.fmt_num(L["median_validate_ms"]), (0.3, 0.95, 0.5)), ("median call", L["median_call_s"] * 1000.0, "%s s" % tts.fmt_num(L["median_call_s"]), (0.8, 0.5, 1.0)),
                ("slowest model", max(calls) * 1000.0, "%s s" % tts.fmt_num(max(calls)), (1.0, 0.4, 0.45))]
        for i, (nm, ms_, txt, rgb) in enumerate(bars):
            x = x0 + 1.3 + i * 3.0
            h = 0.6 + 0.62 * max(math.log10(ms_) , 0.0)
            self.add("bar", "LB%d" % i, loc=(x, yb2, 0.0), size=(0.9, 0.9, h), mat=dict(kind="pbr", rgb=rgb, alpha=1.0, rough=0.4, emit=0.45), track=PolyTrack([a2, a2 + 1.0], None, [(1, 1, MIN_SCALE), (1, 1, 1)], base=(0.9, 0.9, h)))
            lab = self.label([txt], (x, yb2, h + 0.6), 0.42, (1, 1, 1))
            lab["track"] = PolyTrack([a2, a2 + 1.0], [lab["loc"]] * 2, [MIN_SCALE, 1.0])
            self.label([nm], (x, yb2 - 0.8, 0.03), 0.3, G.C_TEXT, mode="flat")
        # chart 3: what fails first (scenes carrying the code on the first attempt)
        yb3 = CY - 11.2
        self.label(["what fails first: scenes carrying the code (all models)"], (41.5, yb3 + 3.6, 0.04), 0.3, G.C_TEXT, mode="flat")
        codes = list(L["codes"].items())[:6]
        cmax = max(v for _, v in codes)
        for i, (c, v) in enumerate(codes):
            x = x0 + 0.5 + i * 1.65
            h = 0.1 + 3.0 * v / cmax
            self.add("bar", "CB%d" % i, loc=(x, yb3, 0.0), size=(0.7, 0.7, h), mat=dict(kind="pbr", rgb=(1.0, 0.6, 0.25), alpha=1.0, rough=0.4, emit=0.45), track=PolyTrack([a6 + 0.5, a6 + 1.5], None, [(1, 1, MIN_SCALE), (1, 1, 1)], base=(0.7, 0.7, h)))
            lab = self.label(["%d" % v], (x, yb3, h + 0.5), 0.36, (1, 1, 1))
            lab["track"] = PolyTrack([a6 + 0.5, a6 + 1.5], [lab["loc"]] * 2, [MIN_SCALE, 1.0])
            self.label([SHORT.get(c, c[:11])], (x, yb3 - 0.7 - 0.35 * (i % 2), 0.03), 0.24, G.C_TEXT, mode="flat")
        self.gmap += ["evidence bars: recorded live run (50 prompts, 5 models, 358 calls); pairs = valid on the first try vs after feeding the validator report back; latency bars are log scale (display)"]

    def _meter(self):
        """Flywheel meter: the last real loop runs (from history.json), each tied to the git commit it ran on. Bars = warm validation ms; pip = green when that run was clean."""
        H = self.W.get("history") or []
        y0 = -32.0
        self.add("plate", "MET_BG", loc=(CX, y0, -0.01), size=(30.0, 3.4, 0.05), mat=dict(kind="pbr", rgb=G.C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        self.label(["FLYWHEEL METER: each real loop run, with the commit it ran on (bar = warm validation ms, dot = clean run)"], (CX, y0 + 1.35, 0.03), 0.3, G.C_DIM, mode="flat")
        if not H:
            self.label(["no history yet: run scripts/flywheel/iterate.sh"], (CX, y0, 0.03), 0.34, G.C_DIM, mode="flat")
            return
        wmax = max(r["validate_warm_ms"] for r in H) or 1.0
        for i, r in enumerate(H):
            x = CX - 12.5 + i * 5.0
            h = 0.15 + 1.2 * r["validate_warm_ms"] / wmax
            a = self.u * (1.0 + 0.5 * i)
            self.add("bar", "MB%d" % i, loc=(x, y0 - 0.9, 0.0), size=(0.7, 0.7, h), mat=dict(kind="pbr", rgb=(1.0, 0.75, 0.25), alpha=1.0, rough=0.4, emit=0.5), track=PolyTrack([a, a + 0.6], None, [(1, 1, MIN_SCALE), (1, 1, 1)], base=(0.7, 0.7, h)))
            clean = r["semantic_errors_after_repair"] == 0 and r["tether"] == "verified" and r["render_pct"] > 30
            self.add("sphere", "MP%d" % i, loc=(x + 1.2, y0 - 0.55, 0.3), size=(0.22,) * 3, mat=dict(kind="emit", rgb=(0.3, 1.0, 0.5) if clean else (1.0, 0.3, 0.35), alpha=1.0))
            self.label(["%s%s" % (r["repo"]["head"] or "-", "*" if r["repo"]["dirty"] else ""), "%s ms" % tts.fmt_num(float("%.3g" % r["validate_warm_ms"]))], (x + 0.8, y0 - 0.6, 0.04), 0.28, (1, 1, 1), mode="flat", align="left", valign="center")
        self.gmap += ["flywheel meter: the last %d real loop runs; label = git commit (* = uncommitted changes), bar = warm validation ms, green dot = clean run (0 errors after repair, tether verified, scene drawn)" % len(H)]

    def _cards(self):
        W, u, dk = self.W, self.u, self.dk
        xc = CX + 1.0
        yh = -37.0
        self.add("plate", "SUB_BG", loc=(xc, yh - 1.2, 0.0), size=(52.0, 5.4, 0.03), mat=dict(kind="pbr", rgb=(0.02, 0.028, 0.045), alpha=0.92, rough=0.9, emit=0.0))
        cards = W["insights"]
        for idx, c in enumerate(cards):
            at = c["at"]
            if "station" in at:
                a, b = at["station"] * 3.2 * u, (at["station"] + 1) * 3.2 * u
            else:
                a, b = (25.6 + 2.2 * at["outro"]) * u, (25.6 + 2.2 * (at["outro"] + 1)) * u
            b -= dk
            xd, yd = xc + (idx - (len(cards) - 1) / 2) * 0.7, yh + 1.4
            self.add("particle", "cd%d" % idx, loc=(xd, yd, 0.1), size=(0.1,) * 3, mat=dict(kind="emit", rgb=(0.3, 0.36, 0.48), alpha=1.0))
            self.add("particle", "ca%d" % idx, loc=(xd, yd, 0.12), size=(0.18,) * 3, mat=dict(kind="emit", rgb=(1.0, 1.0, 0.6), alpha=1.0), track=window_track(a, b, (xd, yd, 0.12), dk, base=(0.18,) * 3))
            hl = self.label([c["title"]], (xc, yh, 0.04), 0.8, (1, 1, 1), mode="flat")
            hl["track"] = window_track(a, b, hl["loc"], dk)
            dl = self.label(tts.wrap(c["text"], self.cap_chars(48.0, 0.46))[:3], (xc, yh - 0.8, 0.04), 0.46, (0.8, 0.9, 1.0), mode="flat", valign="top")
            dl["track"] = window_track(a, b, dl["loc"], dk)
            gl = self.label(["grade %s (%s)  ·  station: %s" % (c["grade"], "measured now" if c["grade"] == "C" else "recorded elsewhere", c["station"])], (xc, yh - 3.0, 0.04), 0.3, G.C_DIM, mode="flat")
            gl["track"] = window_track(a, b, gl["loc"], dk)
        self.grow(-4.0, yh - 4.5, 46.0, yh + 2.0)
        self.gmap += ["cards: ten heuristics, each with its numbers in the trace, a grade (C measured now / R recorded) and the station it belongs to"]


def build_fw(trace_path, live=True, **cfg):
    trace = json.load(open(trace_path))
    return G.build_gnn_from_trace(trace, re.sub(r"\W", "_", os.path.basename(trace_path).split(".trace")[0])[:24], live=live, model_cls=FlywheelModel, **cfg)


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(prog="flywheel_scene")
    ap.add_argument("--fw-trace", required=True)
    ap.add_argument("--fw-out-x3d", required=True)
    ap.add_argument("--fw-report")
    a = ap.parse_args(argv)
    os.makedirs(os.path.dirname(os.path.abspath(a.fw_out_x3d)), exist_ok=True)
    tts._fresh_blender()
    m = build_fw(a.fw_trace, live=False)
    info = G.export_x3d(m, a.fw_out_x3d)
    md = m.model
    xml = open(a.fw_out_x3d, encoding="utf-8").read()
    n_int = len(re.findall(r"<PositionInterpolator ", xml))
    int_bytes = sum(len(l.encode()) + 1 for l in xml.split("\n") if "Interpolator" in l)
    rep = dict(trace=os.path.basename(a.fw_trace), x3d=a.fw_out_x3d, bytes=info["bytes"], kb=round(info["bytes"] / 1024, 1), step=4, frames=md.nf, fps=md.fps, msg_loops=0,
               objects=sum(1 for o in m.scene.objects if not o.get("x3d_skip")), interpolators=n_int, interpolator_pct=round(100 * int_bytes / max(info["bytes"], 1), 1), banner=md.banner,
               mapping=md.mapping_lines(), viewpoints=[c["name"] for c in md.cams])
    print("RESULT %.1f KB objects=%d interpolators=%d (%.1f%% of bytes) -> %s" % (rep["kb"], rep["objects"], n_int, rep["interpolator_pct"], a.fw_out_x3d))
    if a.fw_report:
        json.dump(rep, open(a.fw_report, "w"), indent=1, default=str)


if bpy is not None and "--fw-trace" in sys.argv:
    main(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:])
