#!/usr/bin/env python3
"""gnn_scene.py: the 'mlops-gnn' scene = the generic MLOps pipeline machine (trace_to_scene.Model, reused as a base class and left
untouched) + a clearly separate graph module (friendship network, embedding space, training curves, message particles, insight subtitles).

Headless:  Blender -b --factory-startup -noaudio --python scripts/scene/gnn_scene.py -- \
               --gnn-trace traces/gnn-karate.trace.json --gnn-out-x3d scenes/gnn-karate.x3d [--gnn-out-blend B] [--gnn-max-kb 900] [--gnn-report J]
(The flags are deliberately not --trace/--out-x3d: importing trace_to_scene with those flags present would start ITS command line.)
Live:  exec this file's text in a running Blender, then  m = build_gnn(trace_path, live=True);  export_x3d(m, path)  (see trace_to_scene.py).

HONESTY RULES (same as the generic builder): every number comes from the trace; derived values are listed in the mapping legend on the scene.
Derived/display-only here: playback time stretching (each stage a fixed slot, epochs replayed evenly), the force layout of the network panel,
sphere radius = f(confidence), "undecided" threshold, vertical stacking of members that sit on exactly the same embedding spot, axis frames.
No keyframes and no fcurves: one frame_change handler (trace_to_scene._x3d_trace_frame_handler) moves/scales objects; the X3D exporter samples it.
"""
import copy
import importlib.util
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(globals().get("__file__") or os.path.join(os.environ.get("GNN_SCENE_DIR", "."), "gnn_scene.py")))


def _load_tts():
    """The generic builder: the file next to this one, or (inside a saved .blend) its embedded text 'trace_to_scene.py'."""
    path = os.path.join(HERE, "trace_to_scene.py")
    if os.path.exists(path):
        spec = importlib.util.spec_from_file_location("trace_to_scene", path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules["trace_to_scene"] = mod
        spec.loader.exec_module(mod)
        return mod
    import types
    import bpy as _bpy
    mod = types.ModuleType("trace_to_scene")
    mod.__file__ = "trace_to_scene.py"
    sys.modules["trace_to_scene"] = mod
    exec(compile(_bpy.data.texts["trace_to_scene.py"].as_string(), "trace_to_scene.py", "exec"), mod.__dict__)
    return mod


tts = _load_tts()
bpy, mathutils = tts.bpy, tts.mathutils
MIN_SCALE = tts.MIN_SCALE
SegTrack = tts.SegTrack

# ------------------------------------------------------------------------------------------------- palette and layout constants
C_HI, C_OFF = (0.18, 0.55, 1.0), (1.0, 0.52, 0.08)          # Mr. Hi = blue, Officer = orange (belief spheres and true-faction rings)
C_NEUTRAL, C_GOLD, C_ALARM = (0.60, 0.64, 0.72), (1.0, 0.84, 0.2), (1.0, 0.15, 0.55)
C_PLATE, C_FRAME, C_GRID = (0.045, 0.06, 0.09), (0.22, 0.30, 0.44), (0.20, 0.26, 0.36)
C_TEXT, C_DIM = (0.88, 0.92, 0.97), (0.62, 0.70, 0.80)
C_MSG = (0.55, 0.92, 1.0)
FACTION_RGB = (C_HI, C_OFF)

PS = 14.5                                                    # panel size
PY0, PY1 = -22.0, -7.5                                       # panel front / back edge (y)
NX0, CX0, EX0 = -0.5, 15.0, 27.0                             # left edges of the network panel, the centre column, the embedding panel
CW = 11.0                                                    # centre column width
Z0 = 0.55                                                    # height of the node centres
R_CORE_N, R_MAX_N = 0.27, 0.50                               # network-panel sphere radii (core, full confidence)
R_CORE_E, R_MAX_E = 0.17, 0.32                               # embedding-panel sphere radii
STACK_DIST, STACK_STEP, STACK_MAX = 0.45, 0.55, 5               # members closer than this (plot units) are stacked upward by this step (at most STACK_MAX levels)
LOOP_PERIOD, LAYER_PHASE = 6.4, 3.2                          # message-passing loop (playback seconds): layer 1 then layer 2
SLOT_FRACTIONS = dict(ingest=0.06, validate=0.05, split=0.06, train=0.48, evaluate=0.08, register=0.05, serve=0.06, monitor=0.16)


# ------------------------------------------------------------------------------------------------- tracks
class PolyTrack:
    """Piecewise-linear location and/or scale through breakpoints (ts ascending). scales: floats (uniform) or 3-tuples; base multiplies them."""

    def __init__(self, ts, locs=None, scales=None, base=(1.0, 1.0, 1.0)):
        self.ts, self.locs, self.scales, self.base = ts, locs, scales, base

    def _lerp(self, seq, t):
        ts = self.ts
        i = tts.bisect.bisect_right(ts, t)
        if i <= 0:
            return seq[0]
        if i >= len(ts):
            return seq[-1]
        u = (t - ts[i - 1]) / (ts[i] - ts[i - 1]) if ts[i] > ts[i - 1] else 1.0
        a, b = seq[i - 1], seq[i]
        if isinstance(a, tuple):
            return tuple(a[k] + (b[k] - a[k]) * u for k in range(len(a)))
        return a + (b - a) * u

    def at(self, t):
        loc = self._lerp(self.locs, t) if self.locs is not None else None
        if self.scales is None:
            return loc, tuple(self.base)
        s = self._lerp(self.scales, t)
        s = (s, s, s) if not isinstance(s, tuple) else s
        return loc, tuple(max(self.base[k] * s[k], MIN_SCALE) for k in range(3))


def window_track(t0, t1, pos, dk, base=(1.0, 1.0, 1.0)):
    """Visible (scale 1) only inside [t0, t1]; hidden (tiny scale) otherwise. Used for subtitles and callouts."""
    return SegTrack([(t0, t1, pos, pos, 1.0, 1.0)], base=base, jump=dk)


# ------------------------------------------------------------------------------------------------- time slots (display time)
class Slots:
    """Display (playback) time: every pipeline stage gets a fixed slot of the loop; epochs are replayed at an even pace inside the train slot."""

    def __init__(self, stages, pb, epochs):
        self.pb, self.E = pb, epochs
        self.win, t = {}, 0.0
        for s in stages:
            k = s["stage_key"]
            w = SLOT_FRACTIONS[k] * pb
            self.win[k] = (t, t + w)
            t += w
        self.win[stages[-1]["stage_key"]] = (self.win[stages[-1]["stage_key"]][0], pb)
        self.t0, self.t1 = self.win["train"]

    def epoch_t(self, e):
        return self.t0 + (self.t1 - self.t0) * (e / self.E)

    def card_window(self, at):
        a, b = self.win[at["stage_from"]][0], self.win[at["stage_to"]][1]
        if "epoch_from" in at:
            a, b = self.epoch_t(at["epoch_from"]), self.epoch_t(at["epoch_to"])
        if "part" in at:
            lo, hi = at["part"]
            a, b = a + lo * (b - a), a + hi * (b - a)
        return a, b


def display_trace(tr, S, pb):
    """The trace as the GENERIC builder should see it: stage/flow times in playback seconds, no series gauges, no entity pillars."""
    d = copy.deepcopy(tr)
    d.pop("gnn", None)
    d["time"]["duration"] = pb
    for s in d["stages"]:
        s["start_s"], s["end_s"] = S.win[s["stage_key"]]
    ids = {s["id"]: s for s in d["stages"]}
    for f in d["flows"]:
        f["start_s"], f["end_s"] = ids[f["from"]]["end_s"], ids[f["to"]]["start_s"]
    d["series"] = {"t": [], "channels": {}}
    d["entities"] = []
    return d


def ribbon(points, width, z):
    """Flat band (in the XY plane at height z) along a polyline: (verts, faces)."""
    v, f = [], []
    n = len(points)
    for i, (x, y) in enumerate(points):
        a = points[max(i - 1, 0)]
        b = points[min(i + 1, n - 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / L * width / 2, dx / L * width / 2
        v += [(x + nx, y + ny, z), (x - nx, y - ny, z)]
    for i in range(n - 1):
        f.append((2 * i, 2 * i + 1, 2 * i + 3, 2 * i + 2))
    return v, f


# ------------------------------------------------------------------------------------------------- the model
class GnnModel(tts.Model):
    """Generic machine (stages, tubes, wall, ambient flow particles) + the graph module. Everything specific to the graph lives in _graph_*."""

    def __init__(self, trace, **cfg):
        cfg = dict(dict(n_frames=720, step=4, amb_total=28, amb_cap=4), **{k: v for k, v in cfg.items() if v is not None})
        self.gtr, self.G = trace, trace["gnn"]
        self.msg_loops = cfg.pop("msg_loops", 2)
        fps = int(cfg.get("fps", tts.DEFAULTS["fps"]))
        self.pb_play = (int(cfg["n_frames"]) - 1) / fps
        self.E = int(self.G["epochs"]["index"][-1])
        self.slots = Slots(trace["stages"], self.pb_play, self.E)
        self.gnn_mapping = []
        super().__init__(display_trace(trace, self.slots, self.pb_play), **cfg)
        # the generic layer headers (stage kinds under the blocks) repeat the large stage names and the strip: drop them
        self.items = [it for it in self.items if not (it["kind"] == "label" and it["mode"] == "flat" and abs(it["loc"][1] - (self.ymin_m - 1.3)) < 1e-6)]

    # ---- generic parts that are specialised
    def _stages(self):
        super()._stages()
        st = {s["id"]: s for s in self.gtr["stages"]}
        wmax = max(s["metrics"]["wall_ms"] for s in self.gtr["stages"])
        self.stage_rgb = {}
        for it in self.items:
            if it["kind"] == "block":
                rgb = tts.ramp(st[it["sid"]]["metrics"]["wall_ms"] / wmax)
                it["mat"]["rgb"] = rgb
                self.stage_rgb[it["sid"]] = rgb
                self.pos[it["sid"]]["rgb"] = rgb

    def mapping_lines(self):
        base = [l for l in super().mapping_lines() if not l.startswith("block colour") and not l.startswith("floor ruler")]
        return base + ["block colour = that stage's wall_ms / the slowest stage's (blue, amber, red); real wall-clock per stage is printed on the strip"] + self.gnn_mapping

    def _timeline(self):
        """Stage strip: one segment per stage, width = its playback slot, label = the REAL measured milliseconds, a result chip under it; cursor = playback position."""
        G, S, pb = self.G, self.slots, self.pb_play
        x0, x1 = -1.0, (len(self.layers) - 1) * self.dx + 1.0
        Wr, yt = x1 - x0, -4.9
        xs = lambda t: x0 + Wr * min(max(t / pb, 0.0), 1.0)
        prov = self.gtr["source"]["provenance"]
        ep = G["epochs"]
        chips = dict(ingest=lambda m: ["%d edges" % m["records_out"], "sha " + prov["dataset_sha256"][:8]],
                     validate=lambda m: ["%d/%d checks" % (m["checks_passed"], m["checks_run"]), "passed"],
                     split=lambda m: ["%d labelled" % m["labelled"], "%d unlabelled" % m["unlabelled"]],
                     train=lambda m: ["%d epochs, loss %.3g -> %.3g" % (m["epochs"], ep["loss_train"][0], ep["loss_train"][-1])],
                     evaluate=lambda m: ["%d/34 right" % m["correct"], "%d wrong" % m["wrong"]],
                     register=lambda m: ["weights", "sha " + prov["weights_sha256"][:8]],
                     serve=lambda m: ["hashes match", "%.3g ms" % m["latency_ms_p50"]],
                     monitor=lambda m: ["%d edges removed:" % self.G["monitor"]["k_removed"], "accuracy change %+.3f" % m["accuracy_change"]])
        self.add("plate", "STRIP_BASE", loc=((x0 + x1) / 2, yt - 0.4, 0.0), size=(Wr + 0.3, 2.2, 0.05), mat=dict(kind="pbr", rgb=C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        for s_ in self.gtr["stages"]:
            a, b = S.win[s_["stage_key"]]
            ms = s_["metrics"]["wall_ms"]
            xc = (xs(a) + xs(b)) / 2
            self.add("plate", "SEG_" + s_["id"], loc=(xc, yt, 0.06), size=(xs(b) - xs(a) - 0.12, 0.9, 0.08),
                     mat=dict(kind="pbr", rgb=self.stage_rgb[s_["id"]], alpha=1.0, rough=0.5, emit=0.35))
            self.label([s_["stage_key"]], (xc, yt + 0.14, 0.16), 0.36, (1, 1, 1), mode="flat")
            self.label(["%s ms" % tts.fmt_num(float("%.3g" % ms))], (xc, yt - 0.26, 0.16), 0.34, (1, 1, 0.8), mode="flat")
            self.label(chips[s_["stage_key"]](s_["metrics"]), (xc, yt - 0.8, 0.06), 0.29, (0.78, 0.86, 0.95), mode="flat", valign="top")
        self.caption = "playback %.0f s = %.0f ms of real run (%.0fx slower): every stage gets a fixed slot, epochs replay evenly" % (
            pb, self.gtr["time"]["duration"] * 1e3, pb / self.gtr["time"]["duration"])
        self.label([self.caption], (x0, yt - 1.75, 0.02), 0.3, (0.9, 0.9, 0.6), mode="flat", align="left")
        self.add("plate", "CURSOR", loc=(x0, yt, 0.2), size=(0.08, 1.4, 0.4), mat=dict(kind="emit", rgb=(1.0, 1.0, 0.6), alpha=1.0),
                 track=SegTrack([(-1.0, 0.0, (x0, yt, 0.2), (x0, yt, 0.2), 1.0, 1.0), (0.0, pb, (x0, yt, 0.2), (x1, yt, 0.2), 1.0, 1.0),
                                 (pb, pb + 10.0, (x1, yt, 0.2), (x1, yt, 0.2), 1.0, 1.0)], base=(0.08, 1.4, 0.4)))
        self.flat_banner_y = PY0 - 8.2
        self.grow(x0 - 1.0, yt - 2.2, x1 + 1.0, yt + 0.8)
        self.mapping.append("stage strip: segment width = its slot of the loop, text = real measured ms + result; cursor = playback time")

    def _bars(self):
        """Stage names (large, upright) above the blocks; this trace has no per-stage bar channels, so no gauges."""
        self.fam, self.gauges, self.bar_peak = {}, [], {}
        self.gauge_y = self.ymax_m + 2.4
        for s_ in self.tr["stages"]:
            p = self.pos[s_["id"]]
            self.label([s_["stage_key"].upper()], (p["x"], p["y"], p["sz"] + 0.9), 0.5, (1.0, 1.0, 1.0))

    def _graph_polish(self):
        """Floor with a faint grid (depth cues), subtitle backing plate and the colour key."""
        x0, x1, y0, y1 = -8.0, 50.0, PY0 - 12.0, 12.0
        self.add("plate", "FLOOR", loc=((x0 + x1) / 2, (y0 + y1) / 2, -0.1), size=(x1 - x0, y1 - y0, 0.04), mat=dict(kind="pbr", rgb=(0.016, 0.02, 0.032), alpha=1.0, rough=0.95, emit=0.0))
        grid = dict(kind="emit", rgb=(0.05, 0.065, 0.10), alpha=1.0)
        for gx in range(-5, 50, 5):
            self.add("plate", "GX%d" % (gx + 5), loc=(gx, (y0 + y1) / 2, -0.07), size=(0.03, y1 - y0, 0.01), mat=grid)
        for gy in range(int(y0) + 2, int(y1), 5):
            self.add("plate", "GY%d" % (gy + 40), loc=((x0 + x1) / 2, gy, -0.07), size=(x1 - x0, 0.03, 0.01), mat=grid)
        xc = (NX0 + EX0 + PS) / 2
        self.add("plate", "SUB_BG", loc=(xc, PY0 - 5.1, 0.0), size=(EX0 + PS - NX0 + 1.0, 4.0, 0.03), mat=dict(kind="pbr", rgb=(0.02, 0.028, 0.045), alpha=0.92, rough=0.9, emit=0.0))
        yk, xk = PY0 - 0.85, CX0 + 0.4
        for lab, rgb, w in (("Mr. Hi", C_HI, 1.55), ("Officer", C_OFF, 1.7), ("undecided", C_NEUTRAL, 2.1)):
            self.add("sphere", "KEY_" + lab[:3], loc=(xk + 0.15, yk, 0.25), size=(0.17,) * 3, mat=dict(kind="pbr", rgb=rgb, alpha=1.0, rough=0.3, emit=0.38))
            self.label([lab], (xk + 0.42, yk, 0.03), 0.3, C_TEXT, mode="flat", align="left")
            xk += w + 0.35
        self.add("ring2", "KEY_RING", loc=(xk + 0.2, yk, 0.06), size=(0.28, 0.28, 1.0), mat=dict(kind="emit", rgb=C_TEXT, alpha=1.0))
        self.label(["ring = truth"], (xk + 0.62, yk, 0.03), 0.3, C_TEXT, mode="flat", align="left")

    def _rig(self):
        super()._rig()                                          # lights + world colour; cameras are replaced below
        x0, y0, x1, y1 = self.bb
        Hh = self.wall["H"]
        cx = (x0 + x1) / 2

        def cam(name, desc, tgt, el, fov, pts):
            e = math.radians(el)
            dv = (0.0, -math.cos(e), math.sin(e))
            d = self._fit(tgt, dv, pts, fov, margin=0.97)
            return dict(name=name, desc=desc, loc=tuple(tgt[i] + dv[i] * d for i in range(3)), target=tgt, fov=fov)

        def box(xa, xb, ya, yb, zs=(0.0, 3.0)):
            return [(x, y, z) for x in (xa, xb) for y in (ya, yb) for z in zs]
        gy = (PY0 + PY1) / 2
        ya = self.flat_banner_y - 0.8
        self.cams = [
            cam("VP1_Demo", "Demo: stage strip, friendship network, training curves, embedding space, subtitles", (cx, (ya + 2.0) / 2, 0.5), 47.0, 50.0, box(x0, x1, ya, 2.5, (0.0, 4.5))),
            cam("VP2_Overview", "Overview: everything including the title wall", (cx, (y0 + y1) / 2, 1.5), 40.0, 50.0, box(x0, x1, y0, y1, (0.0, Hh))),
            cam("VP3_Graphs", "Graphs: friendship network, training curves, embedding space", (cx, gy - 0.5, 0.0), 58.0, 50.0, box(NX0 - 0.5, EX0 + PS + 0.5, PY0 - 3.5, PY1 + 0.5)),
            cam("VP4_Network", "Close-up: friendship network (belief colour vs true ring, messages)", (NX0 + PS / 2, gy, 0.0), 62.0, 50.0, box(NX0, NX0 + PS, PY0 - 0.5, PY1 + 0.5)),
            cam("VP5_Embedding", "Close-up: embedding space (the 2 hidden units)", (EX0 + PS / 2, gy, 0.0), 62.0, 50.0, box(EX0, EX0 + PS, PY0 - 0.5, PY1 + 0.5)),
            cam("VP6_Pipeline", "Close-up: MLOps stage strip with real timings and results", (cx, -2.0, 0.5), 36.0, 50.0, box(x0, x1, -8.0, 2.0, (0.0, 4.0))),
            cam("VP8_Wall", "Close-up: title wall (legend, mapping, caveats)", (cx, self.wall["y"], Hh / 2), 6.0, 50.0, box(x0, x1, self.wall["y"] - 0.2, self.wall["y"] + 0.2, (0.0, Hh))),
            cam("VP7_Top", "Top view of everything", (cx, (y0 + y1) / 2, 0.0), 89.0, 55.0, [(x, y, 0.0) for x in (x0, x1) for y in (y0, y1)]),
        ]

    def _entities(self):
        self.ents, self.ent_end_y = [], 0.0
        self._graph_setup()
        self._graph_polish()
        self._graph_frames()
        self._graph_network()
        self._graph_embedding()
        self._graph_plots()
        self._graph_messages()
        self._graph_leaders_and_alarms()
        self._graph_pipeline_glow()
        self._graph_subtitles()
        self._graph_legend()

    def _graph_setup(self):
        G, S = self.G, self.slots
        self.nodes = G["nodes"]
        self.N = len(self.nodes)
        self.ep = G["epochs"]["index"]
        self.te = [S.epoch_t(e) for e in self.ep]
        ents = {e["id"]: e for e in self.gtr["entities"]}
        self.ex = [ents["m%d" % n["id"]]["series"]["x"] for n in self.nodes]
        self.ey = [ents["m%d" % n["id"]]["series"]["y"] for n in self.nodes]
        self.pp = [ents["m%d" % n["id"]]["series"]["p_officer"] for n in self.nodes]
        self.tau = G["thresholds"]["undecided_margin"]
        self.AM = math.ceil(G["emb_axis_max"] * 10) / 10.0                 # embedding frame: 0 .. max activation rounded up to 0.1
        self.netc = (NX0 + PS / 2, (PY0 + PY1) / 2)
        self.embo = (EX0 + 1.3, PY0 + 1.3)
        self.embP = PS - 2.6
        self.leaders = [n["id"] - 1 for n in self.nodes if n["labelled"]]
        self.wrong = [w["member"] - 1 for w in G["final"]["wrong"]]
        self.pos_net = [(self.netc[0] + 6.3 * n["layout"][0], self.netc[1] - 0.5 + 5.6 * n["layout"][1]) for n in self.nodes]      # a header band at the back edge stays free for captions

    def _plate(self, name, cx, cy, w, h, rgb=C_PLATE, z=0.0, th=0.06, emit=0.0, alpha=1.0):
        return self.add("plate", name, loc=(cx, cy, z), size=(w, h, th), mat=dict(kind="pbr", rgb=rgb, alpha=alpha, rough=0.9, emit=emit))

    def _frame(self, tag, x0, y0, w, h):
        e = 0.07
        for nm, (cx, cy, sw, sh) in dict(a=(x0 + w / 2, y0, w, e), b=(x0 + w / 2, y0 + h, w, e), c=(x0, y0 + h / 2, e, h), d=(x0 + w, y0 + h / 2, e, h)).items():
            self._plate("%s_FR%s" % (tag, nm), cx, cy, sw, sh, C_FRAME, z=0.05, th=0.06, emit=0.5)

    def _graph_frames(self):
        gy = (PY0 + PY1) / 2
        for tag, x0 in (("NET", NX0), ("EMB", EX0)):
            self._plate(tag + "_PL", x0 + PS / 2, gy, PS, PS, th=0.08, z=-0.02)
            self._frame(tag, x0, PY0, PS, PS)
        self._plate("COL_PL", CX0 + CW / 2, gy, CW, PS, th=0.08, z=-0.02, rgb=(0.04, 0.052, 0.08))
        self._frame("COL", CX0, PY0, CW, PS)
        self.label(["1 · THE FRIENDSHIP NETWORK"], (NX0 + PS / 2, PY0 - 0.8, 0.02), 0.6, C_TEXT, mode="flat")
        self.label(["fixed display layout · inner colour = what the model believes · ring = the truth"], (NX0 + PS / 2, PY0 - 1.55, 0.02), 0.3, C_DIM, mode="flat")
        self.label(["2 · EMBEDDING SPACE = the model's 2 hidden units"], (EX0 + PS / 2, PY0 - 0.8, 0.02), 0.6, C_TEXT, mode="flat")
        self.label(["each member moves to where the network puts it after every epoch (no projection)"], (EX0 + PS / 2, PY0 - 1.55, 0.02), 0.3, C_DIM, mode="flat")
        self.grow(NX0 - 0.5, PY0 - 2.2, EX0 + PS + 0.5, PY1 + 0.5)
        self.gnn_mapping += [
            "network panel: friendships (display-only force layout); edge thickness = A-hat weight, how much of a friend's message gets through",
            "sphere colour = the model's guess now (blue Mr. Hi, orange Officer, grey = undecided: |P-0.5| < %.2f); radius = confidence; outer ring = the TRUE faction" % self.G["thresholds"]["undecided_margin"],
        ]

    # ---- network panel
    def _graph_network(self):
        G, tau = self.G, self.tau
        W = [e[2] for e in G["edges"]]
        wmin, wmax = min(W), max(W)
        for a, b, w in G["edges"]:
            pa, pb_ = self.pos_net[a - 1], self.pos_net[b - 1]
            self.add("tube", "E%d_%d" % (a, b), p0=(pa[0], pa[1], Z0), p1=(pb_[0], pb_[1], Z0), r=0.03 + 0.07 * (w - wmin) / (wmax - wmin),
                     mat=dict(kind="pbr", rgb=(0.42, 0.52, 0.68), alpha=0.55, rough=0.3, emit=0.0))
        for i, nd in enumerate(self.nodes):
            x, y = self.pos_net[i]
            n = nd["id"]
            self.add("sphere", "nC%d" % n, loc=(x, y, Z0), size=(R_CORE_N,) * 3, mat=dict(kind="pbr", rgb=C_NEUTRAL, alpha=1.0, rough=0.5, emit=0.25))
            for c, rgb in enumerate(FACTION_RGB):
                rad = [self._belief_r(self.pp[i][k], c, R_CORE_N * 1.05, R_MAX_N) for k in range(len(self.ep))]
                self.add("sphere", "n%s%d" % ("AB"[c], n), loc=(x, y, Z0), size=(1, 1, 1), mat=dict(kind="pbr", rgb=rgb, alpha=1.0, rough=0.3, emit=0.38),
                         track=PolyTrack(self.te, None, rad, base=(1, 1, 1)))
            self.add("ring2", "nR%d" % n, loc=(x, y, 0.07), size=(0.72, 0.72, 1.0), mat=dict(kind="emit", rgb=FACTION_RGB[nd["faction"]], alpha=1.0))
            self.label(["%d" % n], (x, y, Z0 + 0.8), 0.32, (1, 1, 1), mode="billboard")

    def _belief_r(self, p, c, r0, r1):
        m = abs(p - 0.5)
        if (1 if p > 0.5 else 0) != c or m < self.tau:
            return 0.0
        return r0 + (r1 - r0) * min(1.0, (m - self.tau) / (0.5 - self.tau))

    # ---- embedding panel
    def _emb_xy(self, ex, ey):
        return (self.embo[0] + ex / self.AM * self.embP, self.embo[1] + ey / self.AM * self.embP)

    def _graph_embedding(self):
        ox, oy, P = self.embo[0], self.embo[1], self.embP
        self.add("plate", "EMB_AX1", loc=(ox + P / 2, oy, 0.07), size=(P, 0.1, 0.06), mat=dict(kind="pbr", rgb=C_HI, alpha=1.0, rough=0.5, emit=0.6))
        self.add("plate", "EMB_AX2", loc=(ox, oy + P / 2, 0.07), size=(0.1, P, 0.06), mat=dict(kind="pbr", rgb=C_OFF, alpha=1.0, rough=0.5, emit=0.6))
        for v in (0.5, 1.0):
            if v <= self.AM:
                x, y = ox + v / self.AM * P, oy + v / self.AM * P
                self.add("plate", "EMB_TX%d" % round(v * 10), loc=(x, oy, 0.07), size=(0.05, 0.4, 0.05), mat=dict(kind="pbr", rgb=C_GRID, alpha=1.0, rough=0.5, emit=0.4))
                self.add("plate", "EMB_TY%d" % round(v * 10), loc=(ox, y, 0.07), size=(0.4, 0.05, 0.05), mat=dict(kind="pbr", rgb=C_GRID, alpha=1.0, rough=0.5, emit=0.4))
                self.label(["%g" % v], (x, oy - 0.5, 0.03), 0.3, C_DIM, mode="flat")
                self.label(["%g" % v], (ox - 0.4, y, 0.03), 0.3, C_DIM, mode="flat", align="right")
        self.label(["hidden unit 1 (activation)"], (ox + P, oy - 1.0, 0.03), 0.32, C_HI, mode="flat", align="right")
        self.label(["hidden unit 2 (activation)"], (ox - 1.0, oy + P + 0.35, 0.03), 0.32, C_OFF, mode="flat", align="left")
        n_pts = len(self.ep)
        anchors = []
        for i, nd in enumerate(self.nodes):
            pts = [self._emb_xy(self.ex[i][k], self.ey[i][k]) for k in range(n_pts)]
            a = self.add("anchor", "eP%d" % nd["id"], loc=(pts[0][0], pts[0][1], Z0))
            a["_pts"] = pts
            anchors.append(a)
        # vertical stacking of coincident members, per epoch (display only): level = number of lower-numbered members closer than STACK_DIST (capped)
        for k in range(n_pts):
            for i in range(self.N):
                pi = anchors[i]["_pts"][k]
                lvl = sum(1 for j in range(i) if math.hypot(pi[0] - anchors[j]["_pts"][k][0], pi[1] - anchors[j]["_pts"][k][1]) < STACK_DIST)
                anchors[i].setdefault("_locs", []).append((pi[0], pi[1], Z0 + STACK_STEP * min(lvl, STACK_MAX)))
        for i, a in enumerate(anchors):
            locs = a.pop("_locs")
            zs = [l[2] for l in locs]
            sm = [sum(zs[max(0, k - 3):k + 4]) / len(zs[max(0, k - 3):k + 4]) for k in range(len(zs))]        # stack height smoothed over +-3 epochs (no flicker)
            locs = [(l[0], l[1], z) for l, z in zip(locs, sm)]
            a["track"] = PolyTrack(self.te, locs, None)
            a["loc"] = a["track"].locs[0]
            a.pop("_pts")
            n, nd = self.nodes[i]["id"], self.nodes[i]
            self.add("sphere", "eC%d" % n, parent=a["name"], loc=(0, 0, 0), size=(R_CORE_E,) * 3, mat=dict(kind="pbr", rgb=C_NEUTRAL, alpha=1.0, rough=0.5, emit=0.25))
            for c, rgb in enumerate(FACTION_RGB):
                rad = [self._belief_r(self.pp[i][k], c, R_CORE_E * 1.05, R_MAX_E) for k in range(n_pts)]
                self.add("sphere", "e%s%d" % ("AB"[c], n), parent=a["name"], loc=(0, 0, 0), size=(1, 1, 1),
                         mat=dict(kind="pbr", rgb=rgb, alpha=1.0, rough=0.3, emit=0.38), track=PolyTrack(self.te, None, rad, base=(1, 1, 1)))
            self.add("ring2", "eR%d" % n, parent=a["name"], loc=(0, 0, -Z0 + 0.07), size=(0.5, 0.5, 1.0), mat=dict(kind="emit", rgb=FACTION_RGB[nd["faction"]], alpha=1.0))
        self.gnn_mapping += [
            "embedding panel: position = the 2 hidden-unit activations after each epoch (axes 0..%g, no projection); members on the same spot stack upward (height only, smoothed over 7 epochs)" % self.AM,
            "axis colours: unit 1 ends up firing for Mr. Hi's members, unit 2 for the Officer's (learned, not designed)",
        ]

    def _graph_plots(self):
        G, S = self.G, self.slots
        ep, beats = G["epochs"], G["beats"]
        x0, w, h = CX0 + 1.3, CW - 2.0, 2.1
        specs = [("LOSS", "cross-entropy loss", PY1 - 5.8, 0.7, [("loss_train", (1.0, 0.82, 0.25), "gold: training loss (the 2 labelled members)"),
                                                                 ("loss_all34", (0.75, 0.55, 1.0), "violet: loss over all 34 (never trained on)")], (0.2, 0.4, 0.6),
                  [(beats["e_loss_lt_0_1"], "loss<0.1"), (beats["e_loss_lt_0_03"], "loss<0.03")]),
                 ("ACC", "accuracy over all 34 members", PY1 - 11.2, 1.0, [("accuracy_all34", (0.35, 0.95, 0.55), "green: share of members guessed right")], (0.5, 1.0),
                  [(beats["e_accuracy_settled"], "settles")])]
        for tag, title, ytop, ymax, curves, ticks, marks in specs:
            y0 = ytop - h
            self.label([title], (CX0 + CW / 2, ytop + 1.45, 0.03), 0.42, C_TEXT, mode="flat")
            for ci, (key, rgb, desc) in enumerate(curves):
                self.label([desc], (x0 - 0.9, ytop + 0.85 - 0.38 * ci, 0.04), 0.26, rgb, mode="flat", align="left")
            self._plate(tag + "_BG", x0 + w / 2, y0 + h / 2, w, h, rgb=(0.03, 0.04, 0.065), z=0.0, th=0.05)
            self.add("plate", tag + "_AXX", loc=(x0 + w / 2, y0, 0.06), size=(w, 0.07, 0.05), mat=dict(kind="pbr", rgb=C_DIM, alpha=1.0, rough=0.5, emit=0.4))
            self.add("plate", tag + "_AXY", loc=(x0, y0 + h / 2, 0.06), size=(0.07, h, 0.05), mat=dict(kind="pbr", rgb=C_DIM, alpha=1.0, rough=0.5, emit=0.4))
            for tv in ticks:
                ty = y0 + tv / ymax * h
                self.add("plate", "%s_TK%d" % (tag, round(tv * 10)), loc=(x0 + w / 2, ty, 0.05), size=(w, 0.025, 0.04), mat=dict(kind="pbr", rgb=C_GRID, alpha=1.0, rough=0.5, emit=0.3))
                self.label(["%g" % tv], (x0 - 0.2, ty, 0.03), 0.28, C_DIM, mode="flat", align="right")
            for ex_ in (0, 100, 200):
                if ex_ <= self.E:
                    self.label(["%d" % ex_], (x0 + ex_ / self.E * w, y0 - 0.4, 0.03), 0.28, C_DIM, mode="flat")
            self.label(["epoch"], (x0 + w + 0.1, y0 - 0.4, 0.03), 0.24, C_DIM, mode="flat", align="left")
            for me, txt in marks:                                   # milestones derived from the run (gnn.beats)
                mx = x0 + me / self.E * w
                my = y0 + min(ep[curves[0][0]][me], ymax) / ymax * h                           # a ring flashes on the curve at the real epoch of the milestone
                tm = S.epoch_t(me)
                self.add("ring", "%s_MP%d" % (tag, me), track=SegTrack([(tm, tm + 1.4, (mx, my, 0.12), (mx, my, 0.12), 0.25, 0.9)], base=(1.0, 1.0, 1.0), jump=self.dk),
                         mat=dict(kind="emit", rgb=(1.0, 1.0, 0.7), alpha=1.0))
                self.add("plate", "%s_MS%d" % (tag, me), loc=(mx, y0 + h / 2, 0.06), size=(0.04, h, 0.04), mat=dict(kind="pbr", rgb=(1.0, 1.0, 0.7), alpha=0.7, rough=0.5, emit=0.6))
                self.label(["%d: %s" % (me, txt)], (mx, y0 - 0.85, 0.03), 0.22, (1.0, 1.0, 0.7), mode="flat")
            for ci, (key, rgb, desc) in enumerate(curves):
                vals = ep[key]
                pts = [(x0 + e / self.E * w, y0 + min(v, ymax) / ymax * h) for e, v in zip(ep["index"], vals)]
                sub = pts[::2] + ([pts[-1]] if (len(pts) - 1) % 2 else [])
                v_, f_ = ribbon(sub, 0.13, 0.08 + 0.01 * ci)
                self.add("mesh", "%s_C%d" % (tag, ci), verts=v_, faces=f_, mat=dict(kind="emit", rgb=tuple(0.6 * c for c in rgb), alpha=1.0))
                self.add("sphere", "%s_M%d" % (tag, ci), loc=(pts[0][0], pts[0][1], 0.25), size=(0.24,) * 3, mat=dict(kind="pbr", rgb=rgb, alpha=1.0, rough=0.4, emit=0.9),
                         track=PolyTrack(self.te, [(p[0], p[1], 0.25) for p in pts], None, base=(0.24,) * 3))
        self.gnn_mapping += ["curves: training loss, loss over all 34 (never trained on), accuracy over all 34; markers = current epoch; thin lines = run milestones"]
        # epoch progress bar under the embedding panel
        bx0, bw, by = EX0, PS, PY0 - 2.35
        self.add("plate", "EPB_BG", loc=(bx0 + bw / 2, by, 0.03), size=(bw, 0.34, 0.05), mat=dict(kind="pbr", rgb=C_PLATE, alpha=1.0, rough=0.9, emit=0.0))
        t0, t1 = S.t0, S.t1
        self.add("plate", "EPB", loc=(bx0, by, 0.08), size=(MIN_SCALE, 0.28, 0.06), mat=dict(kind="emit", rgb=(1.0, 1.0, 0.6), alpha=1.0),
                 track=PolyTrack([t0 - 1.0, t0, t1, t1 + 1.0], [(bx0, by, 0.08), (bx0, by, 0.08), (bx0 + bw / 2, by, 0.08), (bx0 + bw / 2, by, 0.08)],
                                 [(MIN_SCALE, 1, 1), (MIN_SCALE, 1, 1), (bw, 1, 1), (bw, 1, 1)], base=(1.0, 0.28, 0.06)))
        self.label(["epoch 0"], (bx0, by - 0.6, 0.03), 0.28, C_DIM, mode="flat", align="left")
        self.label(["epoch %d" % self.E], (bx0 + bw, by - 0.6, 0.03), 0.28, C_DIM, mode="flat", align="right")
        # correctness pips under the network panel: one green and one red dot per member, shown according to the guess in that epoch
        px0, pw = NX0 + 0.5, PS - 1.0
        for i, nd in enumerate(self.nodes):
            x = px0 + pw * i / (self.N - 1)
            ok = [((1 if p > 0.5 else 0) == nd["faction"]) for p in self.pp[i]]
            for good, rgb, tg in ((True, (0.3, 0.95, 0.45), "G"), (False, (1.0, 0.2, 0.25), "R")):
                self.add("particle", "pip%s%d" % (tg, nd["id"]), loc=(x, by, 0.2), size=(1, 1, 1), mat=dict(kind="emit", rgb=rgb, alpha=1.0),
                         track=PolyTrack(self.te, None, [0.15 if o == good else 0.0 for o in ok], base=(1, 1, 1)))
        self.label(["each member's guess now: green = right, red = wrong (members 1-34)"], (NX0 + PS / 2, by - 0.6, 0.03), 0.3, C_DIM, mode="flat")
        self.grow(NX0 - 0.5, by - 1.2, bx0 + bw + 0.5, by + 0.5)
        self.gnn_mapping.append("pips: one per member, green = guessed right this epoch, red = wrong (accuracy = the green share)")

    def _graph_messages(self):
        """One particle per friendship and direction, bouncing: layer 1 it travels a->b, layer 2 b->a (its twin does the opposite), parking INSIDE the
        node spheres in between. So no hide/show tracks are needed: only positions, plus a size step (small = layer 1, large = layer 2) while parked."""
        S, G = self.slots, self.G
        T_TRAV, PAD = 2.2, 0.35
        k_total = 0
        for a, b, w in G["edges"]:
            pa, pb_ = self.pos_net[a - 1], self.pos_net[b - 1]
            dx, dy = pb_[0] - pa[0], pb_[1] - pa[1]
            L = math.hypot(dx, dy) or 1.0
            for first in (0, 1):
                lane = 0.08 * (1 if first == 0 else -1)
                off = (-dy / L * lane, dx / L * lane)
                pt = lambda p: (p[0] + off[0], p[1] + off[1], Z0)
                src, dst = (pa, pb_) if first == 0 else (pb_, pa)
                ts, locs, scs = [0.0], [pt(src)], [1.0]
                for loop in range(self.msg_loops):
                    for layer in (0, 1):
                        t = S.t0 + loop * LOOP_PERIOD + layer * LAYER_PHASE + PAD
                        if t + T_TRAV > S.t1 + 0.01:
                            continue
                        size = 1.0 if layer == 0 else 1.45
                        ts += [t, t + T_TRAV]
                        locs += [pt(src), pt(dst)]
                        scs += [size, size]
                        src, dst = dst, src
                ts.append(S.pb)
                locs.append(locs[-1])
                scs.append(scs[-1])
                k_total += 1
                self.add("particle", "M%d_%d_%d" % (a, b, first), track=PolyTrack(ts, locs, scs, base=(0.13, 0.13, 0.13)), mat=dict(kind="emit", rgb=C_MSG, alpha=1.0), group="msg")
        self.stats["msg_particles"] = k_total
        # layer captions on the network panel (visible while that layer's particles fly)
        cap = [("LAYER 1 · every member gathers its friends' vectors", 0), ("LAYER 2 · gathers again, then votes: Mr. Hi or Officer?", 1)]
        for text, layer in cap:
            lab = self.label([text], (NX0 + PS / 2, PY1 - 0.7, 0.03), 0.4, (0.7, 0.95, 1.0) if layer == 0 else (1.0, 0.9, 0.5), mode="flat")
            segs = []
            for loop in range(self.msg_loops):
                t = S.t0 + loop * LOOP_PERIOD + layer * LAYER_PHASE + PAD
                if t + T_TRAV <= S.t1 + 0.01:
                    segs.append((t, t + T_TRAV, lab["loc"], lab["loc"], 1.0, 1.0))
            lab["track"] = SegTrack(segs, base=(1, 1, 1), jump=self.dk)
        self.gnn_mapping += ["particles: one per friendship and direction, small = layer 1, large = layer 2, %d slow loops of %.1f s; the self-share (A+I) is not drawn" % (self.msg_loops, LOOP_PERIOD)]

    def _graph_leaders_and_alarms(self):
        S, dk = self.slots, self.dk
        for i in self.leaders:
            n = self.nodes[i]["id"]
            rgb = C_GOLD
            x, y = self.pos_net[i]
            self.add("ring2", "nL%d" % n, loc=(x, y, 0.09), size=(1.15, 1.15, 1.0), mat=dict(kind="emit", rgb=rgb, alpha=1.0))
            self.add("bar", "nBeam%d" % n, loc=(x, y, 0.0), size=(0.09, 0.09, 4.2), mat=dict(kind="emit", rgb=rgb, alpha=0.55))
            self.label(["MR. HI (1)" if i == 0 else "THE OFFICER (34)"], (x, y, 4.3), 0.5, rgb, mode="billboard")
            # sonar pulses from the labelled leaders while training runs
            segs, t = [], S.t0 + 0.2 + (0.0 if i == 0 else 0.8)
            while t + 1.6 <= S.t1:
                segs.append((t, t + 1.6, (x, y, 0.1), (x, y, 0.1), 0.7, 3.4))
                t += 2.4
            if segs:
                self.add("ring", "nS%d" % n, track=SegTrack(segs, base=(1.0, 1.0, 1.0), jump=dk), mat=dict(kind="emit", rgb=rgb, alpha=1.0))
            a = "eP%d" % n
            self.add("ring2", "eL%d" % n, parent=a, loc=(0, 0, -Z0 + 0.09), size=(0.75, 0.75, 1.0), mat=dict(kind="emit", rgb=rgb, alpha=1.0))
            self.add("bar", "eBeam%d" % n, parent=a, loc=(0, 0, 0), size=(0.07, 0.07, 3.0), mat=dict(kind="emit", rgb=rgb, alpha=0.55))
        t_ev0, t_ev1 = S.win["evaluate"][0], S.pb
        for i in self.wrong:
            n = self.nodes[i]["id"]
            w = next(w for w in self.G["final"]["wrong"] if w["member"] == n)
            x, y = self.pos_net[i]
            segs, t = [], t_ev0
            while t + 1.2 <= t_ev1 - 0.1:
                segs.append((t, t + 1.2, (x, y, 0.12), (x, y, 0.12), 0.8, 2.6))
                t += 1.4
            self.add("ring", "nW%d" % n, track=SegTrack(segs, base=(1.0, 1.0, 1.0), jump=dk), mat=dict(kind="emit", rgb=C_ALARM, alpha=1.0))
            ex, ey = self._emb_xy(self.ex[i][-1], self.ey[i][-1])
            segs2, t = [], t_ev0
            while t + 1.2 <= t_ev1 - 0.1:
                segs2.append((t, t + 1.2, (ex, ey, 0.12), (ex, ey, 0.12), 0.8, 2.2))
                t += 1.4
            self.add("ring", "eW%d" % n, track=SegTrack(segs2, base=(1.0, 1.0, 1.0), jump=dk), mat=dict(kind="emit", rgb=C_ALARM, alpha=1.0))
            lines = ["member %d: the model says %s," % (n, ["Mr. Hi", "Officer"][w["predicted"]]), "the truth is %s" % ["Mr. Hi", "Officer"][w["true"]]]
            lab = self.label(["member %d: the model says %s, the truth is %s" % (n, ["Mr. Hi", "Officer"][w["predicted"]], ["Mr. Hi", "Officer"][w["true"]])],
                             (self.netc[0], PY1 - 0.95, 0.03), 0.38, C_ALARM, mode="flat")           # network panel: caption in the free header band
            lab["track"] = window_track(t_ev0, t_ev1, lab["loc"], dk)
            lab = self.label(lines, (ex + 2.6, ey + 1.2, 1.6), 0.36, C_ALARM, mode="billboard")                    # embedding panel: callout at the point
            lab["track"] = window_track(t_ev0, t_ev1, lab["loc"], dk)
        for i in self.wrong:                                         # the wrong member's friendships glow magenta: who his friends are is the whole explanation
            n = self.nodes[i]["id"]
            for a, b, w in self.G["edges"]:
                if n in (a, b):
                    pa, pb_ = self.pos_net[a - 1], self.pos_net[b - 1]
                    L = math.hypot(pb_[0] - pa[0], pb_[1] - pa[1])
                    p0 = (pa[0], pa[1], Z0)
                    self.add("tube", "EW%d_%d" % (a, b), p0=p0, p1=(pb_[0], pb_[1], Z0), r=0.1, mat=dict(kind="emit", rgb=C_ALARM, alpha=1.0),
                             track=window_track(t_ev0, t_ev1, p0, dk, base=(L, 0.1, 0.1)))
        self.gnn_mapping += ["gold ring + beam + pulses = the 2 labelled members; magenta pulses and friendships = a member the model gets wrong at the end and his friends"]

    # ---- pipeline stage glow
    def _graph_pipeline_glow(self):
        """Stage pad: a bright floor pad under the stage that is running in its slot."""
        S, dk = self.slots, self.dk
        for s_ in self.gtr["stages"]:
            p = self.pos[s_["id"]]
            a, b = S.win[s_["stage_key"]]
            size = (p["sx"] + 1.5, p["sy"] + 1.5, 0.05)
            loc = (p["x"], p["y"], 0.03)
            self.add("plate", "PAD_" + s_["id"], loc=loc, size=size, mat=dict(kind="emit", rgb=(0.3, 0.85, 1.0), alpha=1.0), track=window_track(a, b - dk, loc, dk, base=size))
        self.gnn_mapping.append("bright floor pad = the pipeline stage that is running in this slot of the loop")

    def _graph_subtitles(self):
        S, dk = self.slots, self.dk
        xc = (NX0 + EX0 + PS) / 2
        yh = PY0 - 4.55
        cards = self.G["insights"]
        for idx, c in enumerate(cards):
            a, b = S.card_window(c["at"])
            b -= dk                                                  # one key interval of gap so that two cards are never visible together
            xd, yd = xc + (idx - (len(cards) - 1) / 2) * 0.6, yh + 0.95                 # card index dots: dim = all cards, bright = the card playing now
            self.add("particle", "cd%d" % idx, loc=(xd, yd, 0.1), size=(0.1,) * 3, mat=dict(kind="emit", rgb=(0.3, 0.36, 0.48), alpha=1.0))
            self.add("particle", "ca%d" % idx, loc=(xd, yd, 0.12), size=(0.17,) * 3, mat=dict(kind="emit", rgb=(1.0, 1.0, 0.6), alpha=1.0),
                     track=window_track(a, b, (xd, yd, 0.12), dk, base=(0.17,) * 3))
            hl = self.label([c["title"]], (xc, yh, 0.03), 0.78, (1.0, 1.0, 1.0), mode="flat")
            hl["track"] = window_track(a, b, hl["loc"], dk)
            det = tts.wrap(c["text"], self.cap_chars(EX0 + PS - NX0 - 2.0, 0.46))
            dl = self.label(det[:3], (xc, yh - 0.75, 0.03), 0.46, (0.80, 0.90, 1.0), mode="flat", align="center", valign="top")
            dl["track"] = window_track(a, b, dl["loc"], dk)
        self.grow(NX0 - 0.5, yh - 2.9, EX0 + PS + 0.5, yh + 0.8)
        self.gnn_mapping.append("subtitles: insight cards timed to the stage slots and epochs; every number comes from the trace (gnn.insights)")

    def _graph_legend(self):
        lines = ["WHAT IS A GNN MESSAGE PASS?",
                 "1. Every member sends its current vector to its friends and keeps a share for itself.",
                 "2. Every member averages what arrives (fixed weights, nearby members count more) and squeezes it through a small learned filter.",
                 "3. Do it twice and a member knows its friends of friends: that is how 2 labelled leaders can colour all 34."]
        out = []
        for i, ln in enumerate(lines):
            out += tts.wrap(ln, self.cap_chars(CW - 0.8, 0.33)) if i else [ln]
        self.label(out, (CX0 + 0.4, PY1 - 0.5, 0.04), 0.33, (0.75, 0.95, 0.8), mode="flat", align="left", valign="top")


# ------------------------------------------------------------------------------------------------- the Blender side
def _geos():
    return dict(block=("box_base", tts._mesh_box_base), bar=("box_base", tts._mesh_box_base), plate=("box_center", tts._mesh_box_center),
                tube=("cyl_x", tts._mesh_cyl_x), particle=("ico1", lambda: tts._mesh_ico(1)), ring=("torus", tts._mesh_torus),
                sphere=("ico3", lambda: tts._mesh_ico(3)), ring2=("torus_t", lambda: tts._mesh_torus(1.0, 0.07, 36, 6)))


def build_gnn(trace_path, live=True, **cfg):
    if bpy is None:
        raise RuntimeError("build_gnn() needs Blender (bpy)")
    trace = json.load(open(trace_path))
    tag = re.sub(r"\W", "_", os.path.basename(trace_path).split(".trace")[0])[:24]
    return build_gnn_from_trace(trace, tag, live=live, **cfg)


def build_gnn_from_trace(trace, tag, live=True, model_cls=None, **cfg):
    model = (model_cls or GnnModel)(trace, **cfg)
    scene = bpy.data.scenes.new(tag)
    m = tts.Machine(model, scene, tag)
    m.created.append(("scenes", scene))
    coll = bpy.data.collections.new(tag + "_machine")
    m.created.append(("collections", coll))
    scene.collection.children.link(coll)
    scene.frame_start, scene.frame_end, scene.frame_current = 1, model.nf, 1
    scene.render.fps, scene.render.fps_base = model.fps, 1.0
    scene.render.resolution_x, scene.render.resolution_y = 1280, 720
    scene["x3d_trace_run"] = trace["source"].get("run_id", tag)
    scene["x3d_trace_synthetic"] = bool(model.syn)
    world = bpy.data.worlds.new(tag + "_world")
    m.created.append(("worlds", world))
    world.color = model.world_rgb
    if world.node_tree:
        for n in world.node_tree.nodes:
            if n.type == "BACKGROUND":
                n.inputs["Color"].default_value = tuple(model.world_rgb) + (1.0,)
                n.inputs["Strength"].default_value = 1.0
    scene.world = world
    meshes, geos, objs = {}, _geos(), {}

    def mesh(name, geo):
        if name not in meshes:
            me = bpy.data.meshes.new("%s_%s" % (tag, name))
            v, f = geo()
            me.from_pydata(v, [], f)
            me.update()
            me.materials.append(None)
            meshes[name] = me
            m.created.append(("meshes", me))
        return meshes[name]

    def new_obj(name, data):
        o = bpy.data.objects.new(name, data)
        coll.objects.link(o)
        m.created.append(("objects", o))
        objs[name] = o
        return o
    for it in model.items:
        k = it["kind"]
        if k == "label":
            tts._make_label(m, it, new_obj)
            if it.get("track") is not None:
                for nm in (it["name"], it["name"] + "_f"):
                    m.anim.append((objs[nm], it["track"]))
            continue
        if k == "anchor":
            o = new_obj(it["name"], None)
            o.empty_display_type, o.empty_display_size = "PLAIN_AXES", 0.05
            o.location = it["loc"]
        else:
            if k == "mesh":
                me = bpy.data.meshes.new("%s_%s" % (tag, it["name"]))
                me.from_pydata(it["verts"], [], it["faces"])
                me.update()
                me.materials.append(None)
                m.created.append(("meshes", me))
                o = new_obj(it["name"], me)
            else:
                o = new_obj(it["name"], mesh(*geos[k]))
            o.material_slots[0].link = "OBJECT"
            o.material_slots[0].material = tts._material(m, it["mat"])
            if k == "tube":
                p0, p1 = mathutils.Vector(it["p0"]), mathutils.Vector(it["p1"])
                o.location = p0
                o.rotation_mode = "QUATERNION"
                o.rotation_quaternion = tts._quat_x_to(p1 - p0)
                o.scale = ((p1 - p0).length, it["r"], it["r"])
            else:
                if "loc" in it:
                    o.location = it["loc"]
                if "size" in it:
                    o.scale = it["size"]
        if it.get("track") is not None:
            m.anim.append((o, it["track"]))
    for it in model.items:                                          # second pass: parent links (local transforms stay as set above)
        if it.get("parent"):
            objs[it["name"]].parent = objs[it["parent"]]
    for cm in model.cams:
        cd = bpy.data.cameras.new(cm["name"])
        m.created.append(("cameras", cd))
        cd.lens_unit, cd.angle = "FOV", math.radians(cm["fov"])
        cd.clip_start, cd.clip_end = 0.1, 800.0
        o = new_obj(cm["name"], cd)
        o.location = cm["loc"]
        o.rotation_mode = "QUATERNION"
        o.rotation_quaternion = (mathutils.Vector(cm["target"]) - mathutils.Vector(cm["loc"])).to_track_quat("-Z", "Y")
        o["x3d_viewpoint_description"] = cm["desc"]
        if cm["name"].startswith("VP1"):
            scene.camera = o
    for lg in model.lights:
        ld = bpy.data.lights.new(lg["name"], "SUN")
        m.created.append(("lights", ld))
        ld.energy, ld.color = lg["energy"], lg["rgb"]
        o = new_obj(lg["name"], ld)
        o.location = (0, 0, 20)
        o.rotation_mode = "QUATERNION"
        o.rotation_quaternion = mathutils.Vector(lg["dir"]).to_track_quat("-Z", "Y")
    tts._install_handler()
    tts._registry()[scene.name] = m
    scene.frame_set(1)
    m.apply(1)
    if live and bpy.context.window is not None:
        bpy.context.window.scene = scene
    return m


def polish_x3d(path):
    """Post-export touches: only the key light casts (softer) shadows, and a subtle gradient background instead of a flat colour."""
    s = open(path, encoding="utf-8").read()

    def light(mo):
        tag = mo.group(0)
        if "LI_key" in tag:
            return tag.replace('shadows="true"', 'shadows="true" shadowIntensity="0.4"')
        return tag.replace('shadows="true"', 'shadows="false"')
    s = re.sub(r'<DirectionalLight [^>]*>', light, s)
    s = re.sub(r'<Background skyColor="[^"]*" />', '<Background skyColor="0.004 0.006 0.012 0.018 0.022 0.035" skyAngle="1.5708" '
               'groundColor="0.030 0.040 0.065 0.012 0.016 0.028 0.005 0.007 0.013" groundAngle="0.6 1.5708" />', s)
    open(path, "w", encoding="utf-8").write(s)


def export_x3d(mach, path, compact_eps=2e-3):
    info = tts.export_x3d(mach, path, compact=False)
    comp = tts.compact_x3d(path, eps=compact_eps)
    polish_x3d(path)
    info.update(compact=comp, bytes=os.path.getsize(path))
    return info


def export_fit_gnn(trace_path, out_x3d, max_kb=900, out_blend=None, log=print, **cfg):
    """Headless: build + export, trying coarser exporter steps / fewer message loops until the file fits max_kb."""
    budget, attempts, result = max_kb * 1024, [], None
    for step, loops in ((4, 2), (4, 1), (6, 2), (6, 1), (8, 1), (12, 1)):
        tts._fresh_blender()
        m = build_gnn(trace_path, live=False, step=step, msg_loops=loops, **cfg)
        info = export_x3d(m, out_x3d)
        attempts.append(dict(step=step, msg_loops=loops, bytes=info["bytes"], kb=round(info["bytes"] / 1024, 1)))
        log("attempt step=%d msg_loops=%d -> %.1f KB" % (step, loops, info["bytes"] / 1024))
        if info["bytes"] <= budget:
            result = (m, info, step, loops)
            break
    if not result:
        raise RuntimeError("could not fit %d KB: %s" % (max_kb, attempts))
    m, info, step, loops = result
    md = m.model
    rep = dict(trace=os.path.basename(trace_path), x3d=out_x3d, kb=round(info["bytes"] / 1024, 1), bytes=info["bytes"], step=step, msg_loops=loops, frames=md.nf, fps=md.fps,
               text_nodes=info["text_nodes"], attempts=attempts, banner=md.banner, objects_exported=sum(1 for o in m.scene.objects if not o.get("x3d_skip")),
               shown_metrics=[k for k, _ in md.shown_metrics], mapping=md.mapping_lines(), caption=md.caption, stats=md.stats, playback_s=md.pb,
               viewpoints=[c["name"] for c in md.cams], compact=info["compact"], slots={k: [round(a, 3), round(b, 3)] for k, (a, b) in md.slots.win.items()},
               epoch_t0=md.slots.t0, epoch_t1=md.slots.t1, epochs=md.E)
    if out_blend:
        _save_blend_gnn(m, trace_path, out_blend, dict(step=step, msg_loops=loops, n_frames=md.nf))
        rep["blend"] = out_blend
    return m, rep


def _save_blend_gnn(mach, trace_path, out_blend, cfg):
    """Keep both scripts and the trace inside the .blend so attach_saved_gnn() can re-create the frame handler after opening it."""
    for nm, src in (("trace_to_scene.py", tts.__file__), ("gnn_scene.py", globals().get("__file__")), (os.path.basename(trace_path), trace_path)):
        if src and os.path.exists(src):
            bpy.data.texts.new(nm).from_string(open(src, encoding="utf-8").read())
    mach.scene["x3d_trace_text"] = os.path.basename(trace_path)
    mach.scene["x3d_gnn_cfg"] = json.dumps(cfg)
    os.makedirs(os.path.dirname(os.path.abspath(out_blend)), exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=out_blend, check_existing=False)


def attach_saved_gnn(scene=None):
    """After opening a saved .blend: run its text 'gnn_scene.py' (it loads the embedded 'trace_to_scene.py' itself), then call attach_saved_gnn()."""
    scene = scene or bpy.context.scene
    trace = json.loads(bpy.data.texts[scene["x3d_trace_text"]].as_string())
    model = GnnModel(trace, **json.loads(scene["x3d_gnn_cfg"]))
    m = tts.Machine(model, scene, scene.name)
    for it in model.items:
        if it.get("track") is None:
            continue
        for nm in (it["name"], it["name"] + "_f"):
            o = bpy.data.objects.get(nm)
            if o is not None:
                m.anim.append((o, it["track"]))
    tts._install_handler()
    tts._registry()[scene.name] = m
    scene.frame_set(scene.frame_current)
    return m


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(prog="gnn_scene")
    ap.add_argument("--gnn-trace", required=True)
    ap.add_argument("--gnn-out-x3d", required=True)
    ap.add_argument("--gnn-out-blend")
    ap.add_argument("--gnn-max-kb", type=float, default=900)
    ap.add_argument("--gnn-report")
    a = ap.parse_args(argv)
    os.makedirs(os.path.dirname(os.path.abspath(a.gnn_out_x3d)), exist_ok=True)
    m, rep = export_fit_gnn(a.gnn_trace, a.gnn_out_x3d, a.gnn_max_kb, a.gnn_out_blend)
    print("RESULT %.1f KB (limit %g) step=%d msg_loops=%d objects=%d -> %s" % (rep["kb"], a.gnn_max_kb, rep["step"], rep["msg_loops"], rep["objects_exported"], a.gnn_out_x3d))
    if a.gnn_report:
        with open(a.gnn_report, "w") as fh:
            json.dump(rep, fh, indent=1, default=str)


if bpy is not None and "--gnn-trace" in sys.argv:
    main(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:])
