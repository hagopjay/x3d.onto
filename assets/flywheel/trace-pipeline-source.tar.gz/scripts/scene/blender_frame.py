"""Render one frame of a saved machine .blend with Blender itself (EEVEE) to check the Blender-side scene: labels (FONT twins),
materials, handler-driven animation after attach_saved().
  Blender -b --factory-startup -noaudio --python scripts/scene/blender_frame.py -- X.blend OUT.png FRAME [CAMERA_NAME]"""
import sys, bpy
a = sys.argv[sys.argv.index("--") + 1:]
path, out, frame = a[0], a[1], int(a[2])
bpy.ops.wm.open_mainfile(filepath=path)
ns = {"__name__": "__main__"}
exec(bpy.data.texts["trace_to_scene.py"].as_string(), ns)
sc = next(s for s in bpy.data.scenes if "x3d_trace_text" in s)
bpy.context.window.scene = sc
ns["attach_saved"](sc)
if len(a) > 3:
    sc.camera = bpy.data.objects[a[3]]
sc.frame_set(frame)
r = sc.render
r.engine = "BLENDER_EEVEE"
r.resolution_x, r.resolution_y, r.resolution_percentage = 1280, 720, 100
r.filepath = out
r.image_settings.file_format = "PNG"
try:
    sc.eevee.taa_render_samples = 16
except Exception:
    pass
bpy.ops.render.render(write_still=True, scene=sc.name)
print("BLENDER_FRAME_OK", out)
