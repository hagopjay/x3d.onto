#!/usr/bin/env python3
"""trace_to_scene.py: turn ANY x3d-trace/1 file (see TRACE_SCHEMA.md) into "the machine":
(a) an animated Blender scene and (b) an animated X3D 4.0 file written by the x3d_blender_io add-on.

Headless:  Blender -b --factory-startup -noaudio --python scripts/scene/trace_to_scene.py -- \
               --trace PATH --out-x3d PATH [--out-blend PATH] [--max-kb 900] [--report-json PATH]
Live:      inside a running Blender, run this file's text through Python's exec, then
               m = build("/path/to/x.trace.json", live=True)        # NEW scene, nothing else is reset or deleted
               export_x3d(m, "/path/out.x3d")                       # the X3D for exactly the step the scene was built for

Pure data in, deterministic out: every number on the scene comes from the trace; derived values (log scales, ratios
against a trace-wide maximum, display-time stretching) are listed in the mapping legend that is drawn on the scene.

Animation = one bpy.app.handlers.frame_change_pre handler that sets location/scale of the animated objects from the
trace at each frame. No keyframes, no fcurves. The X3D exporter samples matrix_world per frame (animation_step) into
Position/Scale interpolators.
"""
import bisect, json, math, os, re, sys, textwrap
from xml.sax.saxutils import escape as _xesc

try:
    import bpy, mathutils
except ImportError:                      # the Model (layout + tracks) is pure python and testable without Blender
    bpy = None
    mathutils = None

DEFAULTS = dict(
    n_frames=360, fps=24,        # trace time is mapped onto frames 1..n_frames (360 frames @ 24 fps = 15.0 s)
    step=1,                      # animation_step the exporter will use; tracks are built so that jumps hide between keys
    leg_play=0.25,               # playback seconds a tracer needs per tube leg
    transit_play=1.4,            # playback seconds an ambient flow particle needs to cross its tube
    amb_total=140, amb_cap=12,   # ambient flow particles (all flows) and per-flow cap
    tracer_cap=400, dx_max=11.0, tube_z=0.4, max_entities=40, text_scale=1.0,
)
MIN_SCALE = 2e-5                 # the X3D writer prints %.6f: a scale must never print as 0.000000


# ----------------------------------------------------------------------------- small utilities
def normk(k):
    return re.sub(r"[^a-z0-9]", "", str(k).lower())


def lerp(a, b, u):
    return a + (b - a) * u


def vlerp(p, q, u):
    return (p[0] + (q[0] - p[0]) * u, p[1] + (q[1] - p[1]) * u, p[2] + (q[2] - p[2]) * u)


def lognorm(v, lo, hi):
    if hi <= lo:
        return 0.5
    return min(1.0, max(0.0, (math.log1p(v) - math.log1p(lo)) / (math.log1p(hi) - math.log1p(lo))))


RAMP = [(0.0, (0.10, 0.32, 0.85)), (0.5, (0.98, 0.72, 0.12)), (1.0, (1.0, 0.18, 0.06))]
KIND_RGB = {"producer": (0.10, 0.55, 0.55), "partition": (0.30, 0.34, 0.50), "broker": (0.30, 0.34, 0.50),
            "consumer": (0.48, 0.32, 0.72), "scan": (0.15, 0.45, 0.75), "shuffle": (0.35, 0.40, 0.58),
            "aggregate": (0.30, 0.55, 0.45), "join": (0.60, 0.45, 0.25), "sort": (0.50, 0.40, 0.55),
            "output": (0.75, 0.75, 0.80)}
NEUTRAL = (0.35, 0.42, 0.52)
TRACER_RGB = {"chatter": (0.78, 0.92, 1.0), "cascade": (1.0, 0.70, 0.15), "scandal": (1.0, 0.22, 0.70)}
TRACER_EXTRA = [(0.5, 1.0, 0.5), (1.0, 1.0, 0.4), (0.7, 0.5, 1.0)]


def ramp(h, bins=8):
    h = min(1.0, max(0.0, h))
    h = round(h * (bins - 1)) / (bins - 1)
    for (a, ca), (b, cb) in zip(RAMP, RAMP[1:]):
        if h <= b:
            u = (h - a) / (b - a)
            return tuple(round(lerp(ca[i], cb[i], u), 3) for i in range(3))
    return RAMP[-1][1]


def fmt_num(v):
    if v is None:
        return "-"
    if isinstance(v, bool):
        return str(v)
    f = float(v)
    if f.is_integer():
        n, a = int(f), abs(int(f))
        if a >= 10 ** 9:
            return "%.2fG" % (n / 1e9)
        if a >= 10 ** 6:
            return "%.2fM" % (n / 1e6)
        if a >= 10 ** 5:
            return "%.1fk" % (n / 1e3)
        return "{:,}".format(n)
    return "%.3g" % f


def fmt_metric(key, v):
    k = str(key).lower()
    if v is None:
        return "-"
    if "bytes" in k:
        f = float(v)
        for unit, div in (("TB", 1e12), ("GB", 1e9), ("MB", 1e6), ("kB", 1e3)):
            if abs(f) >= div:
                return "%.2f %s" % (f / div, unit)
        return "%d B" % f
    if re.search(r"(^|[^a-z])ms([^a-z]|$)", k):
        return "{:,} ms".format(int(round(float(v))))
    if "ratio" in k:
        return "%.2f" % float(v)
    return fmt_num(v)


def wrap(text, width):
    return textwrap.wrap(str(text), max(4, int(width)), break_long_words=True) or [""]


def nice_step(duration, target=6):
    for m in (1e-3, 1e-2, 1e-1, 1, 10, 100, 1000):
        for b in (1, 2, 5):
            s = b * m
            if duration / s <= target + 2:
                return s
    return duration


def interp(xs, ys, x):
    i = bisect.bisect_right(xs, x)
    if i <= 0:
        return ys[0]
    if i >= len(xs):
        return ys[-1]
    x0, x1 = xs[i - 1], xs[i]
    return ys[i - 1] if x1 <= x0 else lerp(ys[i - 1], ys[i], (x - x0) / (x1 - x0))


# ----------------------------------------------------------------------------- tracks (pure python)
class SegTrack:
    """Piecewise-linear motion. seg = (t0, t1, p0, p1, s0, s1): position and uniform scale factor lerp over [t0, t1].
    Between segments the object is hidden (scale 0). It stays where the previous segment ended for `jump` seconds and
    then jumps to the next start: with jump = one key interval and gaps of >= 2 key intervals, the jump always falls
    between two exported keys that are both hidden, so the interpolators never draw a streak."""

    def __init__(self, segs, base=(1.0, 1.0, 1.0), jump=0.0):
        self.s = sorted(segs, key=lambda g: g[0])
        self.starts = [g[0] for g in self.s]
        self.base = base
        self.jump = jump

    def at(self, t):
        S = self.s
        i = bisect.bisect_right(self.starts, t) - 1
        if i < 0:
            loc, k = S[0][2], 0.0
        else:
            t0, t1, p0, p1, s0, s1 = S[i]
            if t <= t1:
                u = (t - t0) / (t1 - t0) if t1 > t0 else 1.0
                loc, k = vlerp(p0, p1, u), lerp(s0, s1, u)
            else:
                loc = p1 if (i + 1 >= len(S) or t < t1 + self.jump) else S[i + 1][2]
                k = 0.0
        return loc, tuple(max(b * k, MIN_SCALE) for b in self.base)


class BarTrack:
    """Scale of a bar standing on its base (mesh spans z 0..1): z-scale = zmin + (zmax - zmin) * v(t), v from a series."""

    def __init__(self, ts, vs, sx, sy, zmin, zmax):
        self.ts, self.vs, self.sx, self.sy, self.zmin, self.zmax = ts, vs, sx, sy, zmin, zmax

    def at(self, t):
        v = min(1.0, max(0.0, interp(self.ts, self.vs, t)))
        return None, (self.sx, self.sy, max(self.zmin + (self.zmax - self.zmin) * v, MIN_SCALE))


# ----------------------------------------------------------------------------- the model
class Model:
    """Layout + tracks computed from a trace. No bpy here; `items` is a list of dict specs the builder realises."""

    def __init__(self, trace, **cfg):
        c = dict(DEFAULTS)
        c.update({k: v for k, v in cfg.items() if v is not None})
        self.c, self.tr = c, trace
        if trace.get("schema") != "x3d-trace/1":
            raise ValueError("not an x3d-trace/1 file")
        src = trace.get("source") or {}
        if "synthetic" not in src:
            raise ValueError("source.synthetic is required by the trace contract")
        self.syn = bool(src["synthetic"])
        self.D = float(trace["time"]["duration"])
        self.nf, self.fps = int(c["n_frames"]), int(c["fps"])
        self.pb = (self.nf - 1) / self.fps               # playback seconds
        self.tps = self.D / self.pb                      # trace seconds per playback second
        self.fpt = (self.nf - 1) / self.D                # frames per trace second
        self.dk = c["step"] / self.fpt                   # trace seconds between exported keys
        self.items, self._names = [], set()
        self.bb = [1e9, 1e9, -1e9, -1e9]                 # x0, y0, x1, y1 of everything placed so far
        self.stats = {}
        self.mapping = []                                # mapping lines (drawn on the scene and copied to the report)
        self._stages()
        self._flows()
        self._bars()
        self._events()
        self._tracers_or_ambient()
        self._timeline()
        self._entities()
        self._wall()
        self._rig()

    # ---- helpers
    def add(self, kind, name, **kw):
        assert name not in self._names, "duplicate item name " + name
        self._names.add(name)
        d = dict(kind=kind, name=name)
        d.update(kw)
        self.items.append(d)
        return d

    def grow(self, x0, y0, x1, y1):
        b = self.bb
        self.bb = [min(b[0], x0), min(b[1], y0), max(b[2], x1), max(b[3], y1)]

    def label(self, lines, loc, size, rgb=(0.92, 0.94, 0.97), mode="billboard", align="center", valign="center"):
        lines = [str(x) for x in lines if x is not None] or [""]
        size *= self.c["text_scale"]
        name = "TXT_%03d" % (sum(1 for k in self._names if k.startswith("TXT_")) + 1)
        return self.add("label", name, lines=lines, loc=tuple(loc), size=size, rgb=rgb, mode=mode, align=align, valign=valign)

    def cap_chars(self, width, size):
        return int(width / (0.56 * size * self.c["text_scale"]))

    # ---- stages: blocks laid out left to right by layer, stacked by index
    def _stages(self):
        c, tr = self.c, self.tr
        stages = tr["stages"]
        n = len(stages)
        self.S = {s["id"]: s for s in stages}
        self.sm = {s["id"]: {normk(k): (k, float(v)) for k, v in (s.get("metrics") or {}).items()
                             if isinstance(v, (int, float)) and not isinstance(v, bool)} for s in stages}
        layers = sorted({s["layer"] for s in stages})
        by = {l: [s for s in stages if s["layer"] == l] for l in layers}
        maxn = max(len(v) for v in by.values())
        self.pitch = min(3.2, max(1.4, 8.0 / maxn))
        self.span = maxn * self.pitch
        self.dx = min(c["dx_max"], max(5.5, 36.0 / max(len(layers) - 1, 1)))
        # volume (block height): one trace-wide key if it covers >= half of the stages, records as the fallback
        vk = ("bytesout", "shuffleoutputbytes", "recordsout", "recordsin", "recordsread", "recordswritten")
        cov = {k: sum(1 for s in stages if self.sm[s["id"]].get(k, (0, 0))[1] > 0) for k in vk}
        vkey = next((k for k in vk if cov[k] >= 0.5 * n), None)
        chain = ([vkey] if vkey else []) + [k for k in vk if k != vkey]

        def vol(sid):
            for k in chain:
                e = self.sm[sid].get(k)
                if e and e[1] > 0:
                    return e
            return None
        vols = {s["id"]: vol(s["id"]) for s in stages}
        vv = [e[1] for e in vols.values() if e]
        vlo, vhi = (min(vv), max(vv)) if vv else (0, 0)
        # heat (block colour): the first of these metrics a stage has, relative to the trace maximum of that metric
        hk = ("slotms", "peaklag", "peakmsgspers")
        hmax = {k: max([self.sm[s["id"]][k][1] for s in stages if k in self.sm[s["id"]]] or [0]) for k in hk}
        hcov = {k: sum(1 for s in stages if k in self.sm[s["id"]]) for k in hk}
        self.heat = {}
        for s in stages:
            for k in hk:
                if k in self.sm[s["id"]] and hmax[k] > 0:
                    self.heat[s["id"]] = (self.sm[s["id"]][k][0], self.sm[s["id"]][k][1] / hmax[k], k)
                    break
        prim = next((k for k in hk if hcov[k] >= 0.4 * n), None)
        cands = [s["id"] for s in stages if prim and prim in self.sm[s["id"]]]
        self.hottest = (max(cands, key=lambda i: self.sm[i][prim][1]) if cands else
                        max((i for i in vols if vols[i]), key=lambda i: vols[i][1], default=stages[0]["id"]))
        skews = {s["id"]: self.sm[s["id"]]["skewratio"][1] for s in stages if "skewratio" in self.sm[s["id"]]}
        skmax = max(skews.values(), default=1.0)
        pmax = max(max(1.0, float(s.get("parallelism") or 1)) for s in stages)
        self.pos, self.dying = {}, {}
        for li, l in enumerate(layers):
            grp = by[l]
            m = len(grp)
            cell = self.span / m
            for i, s in enumerate(grp):
                sid = s["id"]
                x, y = li * self.dx, (i + 0.5 - m / 2) * cell
                par = max(1.0, float(s.get("parallelism") or 1))
                sy = min(0.62 * cell, 1.3 * (0.6 + 0.4 * lognorm(par, 1.0, pmax)))
                sx = 1.7
                sz = 0.7 + 2.3 * lognorm(vols[sid][1], vlo, vhi) if vols[sid] else 1.2
                rgb = ramp(self.heat[sid][1]) if sid in self.heat else KIND_RGB.get(s.get("kind"), NEUTRAL)
                self.pos[sid] = dict(x=x, y=y, sx=sx, sy=sy, sz=sz, rgb=rgb, cell=cell, layer=l, li=li)
                self.grow(x - sx / 2 - 0.5, y - sy / 2, x + sx / 2 + 0.5, y + sy / 2)
        self.ymin_m, self.ymax_m = -self.span / 2, self.span / 2
        self.grow(-1.5, self.ymin_m, (len(layers) - 1) * self.dx + 1.5, self.ymax_m)
        self.layers, self.by_layer = layers, by
        self.pk, self.vkey, self.vols, self.skews, self.skmax = prim, vkey, vols, skews, skmax
        vname = self._okey(vkey) if vkey else "n/a"
        self.mapping += [
            "block height = log(%s) over the trace (0.7 to 3.0)" % vname,
            "block colour = %s / its trace max (blue, amber, red); no heat metric: neutral per kind"
            % ("/".join(sorted({v[0] for v in self.heat.values()})) or "n/a"),
            "block depth = log(parallelism)"]
        for s in stages:
            sid = s["id"]
            p = self.pos[sid]
            tk = None
            e = self.sm[sid].get("diesats")                  # metrics.dies_at_s: the block shrinks to 40 % at that moment
            if e is not None:
                td, dur, here = e[1], 0.6 * self.tps, (p["x"], p["y"], 0.0)
                tk = SegTrack([(-1.0, td, here, here, 1.0, 1.0), (td, td + dur, here, here, 1.0, 0.4),
                               (td + dur, self.D + 10.0, here, here, 0.4, 0.4)], base=(p["sx"], p["sy"], p["sz"]))
                self.dying[sid] = td
            self.add("block", "B_" + re.sub(r"\W", "_", sid), sid=sid, loc=(p["x"], p["y"], 0.0), size=(p["sx"], p["sy"], p["sz"]),
                     mat=dict(kind="pbr", rgb=p["rgb"], alpha=1.0, rough=0.45, emit=0.0), track=tk)
            if sid in skews and skews[sid] > 1.05:
                hh = 0.2 + 3.2 * (skews[sid] - 1.0) / max(skmax - 1.0, 1e-9)
                self.add("bar", "SK_" + re.sub(r"\W", "_", sid), sid=sid,
                         loc=(p["x"] - p["sx"] / 2 + 0.2, p["y"] - p["sy"] / 2 + 0.2, p["sz"]), size=(0.16, 0.16, hh),
                         mat=dict(kind="pbr", rgb=(0.95, 0.2, 0.62), alpha=1.0, rough=0.4, emit=0.5), track=None)
                p["skew_h"] = hh
        if skews:
            self.mapping.append("magenta post on a block = skew_ratio (height ~ (skew-1)/(max-1), trace max %.2f)" % skmax)
        for l in layers:                                     # layer headers lie flat on the floor in front of each layer
            grp = by[l]
            kinds = sorted({s.get("kind", "") for s in grp})
            self.label(["/".join(k for k in kinds if k) + (" (%d)" % len(grp) if len(grp) > 1 else "")],
                       (self.pos[grp[0]["id"]]["x"], self.ymin_m - 1.3, 0.02), 0.5, (0.75, 0.82, 0.92), mode="flat")

    def _okey(self, k):
        for s in self.tr["stages"]:
            if k in self.sm[s["id"]]:
                return self.sm[s["id"]][k][0]
        return k

    # ---- flows: tubes with ports on the block faces
    def _flows(self):
        c = self.c
        flows = [f for f in self.tr.get("flows") or [] if f.get("from") in self.S and f.get("to") in self.S]
        self.flows = flows
        outs, ins = {}, {}
        for fi, f in enumerate(flows):
            outs.setdefault(f["from"], []).append(fi)
            ins.setdefault(f["to"], []).append(fi)
        for sid in outs:
            outs[sid].sort(key=lambda fi: self.pos[flows[fi]["to"]]["y"])
        for sid in ins:
            ins[sid].sort(key=lambda fi: self.pos[flows[fi]["from"]]["y"])
        recs = [float(f.get("records") or f.get("bytes") or 1) for f in flows]
        rlo, rhi = (min(recs), max(recs)) if recs else (0, 0)
        self.fl, self.flow_by_key = [], {}
        for fi, f in enumerate(flows):
            a, b = self.pos[f["from"]], self.pos[f["to"]]
            ko, mo = outs[f["from"]].index(fi), len(outs[f["from"]])
            ki, mi = ins[f["to"]].index(fi), len(ins[f["to"]])
            oo = (ko - (mo - 1) / 2) * min(0.22, 0.85 * a["sy"] / mo)
            oi = (ki - (mi - 1) / 2) * min(0.22, 0.85 * b["sy"] / mi)
            p0 = (a["x"] + a["sx"] / 2 - 0.02, a["y"] + oo, c["tube_z"])
            p1 = (b["x"] - b["sx"] / 2 + 0.02, b["y"] + oi, c["tube_z"])
            r = 0.03 + 0.07 * lognorm(recs[fi], rlo, rhi)
            d = dict(f=f, p0=p0, p1=p1, r=r, key=(f["from"], f["to"]))
            self.fl.append(d)
            self.flow_by_key.setdefault(d["key"], d)
            self.add("tube", "T_%s_%s" % (f["from"], f["to"]), p0=p0, p1=p1, r=r,
                     mat=dict(kind="pbr", rgb=(0.55, 0.72, 0.92), alpha=0.32, rough=0.2, emit=0.0))
        self.mapping.append("tube radius = log(flow records), 0.03 to 0.10")

    # ---- series channels: bars on top of the stage they name (or gauges at the back for global channels)
    def _bars(self):
        ser = self.tr.get("series") or {}
        ts = [float(t) for t in ser.get("t") or []]
        chans = ser.get("channels") or {}
        ids = set(self.S)
        fam = {}
        for name, vals in chans.items():
            if len(vals) != len(ts) or not ts or not all(isinstance(v, (int, float)) for v in vals):
                continue
            toks = name.split(":")
            idx = next((i for i, t in enumerate(toks) if t in ids), None)
            fname = ":".join("*" if i == idx else t for i, t in enumerate(toks))
            fam.setdefault(fname, []).append((name, toks[idx] if idx is not None else None, vals))
        self.fam, self.gauges, per_stage = {}, [], {}
        for fname, members in fam.items():
            fmax = max((max(v) for _, _, v in members), default=0.0)
            self.fam[fname] = fmax
            tower = bool(re.search(r"lag|pending|queue|wait|backlog", fname))
            for name, sid, vals in members:
                vs = [(v / fmax if fmax > 0 else 0.0) for v in vals]
                rec = dict(name=name, fam=fname, sid=sid, vs=vs, tower=tower, peak=max(vs) if vs else 0.0, fmax=fmax)
                (self.gauges if sid is None else per_stage.setdefault(sid, [])).append(rec)
        self.bar_peak = {}
        for sid, recs in per_stage.items():
            p = self.pos[sid]
            for j, r in enumerate(sorted(recs, key=lambda r: r["name"])):
                w, zmax = (0.62, 4.0) if r["tower"] else (0.34, 3.4)
                x = p["x"] + p["sx"] / 2 - 0.1 - w / 2 - j * 0.7
                self.add("bar", "BR_%s_%d" % (re.sub(r"\W", "_", sid), j), sid=sid, loc=(x, p["y"], p["sz"]), size=(w, w, zmax),
                         mat=dict(kind="pbr", rgb=(1.0, 0.25, 0.35) if r["tower"] else (1.0, 0.72, 0.15), alpha=1.0, rough=0.4, emit=0.6),
                         track=BarTrack(ts, r["vs"], w, w, 0.02, zmax))
                self.bar_peak[sid] = max(self.bar_peak.get(sid, 0.0), 0.02 + (zmax - 0.02) * r["peak"])
        if fam:
            self.mapping.append("bar on a block = its series channel / family max (full height 3.4; lag-like channels 4.0)")
        for s in self.tr["stages"]:                          # stage labels float just above the highest point a bar can reach
            sid = s["id"]
            p = self.pos[sid]
            top = p["sz"] + max(self.bar_peak.get(sid, 0.0), p.get("skew_h", 0.0)) + 0.35
            dense = p["cell"] < 2.0
            nm = s.get("engine_name") or s["name"]
            lines = wrap(nm, 26)
            if not dense:
                if s.get("engine_name") and s["name"] != s["engine_name"]:
                    lines += wrap(s["name"], 26)[:2]
                m, shown = self.sm[sid], []
                for k in ("slotms", "bytesout", "shuffleoutputbytes", "recordsin", "recordsout", "skewratio", "peakmsgspers", "peaklag"):
                    if k in m and len(shown) < 3 and not (k in ("recordsin", "recordsout") and shown):
                        shown.append("%s %s" % (m[k][0], fmt_metric(m[k][0], m[k][1])))
                lines += shown
            size = 0.27 if dense else 0.24
            hgt = len(lines) * size * 1.15
            idx = [g["id"] for g in self.by_layer[p["layer"]]].index(sid)
            stagger = idx * max(0.0, hgt - 0.54 * p["cell"] + 0.15) if not dense else 0.0   # neighbours in a layer must not overprint
            self.label(lines, (p["x"], p["y"], top + stagger + 0.5 * hgt + 0.05), size)
        self.gauge_y = self.ymax_m + 2.4                     # global channels become gauge columns in a back row
        for j, g in enumerate(sorted(self.gauges, key=lambda g: g["name"])):
            x = -0.5 + j * 1.9
            self.add("bar", "GA_%d" % j, loc=(x, self.gauge_y, 0.0), size=(0.7, 0.7, 4.4),
                     mat=dict(kind="pbr", rgb=(1.0, 0.25, 0.35) if g["tower"] else (1.0, 0.72, 0.15), alpha=1.0, rough=0.4, emit=0.6),
                     track=BarTrack(ts, g["vs"], 0.7, 0.7, 0.02, 4.4))
            top = 0.02 + 4.38 * g["peak"]
            lines = wrap(g["name"], 18) + ["max " + fmt_metric(g["name"], g["fmax"])]
            self.label(lines, (x, self.gauge_y, top + 0.5 + 0.15 * len(lines)), 0.24)
            self.grow(x - 0.9, self.gauge_y - 0.5, x + 0.9, self.gauge_y + 0.5)
        if self.gauges:
            self.mapping.append("gauge column (back row) = a global series channel / its own max (full height 4.4)")

    # ---- events: stage deaths, optional trace["events"], a rebalance window parsed from the notes
    def _events(self):
        ev = []
        for e in self.tr.get("events") or []:
            ev.append(dict(start=float(e["start_s"]), end=float(e.get("end_s", e["start_s"])), label=str(e.get("label", "event")),
                           stage=e.get("stage"), ring=bool(e.get("ring")) and float(e.get("end_s", e["start_s"])) > float(e["start_s"])))
        if not ev:
            note = " ".join(self.tr.get("notes") or [])
            m = re.search(r"rebalanc\w*[^.]*?\bfor\s+(\d+(?:\.\d+)?)\s*s\b", note)
            for sid, td in self.dying.items():
                ev.append(dict(start=td, end=td, label="%s dies" % self.S[sid].get("name", sid), stage=sid))
                if m:
                    ev.append(dict(start=td, end=td + float(m.group(1)), label="rebalance (%g s, from notes)" % float(m.group(1)),
                                   stage=sid, ring=True))
        self.events = ev
        for j, e in enumerate(x for x in ev if x.get("ring") and x.get("stage") in self.S):
            ps = [self.pos[s["id"]] for s in self.by_layer[self.S[e["stage"]]["layer"]]]
            cx = sum(p["x"] for p in ps) / len(ps) - 0.6
            cy = (min(p["y"] for p in ps) + max(p["y"] for p in ps)) / 2 - 0.6
            rx, ry = 3.1, (max(p["y"] for p in ps) - min(p["y"] for p in ps)) / 2 + 3.0
            pos, fade, pulse = (cx, cy, 0.06), 0.4 * self.tps, 0.5 * self.tps
            a, b = e["start"], e["end"]
            t, s = a + fade, 1.0
            segs = [(a, t, pos, pos, 0.0, 1.0)]
            while t + pulse <= b - fade:
                s2 = 1.12 if s == 1.0 else 1.0
                segs.append((t, t + pulse, pos, pos, s, s2))
                s, t = s2, t + pulse
            segs.append((t, b, pos, pos, s, 0.0))
            self.add("ring", "RING_%d" % j, track=SegTrack(segs, base=(rx, ry, 6.0), jump=self.dk),
                     mat=dict(kind="emit", rgb=(1.0, 0.45, 0.3), alpha=1.0))
            self.grow(cx - rx, cy - ry, cx + rx, cy + ry)

    # ---- particles: Kafka tracers (individual messages) or ambient flow particles
    def _alloc(self, intervals, gap):
        """Greedy interval colouring: a carrier is reused once idle for >= gap. Returns (carrier per interval, count)."""
        free, out = [], []
        for t0, t1 in intervals:
            k = next((i for i, f in enumerate(free) if f + gap <= t0), None)
            if k is None:
                free.append(t1)
                k = len(free) - 1
            else:
                free[k] = t1
            out.append(k)
        return out, len(free)

    def _tracers_or_ambient(self):
        c = self.c
        kinds = {k: [s["id"] for s in self.tr["stages"] if s.get("kind") == k] for k in ("producer", "partition", "consumer")}
        trc = (self.tr.get("tracers") or [])[: c["tracer_cap"]]
        self.tracer_mode = bool(trc) and all(kinds.values())
        self.stats.update(tracers=0, tracer_carriers=0, tracers_waited=0, ambient_particles=0)
        if self.tracer_mode:
            self._tracers(trc, kinds)
        self._ambient(int(c["amb_total"] * (0.7 if self.tracer_mode else 1.0)))

    def _tracers(self, trc, kinds):
        c = self.c
        L = c["leg_play"] * self.tps
        legs = [L, 0.3 * L, L, 0.4 * L, 0.4 * L]            # P->K tube, through K, K->C tube, to the inbox, into the consumer
        rows, per_cons = [], {}
        for tr in trc:
            try:
                P, K, C = kinds["producer"][tr["producer"]], kinds["partition"][tr["part"]], kinds["consumer"][tr["consumer"]]
            except (IndexError, KeyError, TypeError):
                continue
            t0 = float(tr["t"])
            arrive = t0 + sum(legs[:4])
            leave = max(arrive, float(tr["consume"]))          # a message that waited sits in the inbox until its consume time
            r = dict(tr=tr, P=P, K=K, C=C, t0=t0, arrive=arrive, leave=leave, end=leave + legs[4], kind=tr.get("kind", ""))
            rows.append(r)
            per_cons.setdefault(C, []).append(r)
        for C, lst in per_cons.items():                        # lowest free inbox slot per waiting message
            free = []
            for r in sorted(lst, key=lambda r: (r["arrive"], r["t0"])):
                k = next((i for i, f in enumerate(free) if f <= r["arrive"]), None)
                if k is None:
                    free.append(r["leave"])
                    k = len(free) - 1
                else:
                    free[k] = r["leave"]
                r["slot"] = k
        self.tray = {}
        for C in kinds["consumer"]:
            p = self.pos[C]
            tx, ty = p["x"] - 1.2, p["y"] - 2.1
            self.tray[C] = (tx, ty)
            self.add("plate", "TRAY_" + C, loc=(tx, ty, 0.03), size=(1.3, 1.3, 0.06),
                     mat=dict(kind="pbr", rgb=(0.6, 0.75, 0.9), alpha=0.35, rough=0.3, emit=0.0))
            self.label(["inbox " + C], (tx, ty - 1.05, 0.02), 0.26, (0.8, 0.88, 0.98), mode="flat")
            self.grow(tx - 0.8, ty - 1.3, tx + 0.8, ty + 0.8)
        names = sorted({r["kind"] for r in rows})
        extra = iter(TRACER_EXTRA)
        self.kind_rgb = {k: TRACER_RGB.get(k) or next(extra, (0.8, 0.8, 0.8)) for k in names}
        self.kind_counts = {k: sum(1 for r in rows if r["kind"] == k) for k in names}

        def route(r):
            fk, fc = self.flow_by_key.get((r["P"], r["K"])), self.flow_by_key.get((r["K"], r["C"]))
            pp, pk, pc = self.pos[r["P"]], self.pos[r["K"]], self.pos[r["C"]]
            A = fk["p0"] if fk else (pp["x"], pp["y"], c["tube_z"])
            B = fk["p1"] if fk else (pk["x"], pk["y"], c["tube_z"])
            Cc = fc["p0"] if fc else (pk["x"], pk["y"], c["tube_z"])
            Dp = fc["p1"] if fc else (pc["x"], pc["y"], c["tube_z"])
            tx, ty = self.tray[r["C"]]
            sl = r["slot"]
            slot = (tx - 0.34 + (sl % 3) * 0.34, ty - 0.34 + ((sl // 3) % 3) * 0.34, 0.2 + (sl // 9) * 0.34)
            return [(A, B), (B, Cc), (Cc, Dp), (Dp, slot)], slot, (pc["x"], pc["y"], 0.5)
        n, pr = 0, 0.17
        for kind in names:                                     # one carrier pool per kind: colour cannot be animated on export
            lst = sorted((r for r in rows if r["kind"] == kind), key=lambda r: r["t0"])
            ids, nc = self._alloc([(r["t0"], r["end"]) for r in lst], 2.1 * self.dk)
            cars = [[] for _ in range(nc)]
            for r, ci in zip(lst, ids):
                pts, slot, E = route(r)
                t = r["t0"]
                for j, (u, v) in enumerate(pts):
                    cars[ci].append((t, t + legs[j], u, v, 0.0 if j == 0 else 1.0, 1.0))
                    t += legs[j]
                if r["leave"] > t:
                    cars[ci].append((t, r["leave"], slot, slot, 1.0, 1.0))
                cars[ci].append((r["leave"], r["end"], slot, E, 1.0, 0.0))
            for cs in cars:
                n += 1
                self.add("particle", "TRC_%02d" % n, track=SegTrack(cs, base=(pr, pr, pr), jump=self.dk),
                         mat=dict(kind="emit", rgb=self.kind_rgb[kind], alpha=1.0), group="tracer")
        self.stats.update(tracers=len(rows), tracer_carriers=n, tracers_waited=sum(1 for r in rows if r["leave"] > r["arrive"] + 1e-9))
        self.tracer_rows = rows
        self.mapping.append("tracer = one sampled message (trace.tracers) flying producer, partition tube, consumer tube, inbox tray; "
                            "it leaves the tray at its recorded consume time, so a message that waited sits in the pile")

    def _ambient(self, total):
        c, fl = self.c, self.fl
        if total <= 0 or not fl:
            return
        w = [math.log1p(float(d["f"].get("records") or d["f"].get("bytes") or 1)) for d in fl]
        sw = sum(w) or 1.0
        T = c["transit_play"] * self.tps
        P = T + 2.1 * self.dk
        fi_ = 0.12
        k = 0
        for d, wi in zip(fl, w):
            f = d["f"]
            a, b = self.S[f["from"]], self.S[f["to"]]
            w0 = min(float(f.get("start_s", 0.0)), float(a.get("start_s", 0.0)))
            w1 = max(float(f.get("end_s", self.D)), float(b.get("end_s", self.D)))
            n = max(1, min(c["amb_cap"], int(round(total * wi / sw))))
            pr = 0.05 + 0.6 * d["r"]
            at = lambda u: vlerp(d["p0"], d["p1"], u)
            for j in range(n):
                segs, cs = [], w0 + ((j + 0.5) / n) * P
                while cs <= w1:
                    segs += [(cs, cs + fi_ * T, at(0), at(fi_), 0.0, 1.0),
                             (cs + fi_ * T, cs + (1 - fi_) * T, at(fi_), at(1 - fi_), 1.0, 1.0),
                             (cs + (1 - fi_) * T, cs + T, at(1 - fi_), at(1), 1.0, 0.0)]
                    cs += P
                if segs:
                    k += 1
                    self.add("particle", "AMB_%03d" % k, track=SegTrack(segs, base=(pr, pr, pr), jump=self.dk),
                             mat=dict(kind="emit", rgb=(0.45, 0.82, 1.0), alpha=1.0), group="ambient")
        self.stats["ambient_particles"] = k
        self.mapping.append("flow particles per tube ~ log(records), at most %d; they run from the producer's start_s to the consumer's end_s" % c["amb_cap"])

    # ---- timeline: ruler (+ stage windows as rows when the stages differ in time) with a moving cursor
    def _timeline(self):
        x0, x1 = -1.0, (len(self.layers) - 1) * self.dx + 1.0
        Wr, yt, st = x1 - x0, self.ymin_m - 2.6, self.tr["stages"]
        short = sum(1 for s in st if float(s.get("end_s", self.D)) - float(s.get("start_s", 0.0)) < 0.8 * self.D)
        rows = list(st) if short >= 0.5 * len(st) else []
        h = 0.42 * len(rows)
        xs = lambda t: x0 + Wr * min(max(t / self.D, 0.0), 1.0)
        rule = dict(kind="pbr", rgb=(0.7, 0.75, 0.85), alpha=1.0, rough=0.6, emit=0.2)
        self.add("plate", "RULER", loc=((x0 + x1) / 2, yt, 0.02), size=(Wr, 0.07, 0.04), mat=rule)
        step, v, i = nice_step(self.D), 0.0, 0
        while v <= self.D + 1e-9:
            self.add("plate", "TICK_%d" % i, loc=(xs(v), yt, 0.02), size=(0.05, 0.3, 0.04), mat=rule)
            self.label(["%g s" % round(v, 6)], (xs(v), yt + 0.45, 0.02), 0.36, (0.8, 0.85, 0.92), mode="flat")
            v, i = v + step, i + 1
        for i, s in enumerate(rows):
            y = yt - 0.55 - i * 0.42
            a, b = float(s.get("start_s", 0.0)), float(s.get("end_s", self.D))
            self.add("plate", "WIN_%d" % i, loc=((xs(a) + xs(b)) / 2, y, 0.02), size=(max(xs(b) - xs(a), 0.05), 0.26, 0.05),
                     mat=dict(kind="pbr", rgb=self.pos[s["id"]]["rgb"], alpha=1.0, rough=0.5, emit=0.3))
            self.label([s["id"]], (x0 - 0.2, y, 0.02), 0.26, (0.8, 0.85, 0.92), mode="flat", align="right")
        for j, e in enumerate(self.events):
            t = e["start"]
            txt = e["label"] if e["start"] == e["end"] else "%s %g to %g s" % (e["label"], e["start"], e["end"])
            self.label([txt], (xs(t), yt - 0.9 - h - 0.35 * j, 0.02), 0.28, (1.0, 0.55, 0.45), mode="flat", align="left")
            self.add("plate", "EV_%d" % j, loc=(xs(t), yt - h / 2 - 0.1, 0.05), size=(0.06, h + 0.6, 0.06),
                     mat=dict(kind="pbr", rgb=(1.0, 0.45, 0.35), alpha=1.0, rough=0.5, emit=0.6))
        self.caption = "playback %.1f s = %g s of trace time (%.1fx %s)" % (
            self.pb, self.D, (self.tps if self.tps >= 1 else 1 / self.tps), "faster" if self.tps >= 1 else "slower")
        self.label([self.caption], (x0, yt - h - 1.0 - 0.35 * len(self.events), 0.02), 0.3, (0.9, 0.9, 0.6), mode="flat", align="left")
        cy = yt - h / 2
        self.add("plate", "CURSOR", loc=(x0, cy, 0.15), size=(0.07, h + 0.7, 0.3), mat=dict(kind="emit", rgb=(1.0, 1.0, 0.6), alpha=1.0),
                 track=SegTrack([(-1.0, 0.0, (x0, cy, 0.15), (x0, cy, 0.15), 1.0, 1.0), (0.0, self.D, (x0, cy, 0.15), (x1, cy, 0.15), 1.0, 1.0),
                                 (self.D, self.D + 10.0, (x1, cy, 0.15), (x1, cy, 0.15), 1.0, 1.0)], base=(0.07, h + 0.7, 0.3)))
        self.flat_banner_y = yt - h - 2.4 - 0.35 * len(self.events)
        self.grow(x0 - 1.0, self.flat_banner_y - 0.8, x1 + 1.0, yt + 1.0)
        self.mapping.append("floor ruler + moving cursor = trace time; " + (
            "one row per stage = its start_s..end_s window" if rows else "no per-stage rows (stages span the whole run)"))

    # ---- entities: towers animated by their own series (if any), static pillars otherwise
    def _entities(self):
        c = self.c
        ents = sorted(self.tr.get("entities") or [], key=lambda e: e.get("rank", 1e9))[: c["max_entities"]]
        self.ents, self.ent_end_y = ents, 0.0
        if not ents:
            return
        with_s = [e for e in ents if (e.get("series") or {}).get("v")]
        no_s = [e for e in ents if not (e.get("series") or {}).get("v")]
        yb = self.gauge_y + (3.4 if self.gauges else 1.0)
        x0, W = -1.0, (len(self.layers) - 1) * self.dx + 2.0
        if with_s:
            gmax = max(max(e["series"]["v"]) for e in with_s) or 1.0
            gap = max(1.3, min(2.2, W / len(with_s)))
            unit = with_s[0]["series"].get("unit")
            for i, e in enumerate(with_s):
                x = x0 + 0.9 + i * gap
                t = [float(v) for v in e["series"]["t"]]
                tt = [(v - t[0]) / (t[-1] - t[0]) * self.D if t[-1] > t[0] else 0.0 for v in t]
                vs = [v / gmax for v in e["series"]["v"]]
                self.add("bar", "EN_%d" % i, loc=(x, yb, 0.0), size=(0.5, 0.5, 3.0),
                         mat=dict(kind="pbr", rgb=(0.2, 0.62, 0.72), alpha=1.0, rough=0.5, emit=0.35),
                         track=BarTrack(tt, vs, 0.5, 0.5, 0.02, 3.0))
                ex = e.get("extra") or {}
                lines = wrap("%s. %s" % (e.get("rank", i + 1), e["label"]), 15)[:3] + [fmt_num(e.get("value"))]
                if ex:
                    k0 = next(iter(ex))
                    lines.append("%s %s" % (k0, fmt_num(ex[k0])))
                self.label(lines, (x, yb, 0.02 + 2.98 * max(vs) + 0.4 + 0.12 * len(lines)), 0.2, (0.85, 0.9, 0.95))
            self.grow(x0, yb - 0.6, x0 + 0.9 + len(with_s) * gap, yb + 0.6)
            self.label(["entities with a series: tower height = series value / max over these series (%s%s), replayed across the whole playback"
                        % (fmt_num(gmax), (" " + unit) if unit else "")], (x0, yb - 0.8, 0.02), 0.24, (0.8, 0.85, 0.92), mode="flat", align="left")
            self.mapping.append("entity tower (has a series) = series value / max over entity series, replayed across the playback")
            yb += 3.0
        if no_s:
            vmax = max(float(e.get("value") or 0) for e in no_s) or 1.0
            per = max(1, int((W - 0.5) // 1.7))
            for i, e in enumerate(no_s):
                r, k = divmod(i, per)
                x, y = x0 + 0.9 + k * 1.7, yb + 0.6 + r * 2.4
                self.add("bar", "EP_%d" % i, loc=(x, y, 0.0), size=(0.42, 0.42, 0.15 + 1.5 * float(e.get("value") or 0) / vmax),
                         mat=dict(kind="pbr", rgb=(0.32, 0.5, 0.7), alpha=1.0, rough=0.5, emit=0.15), track=None)
                lines = wrap("%s. %s" % (e.get("rank", i + 1), e["label"]), 14)[:3] + [fmt_num(e.get("value"))]
                self.label(lines, (x, y - 0.45 - 0.11 * len(lines), 0.02), 0.19, (0.8, 0.86, 0.93), mode="flat")
                self.grow(x - 0.8, y - 1.1, x + 0.8, y + 0.4)
            self.label(["entities without a series: pillar height = value / max value (%s)" % fmt_num(vmax)],
                       (x0, yb - 0.1, 0.02), 0.24, (0.8, 0.85, 0.92), mode="flat", align="left")
            self.mapping.append("entity pillar (no series) = value / max value")
            yb += 0.6 + 2.4 * ((len(no_s) - 1) // per + 1)
        self.ent_end_y = yb

    # ---- title wall: banner, title, headline metrics, mapping legend, caveats
    def _wall(self):
        tr, src = self.tr, self.tr["source"]
        data = src.get("data") or {}
        ts = self.c["text_scale"]
        x0, x1 = min(self.bb[0], -1.0), max(self.bb[2], (len(self.layers) - 1) * self.dx + 1.0)
        W, xc = x1 - x0, (x0 + x1) / 2
        colw, xl, half, ls = 0.55 * W, x0 + 0.5, W / 2 - 0.7, 0.22
        origin = str(data.get("origin") or data.get("description") or "")
        dataset = re.split(r"\s*[\(,]", origin, maxsplit=1)[0] or str(src.get("title", ""))
        self.banner = "SYNTHETIC · generated data, not a real system" if self.syn else "REAL DATA · " + dataset
        title = wrap(src.get("title", ""), self.cap_chars(colw, 0.9))
        eng = src.get("engine") or {}
        sub = ["%s · %s %s" % (src.get("kind", ""), eng.get("name", ""), eng.get("version") or "")]
        sub += wrap("run %s · %s" % (src.get("run_id", ""), src.get("created_utc", "")), self.cap_chars(colw, 0.3))
        for pre, key in (("data: ", "description"), ("origin: ", "origin"), ("", "license_note")):
            if data.get(key):
                sub += wrap(pre + str(data[key]), self.cap_chars(colw, 0.3))
        om = data.get("omitted_by_rule")
        if om:
            sub += wrap("omitted by rule: %s titles - %s" % (om.get("count"), om.get("rule")), self.cap_chars(colw, 0.3))
        leg, nt = [], []
        for ln in ["MAPPING (derived values are scaled against the trace itself)"] + self.mapping_lines():
            leg += wrap(ln, self.cap_chars(half, ls))
        for ln in ["CAVEATS"] + list(tr.get("notes") or []) + [self.caption]:
            nt += wrap(ln, self.cap_chars(half, ls))
        band = max(len(leg), len(nt)) * ls * 1.15 * ts + 0.6                 # bottom band of the wall: legend | caveats
        head = 1.7 + len(title) * 0.9 * 1.25 * ts + 0.35 + len(sub) * 0.3 * 1.2 * ts + 0.3
        H = band + head                                                       # wall height follows its text
        yw = max(self.ymax_m + 5.0, self.ent_end_y + 2.5)
        yf = yw - 0.14
        self.add("plate", "WALL", loc=(xc, yw + 0.1, H / 2), size=(W, 0.1, H), mat=dict(kind="pbr", rgb=(0.05, 0.06, 0.09), alpha=1.0, rough=0.9, emit=0.0))
        self.add("plate", "BANNER", loc=(xc, yw - 0.02, H - 0.65), size=(W, 0.06, 1.3),
                 mat=dict(kind="pbr", rgb=(0.80, 0.30, 0.05) if self.syn else (0.08, 0.45, 0.25), alpha=1.0, rough=0.6, emit=0.35))
        self.label([self.banner], (xc, yf, H - 0.65), min(0.85, 0.92 * W / (0.56 * len(self.banner))), (1.0, 1.0, 1.0), mode="front")
        self.label(title, (xl, yf, H - 1.7), 0.9, (1.0, 1.0, 1.0), mode="front", align="left", valign="top")
        z = H - 1.7 - len(title) * 0.9 * 1.25 * ts - 0.35
        self.label(sub, (xl, yf, z), 0.3, (0.78, 0.84, 0.92), mode="front", align="left", valign="top")
        mets = [(k, v) for k, v in (tr.get("metrics") or {}).items() if isinstance(v, (int, float)) and not isinstance(v, bool) and k != "seed"]
        pref = ("bytes", "slot", "skew", "row", "record", "shuffle", "peak", "lag", "messages", "latency", "elapsed")
        mets.sort(key=lambda kv: 0 if any(p in kv[0].lower() for p in pref) else 1)
        self.shown_metrics = mets[:10]
        xr = x0 + colw + 0.6
        self.label([k for k, _ in self.shown_metrics], (xr, yf, H - 1.7), 0.34, (0.7, 0.78, 0.88), mode="front", align="left", valign="top")
        self.label([fmt_metric(k, v) for k, v in self.shown_metrics], (xr + 0.46 * (W - colw) - 0.2, yf, H - 1.7), 0.34, (1.0, 1.0, 1.0),
                   mode="front", align="left", valign="top")
        self.label(leg, (xl, yf, band - 0.2), ls, (0.75, 0.85, 0.75), mode="front", align="left", valign="top")
        self.label(nt, (xc + 0.3, yf, band - 0.2), ls, (1.0, 0.82, 0.55), mode="front", align="left", valign="top")
        flat = self.banner.split(" · ")[0] + ("" if self.syn else " · " + dataset)
        self.label([flat], (xc, self.flat_banner_y, 0.03), min(1.0, 0.9 * W / (0.56 * len(flat))), (1.0, 0.55, 0.2) if self.syn else (0.35, 0.95, 0.6), mode="flat")
        self.grow(x0, self.bb[1], x1, yw + 0.2)
        self.wall = dict(y=yw, H=H, W=W, xc=xc)

    def mapping_lines(self):
        lines = list(self.mapping)
        if self.tracer_mode:
            lines.append("tracer colours: " + ", ".join("%s=%d" % (k, n) for k, n in sorted(self.kind_counts.items())))
        return lines

    # ---- cameras and lights (specs only)
    @staticmethod
    def _fit(target, direction, corners, fov_deg, aspect=16 / 9, margin=0.94):
        """Smallest distance along `direction` (unit, target -> camera) at which all corners project inside the frame."""
        f = math.radians(fov_deg)
        th, tv = math.tan(f / 2), math.tan(f / 2) / aspect          # Blender: fov applies to the wide side
        fw = [-c for c in direction]                                  # camera looks along -direction
        up0 = (0.0, 0.0, 1.0) if abs(direction[2]) < 0.999 else (0.0, 1.0, 0.0)
        rx = (fw[1] * up0[2] - fw[2] * up0[1], fw[2] * up0[0] - fw[0] * up0[2], fw[0] * up0[1] - fw[1] * up0[0])
        n = math.sqrt(sum(c * c for c in rx))
        rx = tuple(c / n for c in rx)
        ru = (rx[1] * fw[2] - rx[2] * fw[1], rx[2] * fw[0] - rx[0] * fw[2], rx[0] * fw[1] - rx[1] * fw[0])
        dot = lambda a, b: sum(x * y for x, y in zip(a, b))
        lo, hi = 1.0, 400.0
        for _ in range(40):
            d = (lo + hi) / 2
            cam = tuple(target[i] + direction[i] * d for i in range(3))
            ok = True
            for c in corners:
                v = tuple(c[i] - cam[i] for i in range(3))
                z = dot(v, fw)
                if z <= 0.1 or abs(dot(v, rx)) / (z * th) > margin or abs(dot(v, ru)) / (z * tv) > margin:
                    ok = False
                    break
            lo, hi = (lo, d) if ok else (d, hi)
        return hi

    def _rig(self):
        x0, y0, x1, y1 = self.bb
        cx, cy, Hh = (x0 + x1) / 2, (y0 + y1) / 2, self.wall["H"]
        corners = [(x, y, z) for x in (x0, x1) for y in (y0, y1) for z in (0.0, Hh)]
        tgt = (cx, cy, 1.5)
        el, az = math.radians(33.0), math.radians(0.0)
        dv = (-math.sin(az) * math.cos(el), -math.cos(az) * math.cos(el), math.sin(el))
        d = self._fit(tgt, dv, corners, 50.0, margin=0.97)
        h = self.pos[self.hottest]
        ht = (h["x"], h["y"], h["sz"] * 0.5 + 0.8)
        topdir = (0.0, -0.03, 1.0)
        nrm = math.sqrt(sum(c * c for c in topdir))
        topdir = tuple(c / nrm for c in topdir)
        dtop = self._fit((cx, cy, 0.0), topdir, corners, 55.0, margin=0.97)
        self.cams = [
            dict(name="VP1_Overview", desc="Overview: the whole machine", loc=tuple(tgt[i] + dv[i] * d for i in range(3)), target=tgt, fov=50.0),
            dict(name="VP2_CloseUp_" + re.sub(r"\W", "_", self.hottest), desc="Close-up: hottest stage %s" % self.hottest,
                 loc=(ht[0] - 4.2, ht[1] - 7.0, ht[2] + 4.4), target=ht, fov=50.0),
            dict(name="VP3_Top", desc="Top view", loc=tuple((cx, cy, 0.0)[i] + topdir[i] * dtop for i in range(3)), target=(cx, cy, 0.0), fov=55.0),
        ]
        if self.tracer_mode:                                  # Kafka: a view of the inbox tray that piles up the most
            waits = {}
            for r in self.tracer_rows:
                if r["leave"] > r["arrive"] + 1e-9:
                    waits[r["C"]] = waits.get(r["C"], 0) + 1
            if waits:
                C = max(sorted(waits), key=lambda k: waits[k])
                tx, ty = self.tray[C]
                self.cams.append(dict(name="VP4_Inbox_" + re.sub(r"\W", "_", C), desc="Inbox tray of %s (messages wait here = consumer lag)" % C,
                                      loc=(tx - 1.2, ty - 3.4, 2.6), target=(tx, ty, 0.4), fov=50.0))
        self.lights = [dict(name="LI_key", energy=1.0, dir=(0.25, 0.55, -0.8), rgb=(1.0, 0.98, 0.95)),
                       dict(name="LI_fill", energy=0.55, dir=(-0.35, -0.45, -0.8), rgb=(0.75, 0.82, 1.0)),
                       dict(name="LI_top", energy=0.45, dir=(0.0, 0.05, -1.0), rgb=(1.0, 1.0, 1.0))]
        self.world_rgb = (0.018, 0.022, 0.035)

    def frame_to_t(self, frame):
        return min(max((frame - 1) / self.fpt, 0.0), self.D)


# ----------------------------------------------------------------------------- Blender side
def _registry():
    return bpy.app.driver_namespace.setdefault("x3d_trace_machines", {})


def _x3d_trace_frame_handler(scene, depsgraph=None):
    m = _registry().get(scene.name)
    if m is not None:
        try:
            m.apply(scene.frame_current)
        except ReferenceError:            # the scene's objects were deleted by the user
            _registry().pop(scene.name, None)


def _install_handler():
    hs = bpy.app.handlers.frame_change_pre
    for h in list(hs):
        if getattr(h, "__name__", "") == "_x3d_trace_frame_handler":
            hs.remove(h)
    hs.append(_x3d_trace_frame_handler)


class Machine:
    def __init__(self, model, scene, tag):
        self.model, self.scene, self.tag = model, scene, tag
        self.anim, self.created, self.labels, self.mats = [], [], {}, {}

    def apply(self, frame):
        t = self.model.frame_to_t(frame)
        for obj, tr in self.anim:
            loc, sc = tr.at(t)
            if loc is not None:
                obj.location = loc
            obj.scale = sc

    def destroy(self):
        """Remove everything this build created (its scene, objects, meshes, materials ...). Nothing else is touched."""
        reg = _registry()
        if reg.get(self.scene.name) is self:
            reg.pop(self.scene.name)
        try:
            bpy.data.scenes.remove(self.scene)
        except (ReferenceError, RuntimeError):
            pass
        for kind in ("objects", "meshes", "materials", "curves", "cameras", "lights", "collections", "worlds"):
            for k, idb in self.created:
                if k == kind:
                    try:
                        getattr(bpy.data, kind).remove(idb)
                    except (ReferenceError, RuntimeError):
                        pass


def _mesh_box_base():     # unit box, x/y in -0.5..0.5, z in 0..1 (scale z to grow it from the floor)
    v = [(-.5, -.5, 0), (.5, -.5, 0), (.5, .5, 0), (-.5, .5, 0), (-.5, -.5, 1), (.5, -.5, 1), (.5, .5, 1), (-.5, .5, 1)]
    return v, [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]


def _mesh_box_center():
    v, f = _mesh_box_base()
    return [(x, y, z - 0.5) for x, y, z in v], f


def _mesh_cyl_x(n=10):   # radius 1 around the x axis, x in 0..1, open ends (they sit inside the blocks)
    v = [(0.0, math.cos(2 * math.pi * i / n), math.sin(2 * math.pi * i / n)) for i in range(n)]
    v += [(1.0, y, z) for _, y, z in v]
    return v, [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)]


def _mesh_ico(sub=1):
    t = (1 + 5 ** 0.5) / 2
    v = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t), (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
    f = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8),
         (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)]
    nz = lambda p: tuple(c / math.sqrt(sum(q * q for q in p)) for c in p)
    v = [nz(p) for p in v]
    for _ in range(sub):
        cache, nf = {}, []

        def mid(a, b):
            k = (min(a, b), max(a, b))
            if k not in cache:
                cache[k] = len(v)
                v.append(nz(tuple((v[a][i] + v[b][i]) / 2 for i in range(3))))
            return cache[k]
        for a, b, c in f:
            ab, bc, ca = mid(a, b), mid(b, c), mid(c, a)
            nf += [(a, ab, ca), (b, bc, ab), (c, ca, bc), (ab, bc, ca)]
        f = nf
    return v, f


def _mesh_torus(R=1.0, r=0.03, nu=40, nv=6):
    v = [((R + r * math.cos(2 * math.pi * j / nv)) * math.cos(2 * math.pi * i / nu),
          (R + r * math.cos(2 * math.pi * j / nv)) * math.sin(2 * math.pi * i / nu), r * math.sin(2 * math.pi * j / nv))
         for i in range(nu) for j in range(nv)]
    f = [(i * nv + j, ((i + 1) % nu) * nv + j, ((i + 1) % nu) * nv + (j + 1) % nv, i * nv + (j + 1) % nv) for i in range(nu) for j in range(nv)]
    return v, f


def _material(mach, spec):
    key = (spec["kind"], tuple(round(x, 3) for x in spec["rgb"]), round(spec.get("alpha", 1.0), 2), round(spec.get("emit", 0.0), 2), round(spec.get("rough", 0.5), 2))
    m = mach.mats.get(key)
    if m is not None:
        return m
    m = bpy.data.materials.new("%s_M%02d" % (mach.tag, len(mach.mats) + 1))
    mach.created.append(("materials", m))
    nt = m.node_tree
    rgba = tuple(spec["rgb"]) + (1.0,)
    if spec["kind"] == "emit":
        nt.nodes.clear()
        em, out = nt.nodes.new("ShaderNodeEmission"), nt.nodes.new("ShaderNodeOutputMaterial")
        em.inputs["Color"].default_value = rgba
        em.inputs["Strength"].default_value = 1.0
        nt.links.new(em.outputs["Emission"], out.inputs["Surface"])
    else:
        p = next(n for n in nt.nodes if n.type == "BSDF_PRINCIPLED")
        p.inputs["Base Color"].default_value = rgba
        p.inputs["Roughness"].default_value = spec.get("rough", 0.5)
        p.inputs["Metallic"].default_value = 0.0
        p.inputs["Alpha"].default_value = spec.get("alpha", 1.0)
        if spec.get("emit", 0.0) > 0:
            p.inputs["Emission Color"].default_value = rgba
            p.inputs["Emission Strength"].default_value = spec["emit"]
        if spec.get("alpha", 1.0) < 1.0:
            try:
                m.surface_render_method = "BLENDED"
            except (AttributeError, TypeError):
                pass
    mach.mats[key] = m
    return m


def _quat_x_to(d):
    v = mathutils.Vector(d)
    if v.length < 1e-9:
        return mathutils.Quaternion()
    v.normalize()
    if v.x < -0.999999:
        return mathutils.Quaternion((0, 0, 0, 1))      # 180 degrees about z
    return mathutils.Vector((1, 0, 0)).rotation_difference(v)


def build(trace_path, live=True, **cfg):
    """Build the machine from a trace in a NEW scene; nothing else in the file is touched.
    cfg: any key of DEFAULTS (step, n_frames, amb_total, ...). live=True also makes the new scene the window's scene."""
    if bpy is None:
        raise RuntimeError("build() needs Blender (bpy)")
    with open(trace_path) as fh:
        trace = json.load(fh)
    tag = re.sub(r"\W", "_", os.path.basename(trace_path).split(".trace")[0])[:24]
    return build_from_trace(trace, tag, live=live, **cfg)


def build_from_trace(trace, tag, live=True, **cfg):
    model = Model(trace, **cfg)
    scene = bpy.data.scenes.new(tag)
    m = Machine(model, scene, tag)
    m.created.append(("scenes", scene))
    coll = bpy.data.collections.new(tag + "_machine")
    m.created.append(("collections", coll))
    scene.collection.children.link(coll)
    scene.frame_start, scene.frame_end, scene.frame_current = 1, model.nf, 1
    scene.render.fps, scene.render.fps_base = model.fps, 1.0
    scene.render.resolution_x, scene.render.resolution_y = 1280, 720
    scene["x3d_trace_run"] = trace["source"].get("run_id", tag)
    scene["x3d_trace_synthetic"] = bool(model.syn)
    world = bpy.data.worlds.new(tag + "_world")
    m.created.append(("worlds", world))
    world.color = model.world_rgb
    if world.node_tree:
        for n in world.node_tree.nodes:
            if n.type == "BACKGROUND":
                n.inputs["Color"].default_value = tuple(model.world_rgb) + (1.0,)
                n.inputs["Strength"].default_value = 1.0
    scene.world = world
    meshes = {}

    def mesh(name, geo):
        if name not in meshes:
            me = bpy.data.meshes.new("%s_%s" % (tag, name))
            v, f = geo()
            me.from_pydata(v, [], f)
            me.update()
            me.materials.append(None)               # one slot; every object links its own material to it (OBJECT link)
            meshes[name] = me
            m.created.append(("meshes", me))
        return meshes[name]

    def new_obj(name, data):
        o = bpy.data.objects.new(name, data)
        coll.objects.link(o)
        m.created.append(("objects", o))
        return o
    geos = dict(block=("box_base", _mesh_box_base), bar=("box_base", _mesh_box_base), plate=("box_center", _mesh_box_center),
                tube=("cyl_x", _mesh_cyl_x), particle=("ico", _mesh_ico), ring=("torus", _mesh_torus))
    for it in model.items:
        k = it["kind"]
        if k == "label":
            _make_label(m, it, new_obj)
            continue
        o = new_obj(it["name"], mesh(*geos[k]))
        o.material_slots[0].link = "OBJECT"
        o.material_slots[0].material = _material(m, it["mat"])
        if k == "tube":
            p0, p1 = mathutils.Vector(it["p0"]), mathutils.Vector(it["p1"])
            o.location = p0
            o.rotation_mode = "QUATERNION"
            o.rotation_quaternion = _quat_x_to(p1 - p0)
            o.scale = ((p1 - p0).length, it["r"], it["r"])
        elif k in ("block", "bar", "plate"):
            o.location, o.scale = it["loc"], it["size"]
        if it.get("track") is not None:
            m.anim.append((o, it["track"]))
    for cm in model.cams:
        cd = bpy.data.cameras.new(cm["name"])
        m.created.append(("cameras", cd))
        cd.lens_unit, cd.angle = "FOV", math.radians(cm["fov"])
        cd.clip_start, cd.clip_end = 0.1, 500.0
        o = new_obj(cm["name"], cd)
        o.location = cm["loc"]
        o.rotation_mode = "QUATERNION"
        o.rotation_quaternion = (mathutils.Vector(cm["target"]) - mathutils.Vector(cm["loc"])).to_track_quat("-Z", "Y")
        o["x3d_viewpoint_description"] = cm["desc"]
        if cm["name"].startswith("VP1"):
            scene.camera = o
    for lg in model.lights:
        ld = bpy.data.lights.new(lg["name"], "SUN")
        m.created.append(("lights", ld))
        ld.energy, ld.color = lg["energy"], lg["rgb"]
        o = new_obj(lg["name"], ld)
        o.location = (0, 0, 20)
        o.rotation_mode = "QUATERNION"
        o.rotation_quaternion = mathutils.Vector(lg["dir"]).to_track_quat("-Z", "Y")
    _install_handler()
    _registry()[scene.name] = m
    scene.frame_set(1)
    m.apply(1)
    if live and bpy.context.window is not None:
        bpy.context.window.scene = scene
    return m


def _make_label(m, it, new_obj):
    """A label = an EMPTY (exported as a Transform; the X3D writer turns it into a Text node) plus a FONT twin for the
    Blender view (the X3D exporter would turn FONT objects into heavy meshes, so the twin is not exported)."""
    n = it["name"]
    e = new_obj(n, None)
    e.empty_display_type, e.empty_display_size = "PLAIN_AXES", 0.05
    cu = bpy.data.curves.new(n + "_c", "FONT")
    m.created.append(("curves", cu))
    cu.body = "\n".join(it["lines"])
    cu.size = it["size"]
    cu.align_x = {"center": "CENTER", "left": "LEFT", "right": "RIGHT"}[it["align"]]
    cu.align_y = {"center": "CENTER", "top": "TOP"}[it["valign"]]
    cu.space_line = 1.15
    tw = new_obj(n + "_f", cu)
    tw["x3d_skip"] = True
    tw.data.materials.append(_material(m, dict(kind="emit", rgb=it["rgb"])))
    e.location = tw.location = it["loc"]
    if it["mode"] in ("front", "billboard"):
        tw.rotation_euler = (math.pi / 2, 0, 0)          # upright, readable from -Y
    if it["mode"] == "front":
        e.rotation_euler = (math.pi / 2, 0, 0)
    m.labels[re.sub(r"\W", "_", e.name)] = it      # key = the DEF suffix the exporter will use (Blender may have renamed the object)


# ----------------------------------------------------------------------------- X3D export
def _text_xml(spec):
    lines = [re.sub(r"[\"'\\]", lambda mo: {"\"": "″", "'": "’", "\\": "/"}[mo.group()], l) for l in spec["lines"]]
    s = " ".join('"%s"' % _xesc(l) for l in lines)
    major = {"center": "MIDDLE", "left": "BEGIN", "right": "END"}[spec["align"]]
    minor = {"center": "MIDDLE", "top": "BEGIN"}[spec["valign"]]
    r, g, b = spec["rgb"]
    shape = ('<Shape><Appearance><UnlitMaterial emissiveColor="%.3f %.3f %.3f"/></Appearance>'
             "<Text string='%s'><FontStyle family='\"SANS\"' size=\"%.3f\" spacing=\"1.15\" justify='\"%s\" \"%s\"'/></Text></Shape>"
             % (r, g, b, s, spec["size"], major, minor))
    return '<Billboard axisOfRotation="0 0 0">%s</Billboard>' % shape if spec["mode"] == "billboard" else shape


def inject_text(path, labels):
    """Replace each label empty's (child-less) Transform content by a Text node (Billboard for 'billboard' labels)."""
    with open(path, encoding="utf-8") as fh:
        s = fh.read()
    n = 0
    for name, spec in labels.items():
        pat = re.compile(r'(<Transform DEF="OB_%s"[^>]*?)(?:/>|>\s*</Transform>)' % re.escape(name))
        s, k = pat.subn(lambda mo: mo.group(1) + ">" + _text_xml(spec) + "</Transform>", s, count=1)
        n += k
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(s)
    return n


def _ff(v, nd=5):
    t = ("%.*f" % (nd, v)).rstrip("0").rstrip(".")
    return "0" if t in ("", "-0") else t


def _simplify(keys, vals, eps):
    """Drop keys whose value is within eps of the linear interpolation between the kept neighbours (exact for X3D
    interpolators, which are linear in the key fraction). Returns the indices that stay."""
    n = len(keys)
    if n <= 2:
        return list(range(n))
    keep = [False] * n
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        a, b = stack.pop()
        if b - a < 2:
            continue
        ta, tb, va, vb = keys[a], keys[b], vals[a], vals[b]
        worst, wi = -1.0, -1
        for i in range(a + 1, b):
            u = (keys[i] - ta) / (tb - ta) if tb > ta else 0.0
            err = max(abs(vals[i][d] - (va[d] + (vb[d] - va[d]) * u)) for d in range(len(va)))
            if err > worst:
                worst, wi = err, i
        if worst > eps:
            keep[wi] = True
            stack += [(a, wi), (wi, b)]
    return [i for i in range(n) if keep[i]]


def compact_x3d(path, eps=1e-4):
    """Lossless-within-eps shrink of the exporter's interpolators: constant-rotation OrientationInterpolators (float
    noise from the matrix decomposition) and constant channels are removed with their ROUTEs, collinear keys are dropped
    and numbers are written with 5 decimals. Returns before/after statistics."""
    with open(path, encoding="utf-8") as fh:
        s = fh.read()
    before = len(s.encode("utf-8"))
    pat = re.compile(r'[ \t]*<(Position|Orientation)Interpolator DEF="([^"]+)" key="([^"]*)" keyValue="([^"]*)" />\n')
    dropped, st = set(), dict(interpolators=0, dropped_constant=0, keys_before=0, keys_after=0)

    def repl(mo):
        kind, name = mo.group(1), mo.group(2)
        dim = 3 if kind == "Position" else 4
        keys = [float(x) for x in mo.group(3).split()]
        flat = [float(x) for x in mo.group(4).split()]
        vals = [tuple(flat[i * dim:(i + 1) * dim]) for i in range(len(keys))]
        st["interpolators"] += 1
        st["keys_before"] += len(keys)
        if max(max(v[d] for v in vals) - min(v[d] for v in vals) for d in range(dim)) <= (1e-5 if kind == "Orientation" else eps):
            dropped.add(name)
            st["dropped_constant"] += 1
            return ""
        idx = _simplify(keys, vals, eps) if kind == "Position" else list(range(len(keys)))
        st["keys_after"] += len(idx)
        return '    <%sInterpolator DEF="%s" key="%s" keyValue="%s" />\n' % (
            kind, name, " ".join(_ff(keys[i], 7) for i in idx), " ".join(_ff(c) for i in idx for c in vals[i]))
    s = pat.sub(repl, s)
    if dropped:
        s = "\n".join(ln for ln in s.split("\n") if not (ln.lstrip().startswith("<ROUTE") and any('"%s"' % d in ln for d in dropped)))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(s)
    st.update(bytes_before=before, bytes_after=len(s.encode("utf-8")))
    return st


def export_x3d(mach, path, title=None, compact=True):
    """Write the machine as animated X3D 4.0 with the x3d_blender_io add-on (animation_step = the step it was built for),
    then swap label empties for Text nodes."""
    import addon_utils
    sc, step = mach.scene, int(mach.model.c["step"])
    try:
        addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)
    except Exception:
        pass
    vl = sc.view_layers[0]
    for o in sc.objects:
        o.select_set(not o.get("x3d_skip"), view_layer=vl)
    win = bpy.context.window
    prev = win.scene if win is not None else None
    if win is not None:
        win.scene = sc
    try:
        with bpy.context.temp_override(scene=sc, view_layer=vl):
            r = bpy.ops.export_scene.x3d(
                filepath=path, check_existing=False, x3d_version="X3D40", use_selection=True, use_visible=False,
                use_mesh_modifiers=False, use_animation=True, animation_step=step, use_hierarchy=True, use_normals=False,
                global_scale=1.0, axis_forward="-Z", axis_up="Y", batch_mode="OFF",
                meta_title=title or mach.model.tr["source"].get("title", ""),
                meta_description=("SYNTHETIC trace " if mach.model.syn else "REAL DATA trace ") + str(mach.model.tr["source"].get("run_id", "")),
                meta_creator="trace_to_scene.py")
    finally:
        if win is not None and prev is not None and prev.name != sc.name:
            win.scene = prev
    if r != {"FINISHED"}:
        raise RuntimeError("X3D export failed: %s" % r)
    raw = os.path.getsize(path)
    n_text = inject_text(path, mach.labels)
    comp = compact_x3d(path) if compact else None
    return dict(path=path, bytes=os.path.getsize(path), raw_exporter_bytes=raw, text_nodes=n_text, labels=len(mach.labels), step=step, compact=comp)


def particle_bytes(path):
    """Bytes of the file that belong to ambient/tracer carriers (their interpolators and routes)."""
    tot = 0
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            if re.search(r'(DEF="[PS]I_(AMB|TRC)_|(fromNode|toNode)="(PI|SI|OB)_(AMB|TRC)_)', line):
                tot += len(line.encode("utf-8"))
    return tot


# ----------------------------------------------------------------------------- headless driver
def _fresh_blender():
    import addon_utils
    bpy.ops.wm.read_factory_settings(use_empty=True)
    addon_utils.enable("bl_ext.user_default.x3d_blender_io", default_set=False)


def export_fit(trace_path, out_x3d, max_kb=900, out_blend=None, log=print, compact=True, **cfg):
    """Headless: build + export, shrinking ambient particles and then raising animation_step until the file fits max_kb.
    Returns (machine, report). Resets the Blender session before every attempt (headless only)."""
    budget = max_kb * 1024
    amb0 = cfg.pop("amb_total", None) or DEFAULTS["amb_total"]
    step0 = cfg.pop("step", None) or DEFAULTS["step"]
    attempts, result = [], None
    for step in [s for s in (1, 2, 3, 4, 6, 8, 12) if s >= step0] or [step0]:
        amb = amb0
        for _ in range(3):
            _fresh_blender()
            m = build(trace_path, live=False, step=step, amb_total=amb, **cfg)
            info = export_x3d(m, out_x3d, compact=compact)
            pb = particle_bytes(out_x3d)
            ncar = sum(1 for it in m.model.items if it["kind"] == "particle")
            amb_n, trc_n = m.model.stats["ambient_particles"], m.model.stats["tracer_carriers"]
            attempts.append(dict(step=step, amb_total=amb, ambient_particles=amb_n, tracer_carriers=trc_n,
                                 bytes=info["bytes"], kb=round(info["bytes"] / 1024, 1)))
            log("attempt step=%d amb_total=%d -> %.1f KB (%d ambient, %d tracer carriers)" % (step, amb, info["bytes"] / 1024, amb_n, trc_n))
            if info["bytes"] <= budget:
                result = (m, info, step, amb)
                break
            per = pb / max(ncar, 1)
            room = int((budget * 0.97 - (info["bytes"] - per * ncar) - per * trc_n) / per) if per > 0 else 0
            if amb_n <= 0 or room < 20 or room >= amb_n:
                break                                    # shrinking ambient cannot fix it: go to a coarser step
            amb = max(int(amb * room / amb_n), 1)
        if result:
            break
    if not result:
        raise RuntimeError("could not fit %d KB: %s" % (max_kb, attempts))
    m, info, step, amb = result
    md = m.model
    rep = dict(trace=os.path.basename(trace_path), x3d=out_x3d, kb=round(info["bytes"] / 1024, 1), bytes=info["bytes"], step=step,
               keys=len(range(1, md.nf + 1, step)) + (0 if (md.nf - 1) % step == 0 else 1), frames=md.nf, fps=md.fps,
               amb_total_requested=amb0, amb_total_used=amb, text_nodes=info["text_nodes"], attempts=attempts, banner=md.banner,
               objects_exported=sum(1 for o in m.scene.objects if not o.get("x3d_skip")), hottest=md.hottest,
               shown_metrics=[k for k, _ in md.shown_metrics], mapping=md.mapping_lines(), caption=md.caption, stats=md.stats,
               duration=md.D, playback_s=md.pb, particle_bytes=particle_bytes(out_x3d), viewpoints=[c['name'] for c in md.cams],
               compact=info['compact'], raw_exporter_bytes=info['raw_exporter_bytes'])
    if out_blend:
        _save_blend(m, trace_path, out_blend)
        rep["blend"] = out_blend
    return m, rep


def _save_blend(mach, trace_path, out_blend):
    """Keep this script and the trace inside the .blend so attach_saved() can re-create the animation handler after opening it."""
    for nm, src in (("trace_to_scene.py", globals().get("__file__")), (os.path.basename(trace_path), trace_path)):
        if src and os.path.exists(src):
            bpy.data.texts.new(nm).from_string(open(src, encoding="utf-8").read())
    mach.scene["x3d_trace_text"] = os.path.basename(trace_path)
    mach.scene["x3d_trace_cfg"] = json.dumps(mach.model.c)
    os.makedirs(os.path.dirname(os.path.abspath(out_blend)), exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=out_blend, check_existing=False)


def attach_saved(scene=None):
    """After opening a saved .blend: run its 'trace_to_scene.py' text, then call attach_saved() to re-create the frame handler
    (the machine is rebuilt from the stored trace text; objects are matched by name)."""
    scene = scene or bpy.context.scene
    trace = json.loads(bpy.data.texts[scene["x3d_trace_text"]].as_string())
    model = Model(trace, **json.loads(scene["x3d_trace_cfg"]))
    m = Machine(model, scene, scene.name)
    for it in model.items:
        o = bpy.data.objects.get(it["name"])
        if o is not None and it.get("track") is not None:
            m.anim.append((o, it["track"]))
    _install_handler()
    _registry()[scene.name] = m
    scene.frame_set(scene.frame_current)
    return m


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(prog="trace_to_scene")
    ap.add_argument("--trace", required=True)
    ap.add_argument("--out-x3d", required=True)
    ap.add_argument("--out-blend")
    ap.add_argument("--max-kb", type=float, default=900)
    ap.add_argument("--report-json")
    ap.add_argument("--frames", type=int, default=DEFAULTS["n_frames"])
    ap.add_argument("--step", type=int, default=DEFAULTS["step"])
    ap.add_argument("--amb", type=int, default=DEFAULTS["amb_total"])
    ap.add_argument("--no-compact", action="store_true", help="skip the lossless-within-1e-4 interpolator compaction (raw exporter output)")
    a = ap.parse_args(argv)
    os.makedirs(os.path.dirname(os.path.abspath(a.out_x3d)), exist_ok=True)
    m, rep = export_fit(a.trace, a.out_x3d, a.max_kb, a.out_blend, n_frames=a.frames, step=a.step, amb_total=a.amb, compact=not a.no_compact)
    print("RESULT %.1f KB (limit %g) step=%d ambient=%d tracers=%d carriers=%d -> %s" % (
        rep["kb"], a.max_kb, rep["step"], rep["stats"]["ambient_particles"], rep["stats"]["tracers"], rep["stats"]["tracer_carriers"], a.out_x3d))
    if a.report_json:
        with open(a.report_json, "w") as fh:
            json.dump(rep, fh, indent=1, default=str)


if bpy is not None and "--trace" in sys.argv and "--out-x3d" in sys.argv:
    main(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:])
