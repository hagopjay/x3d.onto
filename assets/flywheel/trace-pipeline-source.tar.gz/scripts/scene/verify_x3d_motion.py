#!/usr/bin/env python3
"""Check that the exported X3D reproduces what the frame handler computes from the trace.
Rebuilds the pure-python Model with the cfg recorded in the build report, evaluates every animated track at every frame and
compares it with the exported interpolators (linear interpolation, as any X3D browser does) or, where the exporter/compaction
removed a constant interpolator, with the Transform's static translation/scale.
usage: python3 verify_x3d_motion.py TRACE.json SCENE.x3d BUILD_REPORT.json"""
import importlib.util, json, math, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("tts", os.path.join(HERE, "trace_to_scene.py"))
tts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tts)


def lin(keys, vals, f):
    import bisect
    i = bisect.bisect_right(keys, f)
    if i <= 0:
        return vals[0]
    if i >= len(keys):
        return vals[-1]
    u = (f - keys[i - 1]) / (keys[i] - keys[i - 1]) if keys[i] > keys[i - 1] else 0.0
    return tuple(a + (b - a) * u for a, b in zip(vals[i - 1], vals[i]))


def main(trace_path, x3d_path, rep_path):
    trace = json.load(open(trace_path))
    rep = json.load(open(rep_path))
    model = tts.Model(trace, step=rep["step"], amb_total=rep["amb_total_used"], n_frames=rep["frames"])
    s = open(x3d_path, encoding="utf-8").read()
    interp = {}
    for m in re.finditer(r'<PositionInterpolator DEF="(PI|SI)_(\w+)" key="([^"]*)" keyValue="([^"]*)"', s):
        keys = [float(x) for x in m.group(3).split()]
        flat = [float(x) for x in m.group(4).split()]
        interp[(m.group(1), m.group(2))] = (keys, [tuple(flat[i * 3:(i + 1) * 3]) for i in range(len(keys))])
    xf = {}
    for m in re.finditer(r'<Transform DEF="OB_(\w+)" translation="([^"]*)" rotation="[^"]*" scale="([^"]*)"', s):
        xf[m.group(1)] = (tuple(float(x) for x in m.group(2).split()), tuple(float(x) for x in m.group(3).split()))
    nf = model.nf
    worst = {"translation": 0.0, "scale": 0.0}
    checked = {"animated_objects": 0, "with_interp": 0, "static_ok": 0}
    worst_obj = {}
    for it in model.items:
        tr = it.get("track")
        if tr is None:
            continue
        name = it["name"]
        if name not in xf:
            print("MISSING Transform for", name)
            return 1
        checked["animated_objects"] += 1
        t0, s0 = xf[name]
        for frame in range(1, nf + 1):
            f = (frame - 1) / (nf - 1)
            loc, sc = tr.at(f * model.D)
            if loc is not None and max(sc) > 1e-4:                  # a hidden object's position is not visible
                want = (loc[0], loc[2], -loc[1])                         # Blender Z-up -> X3D Y-up
                got = lin(*interp[("PI", name)], f) if ("PI", name) in interp else t0
                e = max(abs(a - b) for a, b in zip(want, got))
                if e > worst["translation"]:
                    worst["translation"], worst_obj["translation"] = e, (name, frame)
            got = lin(*interp[("SI", name)], f) if ("SI", name) in interp else s0
            e = max(abs(a - b) for a, b in zip(sc, got))
            if e > worst["scale"]:
                worst["scale"], worst_obj["scale"] = e, (name, frame)
        if ("PI", name) in interp or ("SI", name) in interp:
            checked["with_interp"] += 1
        else:
            checked["static_ok"] += 1
    out = dict(checked=checked, max_abs_error=worst, worst=worst_obj, frames=nf, tolerance="<= 5e-4 expected (simplification eps 1e-4 + rounding)", note="hidden objects (scale ~0) are skipped for translation")
    print(json.dumps(out))
    return 0 if max(worst.values()) <= 5e-4 else 2


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
