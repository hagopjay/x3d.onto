#!/usr/bin/env python3
"""Numbers for the render check: are the X_ITE screenshots non-blank, and do the timestamps differ from each other?
usage: python3 image_stats.py OUT_DIR PREFIX   (reads PREFIX-t??.png and PREFIX.render.json, writes PREFIX.render-stats.json)"""
import glob, itertools, json, os, sys
import numpy as np
from PIL import Image


def load(p):
    return np.asarray(Image.open(p).convert("RGB")).astype(np.int16)


def main(out_dir, prefix):
    files = sorted(glob.glob(os.path.join(out_dir, prefix + "-t??.png")))
    imgs = {os.path.basename(f): load(f) for f in files}
    stats = {"shots": {}, "pairs": {}}
    for name, a in imgs.items():
        bg = np.median(a[:8, :8].reshape(-1, 3), axis=0)                        # background colour from the corner
        diff_bg = np.abs(a - bg).max(axis=2)
        stats["shots"][name] = dict(size=list(a.shape[1::-1]), non_background_pct=round(float((diff_bg > 12).mean() * 100), 2),
                                    luminance_std=round(float(a.mean(axis=2).std()), 2),
                                    distinct_colours=int(len(np.unique(a.reshape(-1, 3), axis=0))))
    for (n1, a), (n2, b) in itertools.combinations(imgs.items(), 2):
        d = np.abs(a - b).max(axis=2)
        stats["pairs"][n1 + " vs " + n2] = dict(mean_abs_diff=round(float(np.abs(a - b).mean()), 3), changed_pixels_pct=round(float((d > 16).mean() * 100), 3))
    fa, fb = os.path.join(out_dir, prefix + "-free-a.png"), os.path.join(out_dir, prefix + "-free-b.png")
    if os.path.exists(fa) and os.path.exists(fb):
        a, b = load(fa), load(fb)
        d = np.abs(a - b).max(axis=2)
        stats["free_running_timesensor"] = dict(mean_abs_diff=round(float(np.abs(a - b).mean()), 3), changed_pixels_pct=round(float((d > 16).mean() * 100), 3))
    rj = os.path.join(out_dir, prefix + ".render.json")
    if os.path.exists(rj):
        r = json.load(open(rj))
        stats["probes"] = r.get("probes")
        stats["fractions"] = r.get("fracs")
        stats["console"] = r.get("logs")
        stats["webgl"] = r.get("webgl")
    ok = all(s["non_background_pct"] > 2 and s["luminance_std"] > 3 for s in stats["shots"].values()) and \
        all(p["changed_pixels_pct"] > 0.2 for p in stats["pairs"].values()) and len(imgs) >= 3
    free = stats.get("free_running_timesensor", {}).get("changed_pixels_pct", 0) > 0.05
    stats["verdict"] = ("PASS: 3+ timestamps, all non-blank, all pairwise different" + ("; free-running TimeSensor playback also changes the picture" if free else "; WARNING free-running playback did not change the picture")) if ok else "FAIL"
    json.dump(stats, open(os.path.join(out_dir, prefix + ".render-stats.json"), "w"), indent=1)
    print(json.dumps(stats["shots"]), "\n", json.dumps(stats["pairs"]), "\n", stats["verdict"], "\n", json.dumps(stats.get("probes"))[:600])


main(*sys.argv[1:3])
