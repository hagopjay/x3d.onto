#!/usr/bin/env python3
"""Audit: every number that appears in a Text node of the X3D must be a value found in the trace (allowing the display rounding of
fmt_num / fmt_metric). Numbers that are not found are listed so they can be classified (derived: counts, tick labels, ratios).
usage: python3 audit_numbers.py TRACE.json SCENE.x3d"""
import json, re, sys


def leaves(o, out):
    if isinstance(o, bool) or o is None:
        return
    if isinstance(o, (int, float)):
        out.append(float(o))
    elif isinstance(o, dict):
        for v in o.values():
            leaves(v, out)
    elif isinstance(o, list):
        out.append(float(len(o)))
        for v in o:
            leaves(v, out)


UNIT = {"TB": 1e12, "GB": 1e9, "MB": 1e6, "kB": 1e3, "B": 1, "k": 1e3, "M": 1e6, "G": 1e9}


def main(trace_path, x3d_path):
    tr = json.load(open(trace_path))
    vals = []
    leaves({k: v for k, v in tr.items()}, vals)
    vals = sorted(set(vals))
    for e in tr.get("entities", []):                       # per-entity series maxima are shown as "max" values
        if e.get("series"):
            vals.append(float(max(e["series"]["v"])))
    for ch in (tr.get("series") or {}).get("channels", {}).values():
        vals.append(float(max(ch)))
    vals.append(float(tr["time"]["duration"]))
    s = open(x3d_path, encoding="utf-8").read()
    texts = re.findall(r"<Text string='([^']*)'", s)
    tokens = []
    for t in texts:
        for line in re.findall(r'"([^"]*)"', t):
            for m in re.finditer(r"(?<![\w.])(-?\d[\d,]*(?:\.\d+)?(?:e[+-]?\d+)?)\s*(TB|GB|MB|kB|B|k|M|G)?(?![\w])", line):
                tokens.append((m.group(0).strip(), m.group(1), m.group(2), line))
    matched, unmatched = 0, []
    for raw, num, unit, line in tokens:
        v = float(num.replace(",", "")) * UNIT.get(unit or "", 1.0)
        tol = max(1e-9, 0.006 * abs(v), 0.5 * 10 ** -(len(num.split(".")[1]) if "." in num else 0) * UNIT.get(unit or "", 1.0))
        if any(abs(x - v) <= tol for x in vals):
            matched += 1
        else:
            unmatched.append((raw, line[:70]))
    print(json.dumps(dict(text_nodes=len(texts), numeric_tokens=len(tokens), matched_in_trace=matched, unmatched=len(unmatched))))
    seen = set()
    for raw, line in unmatched:
        if (raw, line) not in seen:
            seen.add((raw, line))
            print("  not in trace:", raw, "|", line)


main(*sys.argv[1:3])
