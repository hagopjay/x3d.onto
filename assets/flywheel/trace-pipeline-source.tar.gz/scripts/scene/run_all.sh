#!/bin/bash
# Rebuild both scenes from their traces and run every check. Writes scenes/*.x3d|.blend and out/scene/*.
# Needs: Blender 5.1 with the x3d_blender_io add-on, the x3d_mcp venv, node + playwright (NODE_PATH), a local Chromium, and the
# pinned X_ITE 16.4.3 dist dir (fetch once with:  mkdir /tmp/xite-pack && cd /tmp/xite-pack && npm pack x_ite@16.4.3 && mkdir pkg && tar -xzf x_ite-16.4.3.tgz -C pkg).
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
BLENDER=${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}
MCPPY=${MCPPY:-$HOME/Projects/x3d/x3d_mcp/.venv/bin/python}
export NODE_PATH=${NODE_PATH:-/tmp/node_modules}
export CHROME_PATH=${CHROME_PATH:-$HOME/Library/Caches/ms-playwright/chromium-1155/chrome-mac/Chromium.app/Contents/MacOS/Chromium}
export XITE_DIST=${XITE_DIST:-/tmp/xite-pack/pkg/package/dist}
[ -f "$XITE_DIST/x_ite.min.js" ] || { echo "X_ITE dist missing: $XITE_DIST"; exit 1; }
LOG=out/scene/checks.log; mkdir -p out/scene scenes; : > $LOG
rm -f out/scene/*.png out/scene/*.render*.json
frac_for() { case "$1" in kafka-gossip) echo 0.2,0.66,0.9;; bq-wikipedia) echo 0.25,0.6,0.9;; *) echo 0.2,0.6,0.9;; esac; }
for N in ${@:-kafka-gossip bq-wikipedia}; do
  T=traces/$N.trace.json
  echo "=== $N: build" | tee -a $LOG
  $BLENDER -b --factory-startup -noaudio --python scripts/scene/trace_to_scene.py -- --trace $T --out-x3d scenes/$N.x3d --out-blend scenes/$N.blend --report-json out/scene/$N.build.json 2>&1 | grep -E "attempt|RESULT|Error|Traceback" | tee -a $LOG
  rm -f scenes/$N.blend1
  echo "=== $N: x3d_mcp validate" | tee -a $LOG
  $MCPPY scripts/scene/validate_x3d_mcp.py scenes/$N.x3d 2>&1 | grep -E "validate_x3d:|Found" | cut -c1-300 | tee -a $LOG
  echo "=== $N: exported motion vs trace tracks (every frame)" | tee -a $LOG
  python3 scripts/scene/verify_x3d_motion.py $T scenes/$N.x3d out/scene/$N.build.json | tee -a $LOG
  echo "=== $N: numbers shown vs trace" | tee -a $LOG
  python3 scripts/scene/audit_numbers.py $T scenes/$N.x3d | tee -a $LOG
  echo "=== $N: X_ITE render check" | tee -a $LOG
  VPS=$(python3 -c "import json;r=json.load(open('out/scene/$N.build.json'));print(' '.join(['CA_'+v+('@0.66' if 'Inbox' in v else '') for v in r['viewpoints'][1:]]))")
  node scripts/scene/render_check.js scenes/$N.x3d out/scene/$N $(frac_for $N) $VPS 2>&1 | tail -1 | cut -c1-400 | tee -a $LOG
  python3 scripts/scene/image_stats.py out/scene $N | tail -2 | cut -c1-500 | tee -a $LOG
  echo "=== $N: saved .blend re-attach" | tee -a $LOG
  $BLENDER -b --factory-startup -noaudio --python scripts/scene/test_blend_reattach.py -- scenes/$N.blend 2>&1 | grep -E "REATTACH_TEST|Traceback" | tee -a $LOG
  echo "=== $N: Blender-side frame (EEVEE)" | tee -a $LOG
  $BLENDER -b --factory-startup -noaudio --python scripts/scene/blender_frame.py -- scenes/$N.blend out/scene/$N-blender-f240.png 240 2>&1 | grep -E "BLENDER_FRAME_OK|Traceback" | tee -a $LOG
  echo "=== $N: live-mode sandbox test" | tee -a $LOG
  $BLENDER -b --factory-startup -noaudio --python scripts/scene/test_live_mode.py -- $T 2>&1 | grep -E "LIVE_TEST|Traceback" | cut -c1-700 | tee -a $LOG
done
rm -rf scripts/scene/__pycache__
echo done | tee -a $LOG
