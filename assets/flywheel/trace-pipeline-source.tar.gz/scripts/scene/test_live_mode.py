"""Simulates how the parent drives the builder inside an ALREADY RUNNING Blender (in a throw-away headless Blender that has the
default startup scene): run the file text with exec, build(live=True) twice, check nothing else is touched, animation moves
objects, export works from the live scene, and destroy() removes exactly what the build created.
  Blender -b --factory-startup -noaudio --python scripts/scene/test_live_mode.py -- TRACE.json"""
import sys, json, os, bpy
trace = sys.argv[sys.argv.index("--") + 1]
here = os.path.dirname(os.path.abspath(__file__))
ns = {"__name__": "__main__"}                      # like pasting the script into the Blender MCP / Text editor
exec(open(os.path.join(here, "trace_to_scene.py")).read(), ns)
before = dict(objects=sorted(o.name for o in bpy.data.objects), scenes=sorted(s.name for s in bpy.data.scenes),
              meshes=len(bpy.data.meshes), materials=len(bpy.data.materials), cube_loc=tuple(bpy.data.objects["Cube"].location),
              handlers=len(bpy.app.handlers.frame_change_pre))
m1 = ns["build"](trace, live=True)
m2 = ns["build"](trace, live=True)                   # re-running must not stack handlers or touch the first build
res = {}
res["original_objects_intact"] = all(n in bpy.data.objects for n in before["objects"]) and tuple(bpy.data.objects["Cube"].location) == before["cube_loc"]
res["scenes_now"] = sorted(s.name for s in bpy.data.scenes)
res["new_scenes_only_added"] = set(before["scenes"]) <= set(res["scenes_now"]) and len(res["scenes_now"]) == len(before["scenes"]) + 2
res["window_scene"] = bpy.context.window.scene.name if bpy.context.window else None
hs = [h for h in bpy.app.handlers.frame_change_pre if getattr(h, "__name__", "") == "_x3d_trace_frame_handler"]
res["handlers_ours"] = len(hs)
# animation: pick a tracer/ambient carrier and a bar, move the frame, expect changes
sc = m2.scene
bpy.context.window.scene = sc
names = [o.name for o, _ in m2.anim if o.name.startswith(("TRC_", "AMB_", "BR_", "CURSOR"))][:40]
seen = {}
for fr in (1, 60, 150, 250, 330):
    sc.frame_set(fr)
    for n in names:
        o = bpy.data.objects[n]
        seen.setdefault(n, set()).add((round(o.location.x, 3), round(o.location.y, 3), round(o.scale.z, 4)))
res["objects_that_changed_over_5_frames"] = sum(1 for v in seen.values() if len(v) > 1)
res["objects_checked"] = len(seen)
out = ns["export_x3d"](m2, "/tmp/live_test.x3d")
res["export_bytes"] = out["bytes"]
res["export_text_nodes"] = out["text_nodes"]
res["window_scene_after_export"] = bpy.context.window.scene.name
ids_before_destroy = len(bpy.data.objects)
m1.destroy(); m2.destroy()
res["after_destroy"] = dict(objects_equal=sorted(o.name for o in bpy.data.objects) == before["objects"], scenes_equal=sorted(s.name for s in bpy.data.scenes) == before["scenes"],
                            meshes=len(bpy.data.meshes), materials=len(bpy.data.materials), meshes_before=before["meshes"], materials_before=before["materials"])
print("LIVE_TEST " + json.dumps(res))
