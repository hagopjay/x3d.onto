#!/usr/bin/env python3
"""k8s_to_trace.py: a Kubernetes blueprint (YAML) -> traces/k8s-karate.trace.json (x3d-trace/1, kind 'k8s-blueprint', source.synthetic = TRUE).
Static analysis only (no cluster, no network, no kubectl): five really executed and timed stages parse -> index -> resolve -> lint -> budget.
The blueprint itself is AUTHORED (scripts/infra/make_blueprint.py) and says so on the scene; only its hashes/hyper-parameters come from the real Stage-1 run.
usage: python3 scripts/adapters/k8s_to_trace.py [--blueprint F] [--out T] [--insights-md M]"""
import argparse, datetime, hashlib, json, os, re, time
import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
CLK = time.perf_counter
LAYER = dict(Namespace=0, ServiceAccount=0, ConfigMap=0, PersistentVolumeClaim=0, Job=1, Deployment=1, CronJob=1, Service=2, HorizontalPodAutoscaler=2, PodDisruptionBudget=2, NetworkPolicy=2)
RULES = [("R1", "containers declare resource requests"), ("R2", "containers declare resource limits"), ("R3", "Deployments have readiness + liveness probes"),
         ("R4", "pods run as non-root"), ("R5", "images carry a pinned tag (not latest)"), ("R6", "every reference resolves"),
         ("R7", "selectors match at least one workload"), ("R8", "autoscaler target exists"), ("R9", "claimed volumes are mounted read-only by serve and monitor")]


def pod_spec(d):
    k = d["kind"]
    s = d.get("spec") or {}
    if k in ("Job", "Deployment"):
        return (s.get("template") or {}).get("spec")
    if k == "CronJob":
        return (((s.get("jobTemplate") or {}).get("spec") or {}).get("template") or {}).get("spec")
    return None


def pod_labels(d):
    return ((((d.get("spec") or {}).get("template")) or {}).get("metadata") or {}).get("labels") or {}


def cpu_m(v):
    v = str(v)
    return float(v[:-1]) if v.endswith("m") else float(v) * 1000


def mem_mi(v):
    v = str(v)
    for suf, f in (("Gi", 1024), ("Mi", 1), ("Ki", 1 / 1024)):
        if v.endswith(suf):
            return float(v[:-2]) * f
    return float(v) / 2 ** 20


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--blueprint", default=os.path.join(ROOT, "blueprints", "karate-gcn", "karate-gcn.k8s.yaml"))
    ap.add_argument("--out", default=os.path.join(ROOT, "traces", "k8s-karate.trace.json"))
    ap.add_argument("--insights-md", default=os.path.join(ROOT, "out", "infra", "INSIGHTS.md"))
    a = ap.parse_args(argv)
    raw = open(a.blueprint, "rb").read()
    S, stages, t0 = {}, [], CLK()

    def stage(key, fn):
        t_in = CLK()
        res = fn()
        t_out = CLK()
        stages.append(dict(key=key, start_s=t_in - t0, end_s=t_out - t0, wall_ms=(t_out - t_in) * 1e3, **res))

    def parse():
        S["docs"] = [d for d in yaml.safe_load_all(raw.decode()) if d]
        return dict(records_in=len(raw), records_out=len(S["docs"]), metrics=dict(bytes_in=len(raw), documents=len(S["docs"])))

    def index():
        S["res"] = {"%s/%s" % (d["kind"], d["metadata"]["name"]): d for d in S["docs"]}
        kinds = {}
        for d in S["docs"]:
            kinds[d["kind"]] = kinds.get(d["kind"], 0) + 1
        S["kinds"] = kinds
        return dict(records_in=len(S["docs"]), records_out=len(S["res"]), metrics=dict(resources=len(S["res"]), kinds=len(kinds)))

    def resolve():
        res, edges, dangling = S["res"], [], []
        workloads = {k: d for k, d in res.items() if pod_spec(d) is not None}

        def add(src, kind, name, typ):
            tgt = "%s/%s" % (kind, name)
            (edges if tgt in res else dangling).append(dict(**{"from": src, "to": tgt, "type": typ}))

        def matching(sel):
            return [k for k, d in workloads.items() if k.startswith("Deployment/") and all(pod_labels(d).get(a) == b for a, b in (sel or {}).items())] if sel else []
        for k, d in res.items():
            ps = pod_spec(d)
            if ps:
                for c in ps.get("containers", []):
                    for ef in c.get("envFrom", []) or []:
                        add(k, "ConfigMap", ef["configMapRef"]["name"], "config")
                for v in ps.get("volumes", []) or []:
                    if "persistentVolumeClaim" in v:
                        add(k, "PersistentVolumeClaim", v["persistentVolumeClaim"]["claimName"], "storage")
                if ps.get("serviceAccountName"):
                    add(k, "ServiceAccount", ps["serviceAccountName"], "identity")
            sp = d.get("spec") or {}
            if d["kind"] == "Service":
                for m in matching(sp.get("selector")):
                    edges.append({"from": k, "to": m, "type": "selects"})
            elif d["kind"] == "HorizontalPodAutoscaler":
                add(k, sp["scaleTargetRef"]["kind"], sp["scaleTargetRef"]["name"], "scales")
            elif d["kind"] == "PodDisruptionBudget":
                for m in matching((sp.get("selector") or {}).get("matchLabels")):
                    edges.append({"from": k, "to": m, "type": "protects"})
            elif d["kind"] == "NetworkPolicy":
                for m in matching((sp.get("podSelector") or {}).get("matchLabels")):
                    edges.append({"from": k, "to": m, "type": "guards"})
        S["edges"], S["dangling"] = edges, dangling
        return dict(records_in=len(res), records_out=len(edges), metrics=dict(references=len(edges), dangling=len(dangling)))

    def lint():
        res, edges = S["res"], S["edges"]
        fail = {r: [] for r, _ in RULES}
        app = {r: 0 for r, _ in RULES}
        used_by = {}
        for e in edges:
            used_by.setdefault(e["to"], []).append(e)
        for k, d in res.items():
            ps = pod_spec(d)
            if ps:
                cs = ps.get("containers", [])
                app["R1"] += 1; app["R2"] += 1; app["R4"] += 1; app["R5"] += 1
                if not all((c.get("resources") or {}).get("requests") for c in cs): fail["R1"].append(k)
                if not all((c.get("resources") or {}).get("limits") for c in cs): fail["R2"].append(k)
                if not (ps.get("securityContext") or {}).get("runAsNonRoot"): fail["R4"].append(k)
                if not all(":" in c["image"].split("/")[-1] and not c["image"].endswith(":latest") for c in cs): fail["R5"].append(k)
                if d["kind"] == "Deployment":
                    app["R3"] += 1
                    if not all(c.get("readinessProbe") and c.get("livenessProbe") for c in cs): fail["R3"].append(k)
                if d["kind"] in ("Deployment", "CronJob"):
                    app["R9"] += 1
                    mounts = [m for c in cs for m in c.get("volumeMounts", []) or []]
                    if not all(m.get("readOnly") for m in mounts): fail["R9"].append(k)
            if d["kind"] in ("Service", "PodDisruptionBudget", "NetworkPolicy"):
                app["R7"] += 1
                if not any(e["from"] == k for e in edges): fail["R7"].append(k)
            if d["kind"] == "HorizontalPodAutoscaler":
                app["R8"] += 1
                if not any(e["from"] == k and e["type"] == "scales" for e in edges): fail["R8"].append(k)
        app["R6"] = len(edges) + len(S["dangling"])
        fail["R6"] = ["%s -> %s" % (e["from"], e["to"]) for e in S["dangling"]]
        S["checks"] = [dict(rule=r, text=t, applicable=app[r], failing=fail[r], passed=app[r] - len(fail[r])) for r, t in RULES]
        n_pass, n_app = sum(c["passed"] for c in S["checks"]), sum(c["applicable"] for c in S["checks"])
        return dict(records_in=len(res), records_out=n_app, metrics=dict(rules=len(RULES), checks_run=n_app, checks_passed=n_pass, findings=n_app - n_pass))

    def budget():
        tot = dict(cpu=0.0, mem=0.0, cpu_max=0.0)
        per = {}
        hpa = next((d for d in S["res"].values() if d["kind"] == "HorizontalPodAutoscaler"), None)
        for k, d in S["res"].items():
            ps = pod_spec(d)
            if not ps:
                continue
            rq = [(c.get("resources") or {}).get("requests") or {} for c in ps.get("containers", [])]
            cpu, mem = sum(cpu_m(r.get("cpu", 0)) for r in rq), sum(mem_mi(r.get("memory", 0)) for r in rq)
            rep = int((d.get("spec") or {}).get("replicas", 1)) if d["kind"] == "Deployment" else 1
            rmax = int(hpa["spec"]["maxReplicas"]) if (hpa and d["kind"] == "Deployment") else rep
            per[k] = dict(cpu_m=cpu * rep, mem_mi=mem * rep, replicas=rep, cpu_m_per_pod=cpu, mem_mi_per_pod=mem)
            tot["cpu"] += cpu * rep; tot["mem"] += mem * rep; tot["cpu_max"] += cpu * rmax
        S["per"], S["tot"] = per, tot
        return dict(records_in=len(per), records_out=len(per), metrics=dict(workloads=len(per), cpu_requests_m=tot["cpu"], memory_requests_mi=tot["mem"], cpu_requests_at_hpa_max_m=tot["cpu_max"]))

    for key, fn in (("parse", parse), ("index", index), ("resolve", resolve), ("lint", lint), ("budget", budget)):
        stage(key, fn)
    dur = stages[-1]["end_s"]
    run = json.load(open(os.path.join(ROOT, "out", "gnn", "run.json")))
    res, edges, checks, per, tot = S["res"], S["edges"], S["checks"], S["per"], S["tot"]
    ids = {k: "r%d" % i for i, k in enumerate(res)}
    order = {}
    nodes = []
    for k, d in res.items():
        lay = LAYER[d["kind"]]
        order[lay] = order.get(lay, 0) + 1
        fails = [c["rule"] for c in checks if k in c["failing"] or any(f.startswith(k + " ") for f in c["failing"])]
        nodes.append(dict(id=ids[k], key=k, kind=d["kind"], name=d["metadata"]["name"], layer=lay, order=order[lay] - 1, frame=d["kind"] == "Namespace",
                          cpu_m=per.get(k, {}).get("cpu_m", 0), mem_mi=per.get(k, {}).get("mem_mi", 0), replicas=per.get(k, {}).get("replicas", 0), failing_rules=fails))
    n_fail = sum(1 for n in nodes if n["failing_rules"])
    failing_txt = "; ".join("%s (%s)" % (c["rule"], ", ".join(f.split("/")[-1] for f in c["failing"])) for c in checks if c["failing"]) or "none"
    ann = res["Deployment/karate-gcn-serve"]["metadata"]["annotations"]
    n_pass, n_app = sum(c["passed"] for c in checks), sum(c["applicable"] for c in checks)
    insights = [
        dict(id="shape", title="THE BLUEPRINT AT A GLANCE", text="The blueprint has %d resources in %d kinds: a train Job, a serve Deployment, a monitor CronJob and the config, storage, identity and network objects around them." % (len(res), len(S["kinds"])),
             numbers=dict(resources=len(res), kinds=len(S["kinds"])), at=dict(stage_from="parse", stage_to="index")),
        dict(id="refs", title="REFERENCES BECOME EDGES", text="%d references were resolved (config, storage, identity, selectors, autoscaling); %d dangle. Every Service, budget and policy finds the pods it names." % (len(edges), len(S["dangling"])),
             numbers=dict(references=len(edges), dangling=len(S["dangling"])), at=dict(stage_from="resolve", stage_to="resolve")),
        dict(id="lint", title="LINT: %d OF %d CHECKS PASS" % (n_pass, n_app), text="%d of %d rule checks pass; %d resources have findings. Failing: %s." % (n_pass, n_app, n_fail, failing_txt),
             numbers=dict(checks_passed=n_pass, checks_run=n_app, resources_with_findings=n_fail), at=dict(stage_from="lint", stage_to="lint")),
        dict(id="budget", title="WHAT IT WOULD RESERVE", text="Requests add up to %.0f m CPU and %.0f Mi memory at baseline replicas; if the autoscaler reaches its maximum of %d replicas the CPU request grows to %.0f m." % (
            tot["cpu"], tot["mem"], res["HorizontalPodAutoscaler/karate-gcn-serve"]["spec"]["maxReplicas"], tot["cpu_max"]),
             numbers=dict(cpu_requests_m=tot["cpu"], memory_requests_mi=tot["mem"], max_replicas=res["HorizontalPodAutoscaler/karate-gcn-serve"]["spec"]["maxReplicas"], cpu_requests_at_max_m=tot["cpu_max"]), at=dict(stage_from="budget", stage_to="budget", part=[0.0, 0.5])),
        dict(id="link", title="THE SAME WEIGHTS AS THE REGISTRY", text="The train Job and the serve Deployment are annotated with the weights sha256 %s, the hash the GNN pipeline's registry stored (%d weights, seed %d)." % (ann["x3d.demo/weights-sha256"][:8], run["stages"][3]["metrics"]["n_params"], run["hp"]["seed"]),
             numbers=dict(weights=run["stages"][3]["metrics"]["n_params"], seed=run["hp"]["seed"]), at=dict(stage_from="budget", stage_to="budget", part=[0.5, 1.0])),
    ]
    st_out = []
    for i, s in enumerate(stages):
        m = dict(wall_ms=round(s["wall_ms"], 6), records_in=s["records_in"], records_out=s["records_out"])
        m.update(s["metrics"])
        st_out.append(dict(id="S%d" % i, name=s["key"], kind=s["key"], layer=i, start_s=round(s["start_s"], 6), end_s=round(s["end_s"], 6), parallelism=1, metrics=m, stage_key=s["key"]))
    flows = [{"from": "S%d" % i, "to": "S%d" % (i + 1), "records": stages[i]["records_out"], "bytes": 0, "start_s": st_out[i]["end_s"], "end_s": st_out[i + 1]["start_s"]} for i in range(4)]
    ents = [dict(id=n["id"], label=n["name"], value=n["cpu_m"], rank=r + 1, stage="S2", kind=n["kind"]) for r, n in enumerate(sorted(nodes, key=lambda n: (-n["cpu_m"], n["id"])))]
    trace = dict(
        schema="x3d-trace/1",
        source=dict(kind="k8s-blueprint", synthetic=True, title="A Kubernetes blueprint for the karate-club GNN service (SYNTHETIC blueprint, real static analysis)",
                    run_id="k8s-karate-" + hashlib.sha256(raw).hexdigest()[:8], created_utc=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    engine=dict(name="static analysis in python (pyyaml)", version="pyyaml %s" % yaml.__version__),
                    data=dict(description="11 Kubernetes resources authored to deploy the Stage-1 pipeline: train Job, serve Deployment, monitor CronJob",
                              origin="authored blueprint blueprints/karate-gcn/karate-gcn.k8s.yaml, not an observed cluster", rows_or_bytes_read=len(raw),
                              license_note="authored for this demo; hashes and hyper-parameters come from the real Stage-1 run"),
                    provenance=dict(blueprint_sha256=hashlib.sha256(raw).hexdigest(), weights_sha256=ann["x3d.demo/weights-sha256"], dataset_sha256=ann["x3d.demo/dataset-sha256"],
                                    registry_version=ann["x3d.demo/registry-version"], files={"karate-gcn.k8s.yaml": hashlib.sha256(raw).hexdigest()})),
        time=dict(unit="s", duration=round(dur, 6)), stages=st_out, flows=flows, series=dict(t=[], channels={}), entities=ents,
        metrics=dict(resources=len(res), references=len(edges), dangling_references=len(S["dangling"]), rules=len(RULES), checks_run=n_app, checks_passed=n_pass,
                     resources_with_findings=n_fail, cpu_requests_m=tot["cpu"], memory_requests_mi=tot["mem"], cpu_requests_at_hpa_max_m=tot["cpu_max"], analysis_wall_ms=round(dur * 1e3, 4)),
        notes=["SYNTHETIC: the blueprint is authored for this demo, not an observed cluster; nothing here ran on Kubernetes (no cluster, no kubectl, no network).",
               "REAL: the parse, reference resolution, lint and request budget are really executed on the blueprint (timings measured); the weights/dataset hashes and hyper-parameters come from the real Stage-1 run.",
               "Playback is STRETCHED: each analysis stage gets a fixed slot; real milliseconds are printed on the stage strip.",
               "Lint findings are consequences of how the blueprint was written, not a security audit; Terraform is not covered (no terraform binary available).",
               "Requests are what the blueprint asks to reserve, not measured usage."],
        blueprint=dict(version=1, namespace="karate-gcn", nodes=nodes, edges=[dict(e, **{"from": ids[e["from"]], "to": ids[e["to"]]}) for e in edges], dangling=S["dangling"], checks=checks,
                       totals=dict(cpu_requests_m=tot["cpu"], memory_requests_mi=tot["mem"], cpu_requests_at_hpa_max_m=tot["cpu_max"]), rules=[dict(rule=r, text=t) for r, t in RULES], insights=insights))
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump(trace, open(a.out, "w"), separators=(",", ":"))
    os.makedirs(os.path.dirname(os.path.abspath(a.insights_md)), exist_ok=True)
    open(a.insights_md, "w").write("# Insights from the blueprint analysis\n\n" + "\n".join("## %s\n\n%s\n\nnumbers: `%s`\n" % (c["title"], c["text"], json.dumps(c["numbers"])) for c in insights))
    print("wrote %s (%.0f KB): %d resources, %d references, %d/%d checks pass (%d resources with findings), analysis %.2f ms" % (a.out, os.path.getsize(a.out) / 1024, len(res), len(edges), n_pass, n_app, n_fail, dur * 1e3))
    print("failing:", failing_txt)


if __name__ == "__main__":
    main()
