#!/usr/bin/env python3
"""Turn the two real BigQuery jobs (q1_rising, q2_hourly) into an x3d-trace/1 file. Real data, so synthetic=false.
Engine-reported: stages, record counts, shuffle bytes, slot-ms, ratios, timeline samples, start/end times.
Derived (and labelled so in the trace): per-stage progress channels (linear between the engine's real start and end times)."""
import datetime, hashlib, json, os, re
ROOT = os.path.expanduser("~/Projects/x3d/work/trace-pipeline"); RAW = f"{ROOT}/traces/raw"
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
j1, j2 = json.load(open(f"{RAW}/q1_rising.job.json")), json.load(open(f"{RAW}/q2_hourly.job.json"))
rows1, rows2 = json.load(open(f"{RAW}/q1_rising.rows.json")), json.load(open(f"{RAW}/q2_hourly.rows.json"))
sel = json.load(open(f"{RAW}/q2_selection.json"))
ledger = {d["name"]: d for d in map(json.loads, open(f"{ROOT}/ledger/bq-ledger.jsonl")) if d.get("event") == "done"}
q = j1["statistics"]["query"]; plan = q["queryPlan"]; t0 = int(j1["statistics"]["startTime"]); dur = (int(j1["statistics"]["endTime"]) - t0) / 1000.0
KIND = {"Input": "scan", "Repartition": "shuffle", "Aggregate+": "aggregate", "Join+": "join", "Output": "output", "Sort": "sort", "Sort+": "sort"}
fl = lambda x, d=0.0: float(x) if x not in (None, "") else d
def day(ep): return datetime.datetime.fromtimestamp(float(ep), datetime.UTC).strftime("%Y-%m-%d")
ids = {s["id"]: f'S{int(s["id"]):02d}' for s in plan}
depth = {}
def dep(s):
    if s["id"] in depth: return depth[s["id"]]
    ins = s.get("inputStages", [])
    depth[s["id"]] = 0 if not ins else 1 + max(dep(next(p for p in plan if p["id"] == i)) for i in ins)
    return depth[s["id"]]
stages, flows = [], []
for s in plan:
    kind = KIND.get(s["name"].split(": ")[1], "aggregate"); label = s["name"].split(": ")[1].rstrip("+").replace("Repartition", "Shuffle (repartition)").replace("Aggregate", "Aggregate").replace("Join", "Join").replace("Output", "Output (top 40)")
    if kind == "scan":
        where = " ".join(" ".join(st.get("substeps", [])) for st in s["steps"] if st["kind"] == "READ")
        m = re.search(r"greater_or_equal\(\$\d+, ([0-9.]+)\), less\(\$\d+, ([0-9.]+)\)", where)
        if m:
            a, b = day(m.group(1)), day(float(m.group(2)) - 1)
            label = f"Scan en pageviews {a}" + (f"..{b[8:]} ({(float(m.group(2))-float(m.group(1)))/86400:.0f} days)" if a != b else " (1 day)")
    avg, mx = fl(s.get("computeRatioAvg")), fl(s.get("computeRatioMax"))
    stages.append({"id": ids[s["id"]], "name": label, "engine_name": s["name"], "kind": kind, "layer": dep(s),
                   "start_s": round((int(s["startMs"]) - t0) / 1000, 3), "end_s": round((int(s["endMs"]) - t0) / 1000, 3),
                   "parallelism": int(s.get("parallelInputs", 1)),
                   "metrics": {"records_in": int(s.get("recordsRead", 0)), "records_out": int(s.get("recordsWritten", 0)), "bytes_out": int(s.get("shuffleOutputBytes", 0)),
                               "bytes_spilled": int(s.get("shuffleOutputBytesSpilled", 0)), "slot_ms": int(s.get("slotMs", 0)),
                               "wait_ratio_avg": fl(s.get("waitRatioAvg")), "wait_ratio_max": fl(s.get("waitRatioMax")), "read_ratio_avg": fl(s.get("readRatioAvg")),
                               "read_ratio_max": fl(s.get("readRatioMax")), "compute_ratio_avg": avg, "compute_ratio_max": mx,
                               "write_ratio_avg": fl(s.get("writeRatioAvg")), "write_ratio_max": fl(s.get("writeRatioMax")),
                               "skew_ratio": round(mx / avg, 2) if avg > 0 else 1.0}})
by_id = {s["id"]: s for s in stages}
for s in plan:
    for i in s.get("inputStages", []):
        src = next(p for p in plan if p["id"] == i); a, b = by_id[ids[i]], by_id[ids[s["id"]]]
        flows.append({"from": ids[i], "to": ids[s["id"]], "records": int(src.get("recordsWritten", 0)), "bytes": int(src.get("shuffleOutputBytes", 0)),
                      "start_s": a["end_s"], "end_s": max(b["start_s"], a["end_s"] + 0.02)})
step = 0.05; n = int(dur / step) + 2; tgrid = [round(i * step, 3) for i in range(n)]
chan = {}
for s in stages:
    d = max(s["end_s"] - s["start_s"], 1e-3)
    chan[f"stage:{s['id']}:progress"] = [round(min(1.0, max(0.0, (t - s["start_s"]) / d)), 3) for t in tgrid]
tot_bytes = sum(s["metrics"]["bytes_out"] for s in stages) or 1
chan["derived:shuffle_bytes_cumulative"] = [round(sum(s["metrics"]["bytes_out"] * min(1.0, max(0.0, (t - s["start_s"]) / max(s["end_s"] - s["start_s"], 1e-3))) for s in stages)) for t in tgrid]
# entities: ranked risers (sensitive titles omitted by a documented rule), the first 12 with real hourly series from q2
hours = {}
for r in rows2:
    h = int((datetime.datetime.fromisoformat(r["datehour"]).replace(tzinfo=datetime.UTC) - datetime.datetime(2026, 10, 13, tzinfo=datetime.UTC)).total_seconds() // 3600)
    hours.setdefault(r["title"], {})[h] = int(r["views"])
ents, rank = [], 0
for r in rows1:
    if r["title"] in sel["omitted_titles"]: continue
    rank += 1
    e = {"id": f"e{rank}", "label": r["title"].replace("_", " "), "value": int(r["v_today"]), "rank": rank, "stage": "S08",
         "extra": {"views_per_day_baseline": round(fl(r["v_base"])), "surge": round(fl(r["surge"]), 2)}}
    if r["title"] in hours:
        e["series"] = {"t": list(range(96)), "v": [hours[r["title"]].get(h, 0) for h in range(96)], "unit": "views per hour, hour 0 = 2026-10-13T00:00Z (hours without a row = 0)"}
    ents.append(e)
scans = [s for s in stages if s["kind"] == "scan"]
bill = int(q["totalBytesBilled"]) + int(j2["statistics"]["query"]["totalBytesBilled"])
trace = {
    "schema": "x3d-trace/1",
    "source": {"kind": "bigquery", "synthetic": False, "title": "A day of English Wikipedia attention on BigQuery (REAL DATA)", "run_id": ledger["q1_rising"]["job_id"],
               "created_utc": ledger["q1_rising"]["utc"], "engine": {"name": "Google BigQuery (on-demand, location US)", "version": None},
               "data": {"description": "Real hourly pageview counts for English Wikipedia (desktop site, namespace 0): 2026-10-16 against the 2026-10-13..15 daily average",
                        "origin": "bigquery-public-data.wikipedia.pageviews_2026 (partitioned by day, clustered by wiki, title)", "rows_or_bytes_read": sum(s["metrics"]["records_in"] for s in scans),
                        "license_note": "Wikimedia Foundation pageview counts exposed as a BigQuery public dataset; check Wikimedia's terms before redistributing raw numbers.",
                        "omitted_by_rule": {"count": sel["omitted_titles_count"], "rule": "titles matching a violence/tragedy keyword regex are not shown as labelled entities; they still count in every engine statistic", "regex": sel["rule"]}},
               "provenance": {"job_ids": [ledger["q1_rising"]["job_id"], ledger["q2_hourly"]["job_id"]], "location": "US", "project": "<PROJECT>",
                              "bytes_processed": int(q["totalBytesProcessed"]) + int(j2["statistics"]["query"]["totalBytesProcessed"]), "bytes_billed": bill,
                              "query_sql_sha256": {"q1_rising": ledger["q1_rising"]["sql_sha256"], "q2_hourly": ledger["q2_hourly"]["sql_sha256"]},
                              "partition_range": "pageviews_2026 2026-10-13 .. 2026-10-16", "cache_hit": [q.get("cacheHit", False), j2["statistics"]["query"].get("cacheHit", False)],
                              "files": {n: sha(f"{RAW}/{n}") for n in ("q1_rising.job.json", "q1_rising.rows.json", "q2_hourly.job.json", "q2_hourly.rows.json")}}},
    "time": {"unit": "s", "duration": round(dur, 3)},
    "stages": stages, "flows": flows, "series": {"t": tgrid, "channels": chan}, "entities": ents,
    "timeline_raw": [{k: int(v) for k, v in t.items()} for t in q.get("timeline", [])],
    "metrics": {"bytes_processed_q1": int(q["totalBytesProcessed"]), "bytes_billed_total": bill, "slot_ms_q1": int(q["totalSlotMs"]), "elapsed_ms_q1": round(dur * 1000),
                "rows_scanned_q1": sum(s["metrics"]["records_in"] for s in scans), "shuffle_bytes_total_q1": tot_bytes, "stages_q1": len(stages), "rows_returned_q1": len(rows1),
                "max_skew_ratio": max(s["metrics"]["skew_ratio"] for s in stages), "entities_labelled": len(ents), "entities_omitted_by_rule": sel["omitted_titles_count"]},
    "notes": ["REAL DATA: counts are Wikimedia's pageviews for the English desktop site, namespace 0, read through BigQuery; the stage statistics are BigQuery's own job statistics.",
              "Stage progress channels are DERIVED: linear between the engine-reported start and end of each stage (BigQuery reports 3 coarse timeline samples for this 3-second job, kept in timeline_raw).",
              "Hours without a row in q2 mean zero recorded views. 'Surge' = today / (baseline daily average + 2000), a simple ranking score defined in sql/q1_rising.sql, not an engine output.",
              f"{sel['omitted_titles_count']} rising titles about violence were left out of the labelled entities by a keyword rule; they remain inside every count and engine statistic."]}
out = f"{ROOT}/traces/bq-wikipedia.trace.json"; json.dump(trace, open(out, "w"), separators=(",", ":"))
print(out, os.path.getsize(out) // 1024, "KB |", len(stages), "stages,", len(flows), "flows,", len(chan), "channels,", len(ents), "entities,", sum(1 for e in ents if "series" in e), "with hourly series")
print("labels:", [f"{s['id']} {s['name']} L{s['layer']}" for s in stages])
