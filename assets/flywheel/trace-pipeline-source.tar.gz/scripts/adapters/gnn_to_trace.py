#!/usr/bin/env python3
"""gnn_to_trace.py: out/gnn/run.json (written by scripts/gnn/pipeline.py) -> traces/gnn-karate.trace.json (x3d-trace/1, kind 'mlops-gnn').

usage: python3 scripts/adapters/gnn_to_trace.py [--run out/gnn/run.json] [--out traces/gnn-karate.trace.json] [--insights-md out/gnn/INSIGHTS.md]

Mapping (see the addendum in TRACE_SCHEMA.md):
  stages    = the 8 MLOps stages, layers 0..7, measured wall-clock start/end (perf_counter), metrics = numbers only, hashes -> provenance
  flows     = hand-over between consecutive stages (records = items handed over, bytes = the sender's artifact bytes)
  series    = per-epoch loss / accuracy channels on the real run clock (t = measured end of each epoch)
  entities  = the 34 members: series {t, x, y, p_officer} = hidden-layer embedding position and P(Officer) after every epoch
  gnn       = the extension block: node-link graph (A-hat edge weights, display layout), epochs, errors, monitor, seed sweep, insights
Every number the scene shows comes from here; the insight sentences are filled from the run, never typed in by hand.
"""
import argparse
import json
import os
import sys

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts", "gnn"))
import karate     # noqa: E402
import layout     # noqa: E402

UNDECIDED_MARGIN = 0.10          # display rule: |P(Officer) - 0.5| below this is shown as "undecided" (neutral colour)
LAYOUT_SEED = 2
STAGE_LABELS = {"ingest": "ingest", "validate": "validate data", "split": "split / mask + features", "train": "train (GCN)", "evaluate": "evaluate",
                "register": "register model", "serve": "serve smoke test", "monitor": "monitor: edge-removal probe"}


def num(v, nd=5):
    return round(float(v), nd)


def g3(v):
    """Same display rounding the scene uses for fractions: 3 significant digits."""
    return float("%.3g" % v)


def build_insights(run, nodes, ep):
    """Insight cards. Each: id, title (big subtitle), text (board / report), numbers (every figure that appears in text), at (where it plays)."""
    ev, tl, mon, sw = run["evaluation"], run["train_log"], run["monitor"], run["seed_sweep"]
    n, m = karate.N, len(karate.EDGES)
    unl = n - 2
    y = np.array([nd["faction"] for nd in nodes])
    p = np.array(tl["p_officer"])                                    # (epochs+1, 34)
    emb = np.array(tl["emb"])                                        # (epochs+1, 34, 2)
    acc = np.array(tl["acc_all"])
    loss = np.array(tl["loss_train"])
    E = len(acc) - 1
    margin = np.abs(p - 0.5)
    decided = (margin >= UNDECIDED_MARGIN).sum(axis=1)
    e_half = int(np.argmax(decided >= n // 2))                       # first epoch with half of the members decided
    e_l01 = int(np.argmax(loss < 0.1))
    e_l003 = int(np.argmax(loss < 0.03))
    final_acc = float(acc[-1])
    e_settle = int(max(i for i in range(E + 1) if abs(acc[i] - final_acc) > 1e-9) + 1) if np.any(np.abs(acc - final_acc) > 1e-9) else 0
    c0, cf = int(round(acc[0] * n)), int(round(final_acc * n))
    h = ev["by_hop"]
    mh, off = emb[-1][y == 0].mean(axis=0), emb[-1][y == 1].mean(axis=0)
    w = ev["wrong"][0] if ev["wrong"] else None
    same = ev["same_faction_edges"]
    ia_lo, ia_hi = int(round(100 * sw["init_accuracy_min"])), int(round(100 * sw["init_accuracy_max"]))
    conf0 = round(float(100 * np.maximum(p[0], 1 - p[0]).mean()), 1)
    col = [r["accuracy"] for r in sw["rows"] if r["dead_members"] >= 10]
    col_lo, col_hi = int(round(100 * min(col))), int(round(100 * max(col)))
    cards = []

    def card(cid, title, text, numbers, at):
        cards.append(dict(id=cid, title=title, text=text, numbers=numbers, at=at))

    card("data", "TINY, REAL, LABEL-STARVED",
         "%d members, %d friendships, but the model may see only 2 labels: member 1 (Mr. Hi) and member 34 (the Officer). The other %d members must be worked out from who is friends with whom." % (n, m, unl),
         dict(members=n, friendships=m, labelled=2, unlabelled=unl, leader_a=1, leader_b=34), dict(stage_from="ingest", stage_to="validate"))
    card("homophily", "WHY FRIENDS CAN VOTE",
         "%d of %d friendships join members of the same faction (%d%%). A member who looks like its friends is usually right: that is the bet a graph network makes." % (same, m, round(100 * same / m)),
         dict(same_faction_friendships=same, friendships=m, same_faction_percent=round(100 * same / m)), dict(stage_from="split", stage_to="split"))
    card("epoch0", "EPOCH 0: RANDOM WEIGHTS, COIN-FLIP GUESSES",
         "Average confidence is only %.1f%% (a coin flip is 50%%). This seed happens to start with %d of %d right; over %d seeds the untrained model scores anywhere from %d%% to %d%%, so that is luck." % (
             conf0, c0, n, len(sw["seeds"]), ia_lo, ia_hi),
         dict(mean_confidence_percent_epoch0=conf0, coin_flip_percent=50, correct_epoch0=c0, members=n, seeds=len(sw["seeds"]), init_accuracy_percent_min=ia_lo, init_accuracy_percent_max=ia_hi),
         dict(stage_from="train", stage_to="train", epoch_from=0, epoch_to=e_half))
    card("gossip", "TWO ROUNDS OF GOSSIP REACH EVERYONE",
         "Each layer, every member averages itself and its friends. After 2 layers a leader's label has travelled 2 friendships: %d of the %d unlabelled members are friends of a leader and %d are friends of friends; nobody is further away." % (
             h["1"]["members"], unl, h.get("2", {"members": 0})["members"]),
         dict(one_hop_members=h["1"]["members"], two_hop_members=h.get("2", {"members": 0})["members"], unlabelled=unl, layers=2),
         dict(stage_from="train", stage_to="train", epoch_from=e_half, epoch_to=e_l01))
    card("confidence", "LEARNING = CONFIDENCE, NOT NEW ANSWERS",
         "Accuracy was %d of %d from epoch %d on, yet training runs to epoch %d: the loss falls from %.3g to %.3g as tentative guesses become confident votes." % (
             cf, n, e_settle, E, g3(loss[0]), g3(loss[-1])),
         dict(correct_final=cf, members=n, settled_epoch=e_settle, epochs=E, loss_epoch0=g3(loss[0]), loss_final=g3(loss[-1])),
         dict(stage_from="train", stage_to="train", epoch_from=e_l01, epoch_to=e_l003))
    card("camps", "TWO CAMPS ON TWO HIDDEN UNITS",
         "The 2 hidden units become detectors: unit 1 fires for Mr. Hi's members (mean %.2f against %.2f for the Officer's), unit 2 for the Officer's (%.2f against %.2f). The panel shows the raw hidden layer, no projection." % (
             mh[0], off[0], off[1], mh[1]),
         dict(hidden_units=run["hp"]["hidden"], unit1_mean_mr_hi=num(mh[0], 2), unit1_mean_officer=num(off[0], 2), unit2_mean_officer=num(off[1], 2), unit2_mean_mr_hi=num(mh[1], 2)),
         dict(stage_from="train", stage_to="train", epoch_from=e_l003, epoch_to=E))
    if w:
        card("miss", "THE ONE MISS: MEMBER %d" % w["member"],
             "Member %d really sided with Mr. Hi, but %d of his %d friends are in the Officer's camp (model: %.2f chance he is the Officer's). A friendship graph cannot see reasons that are not friendships." % (
                 w["member"], w["friends_in_officer"], w["degree"], w["p_officer"]),
             dict(member=w["member"], friends_in_officer=w["friends_in_officer"], friends=w["degree"], p_officer=g3(w["p_officer"])),
             dict(stage_from="evaluate", stage_to="evaluate"))
    card("registry", "REGISTERED, RELOADED, BIT-IDENTICAL",
         "The %d weights were stored under their sha256 and reloaded from disk by the serve stage: same hash, same %d predictions. Training again with the same seed gives the same hash." % (
             run["stages"][3]["metrics"]["n_params"], n),
         dict(weights=run["stages"][3]["metrics"]["n_params"], predictions=n), dict(stage_from="register", stage_to="serve"))
    card("robust", "ROBUSTNESS PROBE",
         "Remove %d random friendships (seed %d): %d of %d predictions change. Over %d such random draws the mean accuracy is %.3g (worst %.3g)." % (
             mon["k_removed"], mon["seed"], mon["changed_predictions"], n, mon["draws"], g3(mon["draws_accuracy_mean"]), g3(mon["draws_accuracy_min"])),
         dict(friendships_removed=mon["k_removed"], seed=mon["seed"], changed_predictions=mon["changed_predictions"], members=n, draws=mon["draws"],
              draws_accuracy_mean=g3(mon["draws_accuracy_mean"]), draws_accuracy_worst=g3(mon["draws_accuracy_min"])),
         dict(stage_from="monitor", stage_to="monitor", part=[0.0, 0.5]))
    card("seeds", "FRAGILE START: 2 HIDDEN UNITS CAN DIE",
         "With only %d ReLU units, %d of %d seeds reach 94%% or better and %d collapse to between %d%% and %d%% accuracy because units die and members sit at zero. This run is seed %d, the default seed; the other %d are counted here." % (
             run["hp"]["hidden"], sw["n_at_least_94"], len(sw["seeds"]), sw["n_collapsed"], col_lo, col_hi, run["hp"]["seed"], len(sw["seeds"]) - 1),
         dict(hidden_units=run["hp"]["hidden"], seeds_at_least_94_percent=sw["n_at_least_94"], seeds=len(sw["seeds"]), seeds_collapsed=sw["n_collapsed"], seed=run["hp"]["seed"], other_seeds=len(sw["seeds"]) - 1, threshold_percent=94,
              collapsed_accuracy_percent_min=col_lo, collapsed_accuracy_percent_max=col_hi),
         dict(stage_from="monitor", stage_to="monitor", part=[0.5, 1.0]))
    return cards, dict(e_half_decided=e_half, e_loss_lt_0_1=e_l01, e_loss_lt_0_03=e_l003, e_accuracy_settled=e_settle)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default=os.path.join(ROOT, "out", "gnn", "run.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "traces", "gnn-karate.trace.json"))
    ap.add_argument("--insights-md", default=os.path.join(ROOT, "out", "gnn", "INSIGHTS.md"))
    a = ap.parse_args(argv)
    run = json.load(open(a.run))
    tl, ev, hp = run["train_log"], run["evaluation"], run["hp"]
    n = karate.N
    y = karate.factions()
    A = np.zeros((n, n))
    for i, j in karate.edge_list_0idx():
        A[i, j] = A[j, i] = 1.0
    deg = A.sum(axis=1).astype(int)
    pos = layout.fruchterman_reingold(A, seed=LAYOUT_SEED)
    pos = pos / np.abs(pos).max(axis=0)                                              # stretch each axis to fill the square panel (distances only grow)
    emb = np.array(tl["emb"])                                                       # (E+1, 34, 2)
    p_off = np.array(tl["p_officer"])
    t_run = [float(t) for t in tl["t_run_s"]]
    hops = ev["hops_to_nearest_leader"]
    final_pred = ev["pred"]

    # ---- stages and flows
    stages, flows = [], []
    for i, s in enumerate(run["stages"]):
        met = {"wall_ms": s["wall_ms"]}
        met.update({k: v for k, v in s["metrics"].items() if isinstance(v, (int, float)) and not isinstance(v, bool)})
        stages.append(dict(id="S%d" % i, name=STAGE_LABELS[s["id"]], kind=s["kind"], layer=i, start_s=num(s["start_s"], 6), end_s=num(s["end_s"], 6),
                           parallelism=1, metrics={k: (num(v, 6) if isinstance(v, float) else v) for k, v in met.items()}, stage_key=s["id"]))
    handoff = [(78, "ingest"), (78, "validate"), (34, "split"), (72, "train"), (72, "evaluate"), (72, "register"), (34, "serve")]
    for i, (recs, key) in enumerate(handoff):
        src, dst = stages[i], stages[i + 1]
        flows.append({"from": src["id"], "to": dst["id"], "records": recs, "bytes": int(run["stages"][i]["metrics"].get("artifact_bytes", 0)),
                      "start_s": src["end_s"], "end_s": dst["start_s"]})
    duration = num(run["stages"][-1]["end_s"], 6)

    # ---- series on the real run clock
    series = dict(t=[round(t, 6) for t in t_run], epoch=tl["epoch"], channels=dict(
        loss_train=tl["loss_train"], loss_all34=tl["loss_all"], accuracy_all34=tl["acc_all"], accuracy_unlabelled32=tl["acc_unlabelled"]))

    # ---- nodes / entities
    nodes, ents = [], []
    order = sorted(range(n), key=lambda i: (-int(deg[i]), i))
    rank = {i: r + 1 for r, i in enumerate(order)}
    for i in range(n):
        nodes.append(dict(id=i + 1, label="member %d" % (i + 1), faction=int(y[i]), faction_name=karate.FACTION_NAMES[y[i]], labelled=(i + 1) in karate.LEADERS,
                          degree=int(deg[i]), hops_to_leader=int(hops[i]), layout=[num(pos[i][0], 4), num(pos[i][1], 4)], final_pred=int(final_pred[i])))
        ents.append(dict(id="m%d" % (i + 1), label="member %d" % (i + 1), value=int(deg[i]), rank=rank[i], stage="S3", faction=karate.FACTION_NAMES[y[i]],
                         series=dict(t=[round(t, 6) for t in t_run], x=[round(float(v), 4) for v in emb[:, i, 0]], y=[round(float(v), 4) for v in emb[:, i, 1]],
                                     p_officer=[round(float(v), 4) for v in p_off[:, i]])))
    ents.sort(key=lambda e: e["rank"])

    insights, beats = build_insights(run, nodes, tl)
    wrong = ev["wrong"]
    sw, mon, rep = run["seed_sweep"], run["monitor"], run["repeat"]
    st = {s["id"]: s for s in run["stages"]}
    metrics = {
        "accuracy_all_34": ev["accuracy_all34"], "members_correct_of_34": ev["n_correct"], "members_wrong": ev["n_wrong"],
        "accuracy_32_unlabelled": ev["accuracy_unlabelled32"], "train_loss_final": tl["loss_train"][-1], "epochs": hp["epochs"],
        "model_weights": st["train"]["metrics"]["n_params"], "pipeline_wall_ms": run["pipeline_wall_ms"], "train_wall_ms": st["train"]["wall_ms"],
        "accuracy_after_edge_removal": mon["perturbed_accuracy"], "seeds_collapsed_of_20": sw["n_collapsed"],
    }
    notes = [
        "REAL DATA: Zachary's 1977 karate club, a tiny textbook dataset (34 members, 78 friendships). It shows how a graph network works; it is not a benchmark.",
        "REAL training run: a 2-layer GCN in plain numpy, %d epochs of gradient descent, seed %d; only members 1 and 34 are labelled." % (hp["epochs"], hp["seed"]),
        "Accuracy is measured on the same 34-member graph the model was trained on (transductive): %d of 34 right%s." % (
            ev["n_correct"], ", member %d wrong" % wrong[0]["member"] if wrong else ""),
        "Playback is STRETCHED: each pipeline stage gets a fixed slot of the loop and the real milliseconds are printed on the stage strip (whole run %.0f ms); epochs replay at an even pace." % run["pipeline_wall_ms"],
        "Timings come from one cold run: the first training call includes one-off numpy start-up (warm repeat %.1f ms vs %.1f ms here)." % (rep["warm_train_wall_ms"], st["train"]["wall_ms"]),
        "Seed %d is the default seed, used as is. %d of %d seeds collapse (dead ReLU units); the untrained model's accuracy also depends on the seed." % (hp["seed"], sw["n_collapsed"], len(sw["seeds"])),
        "The network layout is display-only (force-directed). The embedding panel is the model's real 2-unit hidden layer, not a projection.",
        "Why member 9 chose Mr. Hi is reported in Zachary's paper as a non-friendship reason (not derivable from this data).",
    ]
    stage_hashes = {s["id"]: s["hashes"] for s in run["stages"]}
    trace = dict(
        schema="x3d-trace/1",
        source=dict(kind="mlops-gnn", synthetic=False,
                    title="A tiny graph neural network learns Zachary's karate club",
                    run_id=run["run_id"], created_utc=run["created_utc"],
                    engine=dict(name="numpy GCN from scratch (Kipf & Welling 2-layer)", version="numpy %s, python %s" % (run["env"]["numpy"], run["env"]["python"])),
                    data=dict(description="34 members, 78 friendships of a university karate club and the two factions it really split into; a tiny textbook dataset",
                              origin="Zachary 1977 karate club (Zachary, J. Anthropological Research 33(4):452-473)", rows_or_bytes_read=len(karate.EDGES),
                              license_note="published historical dataset embedded in code; members are anonymous numbers"),
                    provenance=dict(seed=hp["seed"], dataset_sha256=run["dataset_sha256"], weights_sha256=run["weights_sha256"], registry_version=run["version"],
                                    code_sha256=run["env"]["code_sha256"], hyper_parameters=hp, stage_hashes=stage_hashes,
                                    files={k: v for s in run["stages"] for k, v in s["hashes"].items() if isinstance(v, str)})),
        time=dict(unit="s", duration=duration),
        stages=stages, flows=flows, series=series, entities=ents, metrics={k: (num(v, 6) if isinstance(v, float) else v) for k, v in metrics.items()}, notes=notes,
        gnn=dict(
            version=1,
            dataset=dict(name="zachary-karate-club-1977", n_nodes=n, n_edges=len(karate.EDGES), classes=karate.FACTION_NAMES, features="identity (one-hot member id)",
                         labelled=sorted(karate.LEADERS), same_faction_edges=ev["same_faction_edges"]),
            model=dict(layers=[dict(op="gcn", inputs=n, outputs=hp["hidden"], activation="relu"), dict(op="gcn", inputs=hp["hidden"], outputs=2, activation="softmax")],
                       hidden=hp["hidden"], n_params=st["train"]["metrics"]["n_params"], optimizer="full-batch gradient descent", lr=hp["lr"], weight_decay=hp["wd"],
                       epochs=hp["epochs"], seed=hp["seed"], init="glorot-uniform", embedding="hidden layer after ReLU (2 units, no projection)"),
            layout=dict(kind="fruchterman-reingold + collision relaxation", seed=LAYOUT_SEED, note="display-only 2-D layout of the friendship network, not a model output"),
            nodes=nodes,
            edges=[[int(a), int(b), num(w, 5)] for a, b, w in run["ahat"]["edges"]],
            self_weights=[num(v, 5) for v in run["ahat"]["self_loops"]],
            epochs=dict(index=tl["epoch"], t_s=[round(t, 6) for t in t_run], loss_train=tl["loss_train"], loss_all34=tl["loss_all"], accuracy_all34=tl["acc_all"],
                        accuracy_unlabelled32=tl["acc_unlabelled"], grad_norm=tl["grad_norm"]),
            thresholds=dict(undecided_margin=UNDECIDED_MARGIN),
            emb_axis_max=num(float(emb.max()), 4),
            final=dict(accuracy_all34=ev["accuracy_all34"], confusion=ev["confusion"], wrong=wrong, by_hop=ev["by_hop"]),
            beats=beats, monitor=mon, seed_sweep={k: v for k, v in sw.items() if k != "rows"}, seed_rows=[dict(seed=r["seed"], init_accuracy=num(r["init_accuracy"], 4), accuracy=num(r["accuracy"], 4), dead_members=r["dead_members"]) for r in sw["rows"]],
            repeat=rep, insights=insights))
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w") as fh:
        json.dump(trace, fh, separators=(",", ":"))
    print("wrote %s (%.0f KB): %d stages, %d flows, %d entities x %d epochs, %d insight cards" % (a.out, os.path.getsize(a.out) / 1024, len(stages), len(flows), len(ents), len(t_run), len(insights)))
    md = ["# Insights from the real run (%s)\n" % run["run_id"], "Every sentence below is filled from out/gnn/run.json; numbers in the scene come from the same trace.\n"]
    for c in insights:
        md.append("## %s\n\n%s\n\nnumbers: `%s`  ·  plays at: `%s`\n" % (c["title"], c["text"], json.dumps(c["numbers"]), json.dumps(c["at"])))
    md.append("\nbeats (derived epochs): `%s`\n" % json.dumps(beats))
    os.makedirs(os.path.dirname(os.path.abspath(a.insights_md)), exist_ok=True)
    open(a.insights_md, "w").write("\n".join(md))


if __name__ == "__main__":
    main()
