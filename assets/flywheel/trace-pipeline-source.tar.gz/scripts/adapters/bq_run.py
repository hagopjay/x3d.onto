#!/usr/bin/env python3
"""Run ONE BigQuery query under the user-approved rules: dry-run first, <= 10 GB per query, <= 50 GB total, public data only.
usage: bq_run.py NAME SQL_FILE [--dry-only]
Writes: ledger/bq-ledger.jsonl (planned line BEFORE the run, done line after), traces/raw/NAME.rows.json, traces/raw/NAME.job.json"""
import datetime, hashlib, json, os, re, subprocess, sys, time
ROOT = os.path.expanduser("~/Projects/x3d/work/trace-pipeline"); PROJECT = "<PROJECT>"; LOCATION = "US"
PER_QUERY, TOTAL = 10 * 10**9, 50 * 10**9
LEDGER = f"{ROOT}/ledger/bq-ledger.jsonl"
name, sql_file = sys.argv[1], sys.argv[2]; dry_only = "--dry-only" in sys.argv
sql = "\n".join(l for l in open(sql_file).read().splitlines() if not l.strip().startswith("--")).strip()   # bq mistakes a leading "--" for a flag
if "bigquery-public-data" not in sql or re.search(r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER)\b", sql, re.I):
    sys.exit("refused: only SELECTs over bigquery-public-data are allowed")
sha = hashlib.sha256(sql.encode()).hexdigest()
def bq(*args, timeout=600):
    r = subprocess.run(["bq", f"--project_id={PROJECT}", f"--location={LOCATION}", *args], capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout, r.stderr
rc, out, err = bq("query", "--use_legacy_sql=false", "--dry_run", sql)
m = re.search(r"process(?:es)?(?: upper bound of)? (\d+) bytes", out + err)
if rc or not m:
    sys.exit(f"dry-run failed: {(out + err)[:300]}")
dry = int(m.group(1))
spent = 0
if os.path.exists(LEDGER):
    for line in open(LEDGER):
        d = json.loads(line)
        if d.get("event") == "done":
            spent += d["bytes_billed"]
print(f"[{name}] dry-run upper bound {dry/1e9:.2f} GB | ledger so far {spent/1e9:.2f} GB | per-query cap 10 GB | total cap 50 GB")
if dry > PER_QUERY: sys.exit(f"refused: {dry/1e9:.2f} GB exceeds the 10 GB per-query cap")
if spent + dry > TOTAL: sys.exit(f"refused: would bring the total to {(spent+dry)/1e9:.2f} GB (> 50 GB)")
def log(rec):
    os.makedirs(os.path.dirname(LEDGER), exist_ok=True)
    open(LEDGER, "a").write(json.dumps(rec) + "\n")
log({"event": "planned", "name": name, "utc": datetime.datetime.now(datetime.UTC).isoformat(), "sql_sha256": sha, "dry_run_bytes": dry, "cap_bytes": min(PER_QUERY, int(dry * 1.1) + 1000000), "dry_only": dry_only})
if dry_only: sys.exit(0)
jid = f"x3d_{name}_{int(time.time())}"; cap = min(PER_QUERY, int(dry * 1.1) + 1000000)
rc, out, err = bq("query", "--use_legacy_sql=false", f"--maximum_bytes_billed={cap}", f"--job_id={jid}", "--format=json", "--max_rows=1000", sql)
if rc:
    log({"event": "failed", "name": name, "job_id": jid, "error": (out + err)[:400]}); sys.exit(f"query failed: {(out+err)[:400]}")
json.dump(json.loads(out), open(f"{ROOT}/traces/raw/{name}.rows.json", "w"))
rc, out, err = bq("show", "--format=prettyjson", "-j", f"{PROJECT}:{jid}")
job = json.loads(out); json.dump(job, open(f"{ROOT}/traces/raw/{name}.job.json", "w"), indent=1)
q = job["statistics"]["query"]
rec = {"event": "done", "name": name, "job_id": jid, "location": LOCATION, "sql_sha256": sha, "dry_run_bytes": dry,
       "bytes_processed": int(q.get("totalBytesProcessed", 0)), "bytes_billed": int(q.get("totalBytesBilled", 0)),
       "slot_ms": int(q.get("totalSlotMs", 0)), "cache_hit": q.get("cacheHit", False), "utc": datetime.datetime.now(datetime.UTC).isoformat()}
log(rec); spent += rec["bytes_billed"]
print(json.dumps(rec)); print(f"ledger total now {spent/1e9:.2f} GB of 50 GB")
