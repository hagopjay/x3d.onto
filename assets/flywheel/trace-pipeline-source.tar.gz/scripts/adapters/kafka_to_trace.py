#!/usr/bin/env python3
"""Convert the Kafka gossip simulation output into an x3d-trace/1 file (see TRACE_SCHEMA.md). Synthetic, and says so."""
import hashlib, json, os, sys
W = os.path.expanduser("~/Projects/x3d/work")
ev = json.load(open(f"{W}/kafka-gossip/events.json")); met = json.load(open(f"{W}/kafka-gossip/metrics.json"))
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
S = ev["series"]; parts = ev["partitions"]; meta = ev["meta"]
pc = {p["id"]: 0 for p in parts}
for a, b, n in ev["flows"]["producer_part"]:
    pc[b] += n
stages = []
for i in range(meta["producers"]):
    n = sum(x[2] for x in ev["flows"]["producer_part"] if x[0] == i)
    stages.append({"id": f"P{i}", "name": f"gossiper {i}", "kind": "producer", "layer": 0, "start_s": 0.0, "end_s": 30.0,
                   "parallelism": 1, "metrics": {"records_out": n}})
for p in parts:
    lab = f'{p["topic"]}[{p["index"]}]'
    stages.append({"id": f'K{p["id"]:02d}', "name": lab, "kind": "partition", "layer": 1, "start_s": 0.0, "end_s": S["t"][-1], "parallelism": 1,
                   "metrics": {"records_in": pc[p["id"]], "leader_broker": p["leader"], "topic_index": list(dict.fromkeys(q["topic"] for q in parts)).index(p["topic"]),
                               "peak_msgs_per_s": max(S["rate"][p["id"]])}})
for c in range(3):
    n = sum(x[2] for x in ev["flows"]["part_consumer"] if x[1] == c)
    stages.append({"id": f"C{c}", "name": f"consumer {c}", "kind": "consumer", "layer": 2, "start_s": 0.0,
                   "end_s": meta["death_t"] if c == 2 else S["t"][-1], "parallelism": 1,
                   "metrics": {"records_in": n, "peak_lag": max(S["lag"][c]), "dies_at_s": meta["death_t"] if c == 2 else None}})
flows = [{"from": f"P{a}", "to": f"K{b:02d}", "records": n, "bytes": n * 220, "start_s": 0.0, "end_s": 30.0} for a, b, n in ev["flows"]["producer_part"]]
flows += [{"from": f"K{a:02d}", "to": f"C{b}", "records": n, "bytes": n * 220, "start_s": 0.0, "end_s": S["t"][-1]} for a, b, n in ev["flows"]["part_consumer"]]
channels = {f"rate:K{p['id']:02d}": S["rate"][p["id"]] for p in parts}
channels.update({f"lag:C{c}": S["lag"][c] for c in range(3)})
channels["total_rate"] = S["total_rate"]; channels["total_lag"] = S["total_lag"]
keys = {}
for t in ev["tracers"]:
    keys.setdefault(t["key"], {"topic": t["topic"], "n": 0})["n"] += 1
ents = [{"id": f"key{i}", "label": k, "value": v["n"], "rank": i + 1, "stage": None} for i, (k, v) in enumerate(sorted(keys.items(), key=lambda kv: -kv[1]["n"])[:10])]
trace = {
    "schema": "x3d-trace/1",
    "source": {"kind": "kafka-sim", "synthetic": True, "title": "Gossip stream on a 3-broker Kafka cluster (SYNTHETIC)", "run_id": f"kafka-sim-seed{met['seed']}",
               "created_utc": "2026-10-18T00:00:00Z", "engine": {"name": "kafka_sim.py (Kafka murmur2 partitioner, FIFO leader queues, eager rebalance)", "version": "1"},
               "data": {"description": "Generated events: Poisson chatter plus Hawkes scandal cascades on fictional names", "origin": "kafka_sim.py", "rows_or_bytes_read": met["messages"],
                        "license_note": "Fully synthetic; all names are fictional"},
               "provenance": {"seed": met["seed"], "files": {"kafka_sim.py": sha(f"{W}/kafka-gossip/kafka_sim.py"), "events.json": sha(f"{W}/kafka-gossip/events.json"),
                                                              "metrics.json": sha(f"{W}/kafka-gossip/metrics.json")}}},
    "time": {"unit": "s", "duration": S["t"][-1]},
    "stages": stages, "flows": flows, "series": {"t": S["t"], "channels": channels}, "entities": ents,
    "metrics": {k: v for k, v in met.items() if isinstance(v, (int, float))} | {f"latency_{k}": v for k, v in met["latency_ms"].items()},
    "tracers": ev["tracers"],   # extension used by the Kafka scene: per-message path timings (id,t,part,producer,consumer,append,ack,consume)
    "notes": ["SYNTHETIC: events are generated, the Kafka mechanics (murmur2 partitioning, per-partition FIFO append queues, eager rebalance) are modelled.",
              "At t=18 s consumer 2 dies; an eager rebalance pauses the whole group for 3 s, the lag spike is the model's output."]}
out = f"{W}/trace-pipeline/traces/kafka-gossip.trace.json"
json.dump(trace, open(out, "w"), separators=(",", ":"))
print(out, os.path.getsize(out) // 1024, "KB |", len(stages), "stages,", len(flows), "flows,", len(channels), "channels")
