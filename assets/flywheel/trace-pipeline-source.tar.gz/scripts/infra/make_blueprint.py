#!/usr/bin/env python3
"""Writes blueprints/karate-gcn/karate-gcn.k8s.yaml: an AUTHORED Kubernetes blueprint that would deploy the Stage-1 MLOps pipeline (train Job, serve Deployment,
monitor CronJob). Authored, not an observed cluster. Real values pulled from out/gnn/run.json: hyper-parameters, dataset hash, weights hash, registry version."""
import json, os
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
run = json.load(open(os.path.join(ROOT, "out", "gnn", "run.json")))
hp, W, D, V = run["hp"], run["weights_sha256"], run["dataset_sha256"], run["version"]
NS = "karate-gcn"
ann = f'''annotations:
    x3d.demo/weights-sha256: "{W}"
    x3d.demo/dataset-sha256: "{D}"
    x3d.demo/registry-version: "{V}"'''
doc = f'''apiVersion: v1
kind: Namespace
metadata:
  name: {NS}
  labels: {{app.kubernetes.io/part-of: karate-gcn, pod-security.kubernetes.io/enforce: restricted}}
---
apiVersion: v1
kind: ServiceAccount
metadata: {{name: karate-gcn-serve, namespace: {NS}}}
---
apiVersion: v1
kind: ConfigMap
metadata: {{name: karate-gcn-config, namespace: {NS}}}
data:
  LEARNING_RATE: "{hp['lr']}"
  EPOCHS: "{hp['epochs']}"
  HIDDEN_UNITS: "{hp['hidden']}"
  SEED: "{hp['seed']}"
  WEIGHT_DECAY: "{hp['wd']}"
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata: {{name: karate-gcn-registry, namespace: {NS}}}
spec:
  accessModes: [ReadWriteMany]
  resources: {{requests: {{storage: 1Gi}}}}
---
apiVersion: batch/v1
kind: Job
metadata:
  name: karate-gcn-train
  namespace: {NS}
  {ann}
spec:
  backoffLimit: 2
  template:
    spec:
      restartPolicy: Never
      securityContext: {{runAsNonRoot: true, runAsUser: 10001}}
      containers:
        - name: train
          image: registry.example.com/karate-gcn/pipeline:1.0.0
          args: ["python", "scripts/gnn/pipeline.py", "--out", "/registry"]
          envFrom: [{{configMapRef: {{name: karate-gcn-config}}}}]
          volumeMounts: [{{name: registry, mountPath: /registry}}]
          resources: {{requests: {{cpu: 500m, memory: 256Mi}}, limits: {{cpu: "1", memory: 512Mi}}}}
      volumes: [{{name: registry, persistentVolumeClaim: {{claimName: karate-gcn-registry}}}}]
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: karate-gcn-serve
  namespace: {NS}
  {ann}
spec:
  replicas: 2
  selector: {{matchLabels: {{app: karate-gcn-serve}}}}
  template:
    metadata: {{labels: {{app: karate-gcn-serve}}}}
    spec:
      serviceAccountName: karate-gcn-serve
      securityContext: {{runAsNonRoot: true, runAsUser: 10001}}
      containers:
        - name: serve
          image: registry.example.com/karate-gcn/serve:1.0.0
          ports: [{{containerPort: 8080}}]
          envFrom: [{{configMapRef: {{name: karate-gcn-config}}}}]
          readinessProbe: {{httpGet: {{path: /ready, port: 8080}}}}
          livenessProbe: {{httpGet: {{path: /live, port: 8080}}}}
          volumeMounts: [{{name: registry, mountPath: /registry, readOnly: true}}]
          resources: {{requests: {{cpu: 100m, memory: 128Mi}}, limits: {{cpu: 500m, memory: 256Mi}}}}
      volumes: [{{name: registry, persistentVolumeClaim: {{claimName: karate-gcn-registry, readOnly: true}}}}]
---
apiVersion: v1
kind: Service
metadata: {{name: karate-gcn-serve, namespace: {NS}}}
spec:
  selector: {{app: karate-gcn-serve}}
  ports: [{{port: 80, targetPort: 8080}}]
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: {{name: karate-gcn-serve, namespace: {NS}}}
spec:
  scaleTargetRef: {{apiVersion: apps/v1, kind: Deployment, name: karate-gcn-serve}}
  minReplicas: 2
  maxReplicas: 6
  metrics: [{{type: Resource, resource: {{name: cpu, target: {{type: Utilization, averageUtilization: 70}}}}}}]
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata: {{name: karate-gcn-serve, namespace: {NS}}}
spec:
  minAvailable: 1
  selector: {{matchLabels: {{app: karate-gcn-serve}}}}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: {{name: karate-gcn-serve, namespace: {NS}}}
spec:
  podSelector: {{matchLabels: {{app: karate-gcn-serve}}}}
  policyTypes: [Ingress]
  ingress: [{{from: [{{namespaceSelector: {{matchLabels: {{access: karate-gcn}}}}}}], ports: [{{port: 8080}}]}}]
---
apiVersion: batch/v1
kind: CronJob
metadata: {{name: karate-gcn-monitor, namespace: {NS}}}
spec:
  schedule: "*/30 * * * *"
  jobTemplate:
    spec:
      template:
        spec:
          restartPolicy: Never
          securityContext: {{runAsNonRoot: true, runAsUser: 10001}}
          containers:
            - name: monitor
              image: registry.example.com/karate-gcn/pipeline:1.0.0
              args: ["python", "scripts/gnn/monitor_probe.py"]
              envFrom: [{{configMapRef: {{name: karate-gcn-config}}}}]
              volumeMounts: [{{name: registry, mountPath: /registry, readOnly: true}}]
              resources: {{requests: {{cpu: 50m, memory: 64Mi}}}}
          volumes: [{{name: registry, persistentVolumeClaim: {{claimName: karate-gcn-registry, readOnly: true}}}}]
'''
out = os.path.join(ROOT, "blueprints", "karate-gcn", "karate-gcn.k8s.yaml")
open(out, "w").write(doc)
print("wrote", out, len(doc), "bytes")
