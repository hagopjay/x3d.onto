#!/usr/bin/env python3
"""Tests for the Stage-2 k8s blueprint analysis. Run: python3 -m pytest -q scripts/infra/test_infra.py"""
import importlib.util, json, os, re, subprocess, sys, tempfile
import pytest, yaml
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
BP = os.path.join(ROOT, "blueprints", "karate-gcn", "karate-gcn.k8s.yaml")


def _adapter():
    spec = importlib.util.spec_from_file_location("k8s_to_trace", os.path.join(ROOT, "scripts", "adapters", "k8s_to_trace.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


@pytest.fixture(scope="module")
def trace():
    out = tempfile.mkdtemp(prefix="k8s-test-")
    _adapter().main(["--blueprint", BP, "--out", os.path.join(out, "t.json"), "--insights-md", os.path.join(out, "i.md")])
    return json.load(open(os.path.join(out, "t.json")))


def test_blueprint_is_valid_yaml_with_known_kinds():
    docs = [d for d in yaml.safe_load_all(open(BP)) if d]
    assert len(docs) == 11 and all({"apiVersion", "kind", "metadata"} <= set(d) for d in docs)


def test_blueprint_carries_the_real_stage1_hashes(trace):
    run = json.load(open(os.path.join(ROOT, "out", "gnn", "run.json")))
    assert trace["source"]["provenance"]["weights_sha256"] == run["weights_sha256"] and trace["source"]["provenance"]["dataset_sha256"] == run["dataset_sha256"]


def test_trace_is_honestly_synthetic_and_consistent(trace):
    assert trace["schema"] == "x3d-trace/1" and trace["source"]["kind"] == "k8s-blueprint" and trace["source"]["synthetic"] is True
    assert any("SYNTHETIC" in n for n in trace["notes"]) and any("REAL" in n for n in trace["notes"])
    st = trace["stages"]
    assert [s["stage_key"] for s in st] == ["parse", "index", "resolve", "lint", "budget"] and all(s["metrics"]["wall_ms"] > 0 for s in st)
    assert all(st[i + 1]["start_s"] >= st[i]["end_s"] for i in range(4))
    b = trace["blueprint"]
    ids = {n["id"] for n in b["nodes"]}
    assert len(b["nodes"]) == trace["metrics"]["resources"] == 11 and all(e["from"] in ids and e["to"] in ids for e in b["edges"])
    assert b["dangling"] == [] and trace["metrics"]["checks_passed"] <= trace["metrics"]["checks_run"]


def test_reference_resolution_finds_a_dangling_reference(tmp_path):
    txt = open(BP).read()
    i = txt.rindex("claimName: karate-gcn-registry")
    bad = txt[:i] + "claimName: missing-claim" + txt[i + len("claimName: karate-gcn-registry"):]
    p = tmp_path / "bad.yaml"; p.write_text(bad)
    out = tmp_path / "t.json"
    _adapter().main(["--blueprint", str(p), "--out", str(out), "--insights-md", str(tmp_path / "i.md")])
    t = json.load(open(out))
    assert t["metrics"]["dangling_references"] == 1 and any(c["rule"] == "R6" and c["failing"] for c in t["blueprint"]["checks"])


def test_insight_numbers_match_text(trace):
    for c in trace["blueprint"]["insights"]:
        vals = [float(v) for v in c["numbers"].values()]
        for tok in re.findall(r"(?<![\w.])\d+(?:\.\d+)?(?![\w])", c["text"]):
            assert any(abs(float(tok) - x) <= max(0.006 * abs(x), 0.5) for x in vals), (c["id"], tok)


def test_scene_model_builds(trace):
    sys.path.insert(0, os.path.join(ROOT, "scripts", "scene"))
    argv, sys.argv = sys.argv, sys.argv[:1]
    try:
        import infra_scene
    finally:
        sys.argv = argv
    m = infra_scene.InfraModel(trace)
    assert 150 < len(m.items) < 400 and len({i["name"] for i in m.items}) == len(m.items) and m.syn and "SYNTHETIC" in m.banner
