#!/usr/bin/env python3
"""Validate X3D files with the x3d_mcp server over stdio (tools validate_x3d, validate_semantic).
usage: ~/Projects/x3d/x3d_mcp/.venv/bin/python scripts/gnn/validate_x3d_gnn.py FILE.x3d [...]   -> prints a summary, writes FILE.validate.json under out/scene/"""
import asyncio, json, os, sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

REPO = os.path.expanduser("~/Projects/x3d/x3d_mcp")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "out", "infra")


def text_of(res):
    return "".join(getattr(c, "text", "") for c in res.content)


def parse(t):
    try:
        return json.loads(t)
    except Exception:
        return {"raw": t}


async def main(files):
    params = StdioServerParameters(command=os.path.join(REPO, ".venv/bin/python"), args=["-m", "src.server"], cwd=REPO)
    async with stdio_client(params) as (r, w):
        async with ClientSession(r, w) as s:
            await s.initialize()
            for f in files:
                f = os.path.abspath(f)
                content = open(f, encoding="utf-8").read()
                out = {"file": f, "bytes": len(content.encode())}
                for tool, args in (("validate_x3d", {"content": content, "encoding": "xml"}), ("validate_semantic", {"content": content})):
                    res = await s.call_tool(tool, args)
                    out[tool] = parse(text_of(res))
                name = os.path.basename(f).rsplit(".", 1)[0]
                os.makedirs(OUT, exist_ok=True)
                with open(os.path.join(OUT, name + ".validate.json"), "w") as fh:
                    json.dump(out, fh, indent=1)
                v, sm = out["validate_x3d"], out["validate_semantic"]
                print(name, "validate_x3d:", json.dumps(v)[:400])
                print(name, "validate_semantic:", json.dumps(sm)[:1500])

asyncio.run(main(sys.argv[1:]))
