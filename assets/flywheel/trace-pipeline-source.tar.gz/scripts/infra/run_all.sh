#!/bin/bash
# STAGE 2 (thin, static): authored k8s blueprint -> real timed static analysis -> trace -> scene -> checks. No cluster, no network, no kubectl.
#   scripts/infra/run_all.sh [--no-render]      Needs: python3 + pyyaml + pytest, Blender 5.1 + x3d_blender_io, x3d_mcp venv, node/playwright/Chromium/X_ITE (see scripts/gnn/run_all.sh)
set -u
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
BLENDER=${BLENDER:-/Applications/Blender.app/Contents/MacOS/Blender}
MCPPY=${MCPPY:-$HOME/Projects/x3d/x3d_mcp/.venv/bin/python}
export NODE_PATH=${NODE_PATH:-/tmp/node_modules}
export CHROME_PATH=${CHROME_PATH:-$HOME/Library/Caches/ms-playwright/chromium-1155/chrome-mac/Chromium.app/Contents/MacOS/Chromium}
export XITE_DIST=${XITE_DIST:-/tmp/xite-pack/pkg/package/dist}
mkdir -p out/infra scenes traces; LOG=out/infra/checks.log; : > $LOG
step() { echo "=== $1" | tee -a $LOG; }
step "1 blueprint (authored; hashes + hyper-parameters from the real Stage-1 run)"; python3 scripts/infra/make_blueprint.py | tee -a $LOG
step "2 adapter: parse, index, resolve, lint, budget (timed) -> traces/k8s-karate.trace.json"; python3 scripts/adapters/k8s_to_trace.py | tee -a $LOG
step "3 tests"; python3 -m pytest -q scripts/infra/test_infra.py 2>&1 | tail -2 | tee -a $LOG
step "4 compatibility: the UNMODIFIED generic builder accepts this trace"
$BLENDER -b --factory-startup -noaudio --python scripts/scene/trace_to_scene.py -- --trace traces/k8s-karate.trace.json --out-x3d out/infra/k8s-generic.x3d 2>&1 | grep -E "RESULT|Error|Traceback" | tee -a $LOG
step "5 scene build"; $BLENDER -b --factory-startup -noaudio --python scripts/scene/infra_scene.py -- --infra-trace traces/k8s-karate.trace.json --infra-out-x3d scenes/k8s-karate.x3d --infra-report out/infra/build.json 2>&1 | grep -E "RESULT|Error|Traceback" | tee -a $LOG
step "6 x3d_mcp validate"; $MCPPY scripts/infra/validate_x3d_infra.py scenes/k8s-karate.x3d 2>&1 | grep -E "validate_x3d:|validate_semantic" | cut -c1-200 | tee -a $LOG
step "7 exported motion vs trace tracks"; python3 scripts/infra/verify_infra_x3d.py traces/k8s-karate.trace.json scenes/k8s-karate.x3d out/infra/build.json | cut -c1-400 | tee -a $LOG
step "8 numbers shown vs trace"; python3 scripts/gnn/audit_numbers_gnn.py traces/k8s-karate.trace.json scenes/k8s-karate.x3d | tee -a $LOG
if [ "${1:-}" != "--no-render" ]; then
  step "9 X_ITE render check"; rm -f out/infra/k8s-karate-*.png
  node scripts/infra/render_check_infra.js scenes/k8s-karate.x3d out/infra/k8s-karate 0.12,0.50,0.93 CA_VP3_Graph@0.93 CA_VP2_Overview@0.5 2>&1 | tail -1 | cut -c1-200 | tee -a $LOG
  python3 scripts/scene/image_stats.py out/infra k8s-karate | tail -2 | cut -c1-300 | tee -a $LOG
fi
step "10 Stage 1 unaffected: GNN tests + GNN scene rebuilds identically"
python3 -m pytest -q scripts/gnn/test_gnn.py 2>&1 | tail -1 | tee -a $LOG
python3 scripts/gnn/make_figures.py >/dev/null 2>&1; $BLENDER -b --factory-startup -noaudio --python scripts/scene/gnn_scene.py -- --gnn-trace traces/gnn-karate.trace.json --gnn-out-x3d out/infra/gnn-check.x3d 2>&1 | grep -E "RESULT" | tee -a $LOG
norm() { sed 's/name="filename" content="[^"]*"//' "$1" | shasum -a 256; }
[ "$(norm out/infra/gnn-check.x3d)" = "$(norm scenes/gnn-karate.x3d)" ] && echo "gnn-karate.x3d IDENTICAL after Stage-2 changes" | tee -a $LOG || echo "gnn-karate.x3d DIFFERENT" | tee -a $LOG
rm -f out/infra/gnn-check.x3d; rm -rf scripts/*/__pycache__ .pytest_cache scripts/*/.pytest_cache; echo done | tee -a $LOG
